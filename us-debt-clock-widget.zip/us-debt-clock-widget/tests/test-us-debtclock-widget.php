<?php

class DebtclockTest extends WP_UnitTestCase {

	// testing framework is ready for expansion :)
	// for now, we just make sure the universe still exists
	public function testTruth() {

		$this->assertTrue( true );
	}
}

