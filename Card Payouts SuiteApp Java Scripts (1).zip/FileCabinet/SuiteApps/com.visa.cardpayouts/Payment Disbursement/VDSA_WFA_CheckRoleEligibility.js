/*************************************************************
 * Script   : VDSA_WFA_DetermineRoleEligibility.js
 * Abstract : Workflow action script for determining if role should be able to
              view button to process card payouts payment
 * Author   : r.v.magbojos
 * Revision History :
 *************************************************************
 * Version * Date       * Author              * Description
 *************************************************************
 *   0.1   * 02/20/2019 * r.v.magbojos        * Initial version                   
 *************************************************************/

/**
 * @NApiVersion 2.x
 * @NScriptType workflowactionscript
 */
define(['N/search', 'N/runtime'],

function (search, runtime) {

  /**
   * Main function to determine if role is eligible.
   *
   * @param {Object} scriptContext
   * @param {Record} scriptContext.newRecord - New record
   * @param {Record} scriptContext.oldRecord - Old record
   * @Since 2016.1
   */
  function onAction(scriptContext) {
    var roleEligible = 'F';

    var scriptObj = runtime.getCurrentScript();
    var prefId = scriptObj.getParameter({
      name: 'custscript_vdsa_preference_record'
    });
    
    if (!prefId) {
      return 'F';
    }
    
    // Lookup global preference
    var lookupRes = search.lookupFields({
      type: 'customrecord_vdsa_suiteapp_preference',
      id: prefId,
      columns: 'custrecord_vdsa_pymt_processing_roles'
    });
    var pymtProcessingRolesArr = lookupRes.custrecord_vdsa_pymt_processing_roles;
    
    // Get current user role
    var currUserRole = runtime.getCurrentUser().role;
    
    // Check if current user role is in lookup results
    for (var index in pymtProcessingRolesArr) {
      var roleId = pymtProcessingRolesArr[index]['value'];
      
      if (currUserRole == roleId) {
        roleEligible = 'T';
        break;
      }
    }

    return roleEligible;
  }

  return {
    onAction: onAction
  };

});
