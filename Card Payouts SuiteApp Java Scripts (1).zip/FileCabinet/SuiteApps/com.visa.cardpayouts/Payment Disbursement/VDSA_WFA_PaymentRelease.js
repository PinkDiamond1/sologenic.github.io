/*************************************************************
 * Script   : VDSA_WFA_PaymentRelease.js
 * Abstract : Workflow action script for confirming or declining of vendor payments.
 * Author   : gerard.c.villasenor
 * Revision History :
 *************************************************************
 * Version * Date       * Author              * Description
 *************************************************************
 *   0.1   * 03/12/2019 * gerard.c.villasenor * Initial version
 *   0.2   * 03/13/2019 * jayzar.n.estareja   * Udated hard-coded variables
 *   1.0   * 03/13/2019 * gerard.c.villasenor * Script Refinement
 *************************************************************/

/**
 * @NApiVersion 2.x
 * @NScriptType workflowactionscript
 */
define(['N/action', 'N/log', 'N/runtime', '../Library/VDSA_LIB_constantsFile.js'],

function (action, log, runtime, VDSA_CONST) {

    /**
     * Function for processing the parameters that will identify if the payment is to be confirmed or declined
     * Definition of the Suitelet script trigger point.
     *
     * @param {Object} scriptContext
     * @param {Record} scriptContext.newRecord - New record
     * @param {Record} scriptContext.oldRecord - Old record
     * @Since 2016.1
     */
    function onAction(scriptContext) {
        
        try {
            var currRecObj = scriptContext.newRecord;
            var recordId = currRecObj.id;
            var recordType = currRecObj.type;

            var scriptObj = runtime.getCurrentScript();

            var method = scriptObj.getParameter({
                name: 'custscript_vdsa_action'
            });

            releaseBillPayments(method, recordId, recordType);

        } catch(errObj){
            log.error('VDSA_ERROR', errObj.message);
        }
    }

    /**
     * Reusable function for confirming or declining of vendor payment.
     *
     */
    function releaseBillPayments(method, recordId, recordType) {

        var actionToDo = method == VDSA_CONST.Lists.PaymentStatus.CONFIRMED ? 'confirm' : 'decline';
        var result = action.execute({
            recordType: recordType,
            id: actionToDo,
            params: { recordId: recordId }
        });

        return result;
    }

    return {
        onAction: onAction
    };

});
