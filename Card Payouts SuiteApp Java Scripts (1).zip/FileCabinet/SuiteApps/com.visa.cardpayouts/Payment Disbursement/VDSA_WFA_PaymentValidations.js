/*************************************************************
 * Script   : VDSA_WFA_PaymentValidations.js
 * Abstract : Workflow action script for validating of the vendor payment before sending to Treasury Bank
 * Author   : gerard.c.villasenor
 * Revision History :
 *************************************************************
 * Version * Date       * Author              * Description
 *************************************************************
 *   0.1   * 02/20/2019 * gerard.c.villasenor * Initial version
 *   1.0   * 03/07/2019 * gerard.c.villasenor * Added validations for treasury bank details
 *   1.1   * 03/13/2019 * jayzar.n.estareja   * Updated hard-coded variables
 *   2.0   * 03/13/2019 * gerard.c.villasenor * Script Refinement  
 *   3.0   * 03/20/2019 * gerard.c.villasenor * Added getting of payment amount threshold and
 *                                              usd currency restriction    
 *   3.1   * 03/21/2019 * jayzar.n.estareja   * Added general preference validation
 *   3.2   * 03/22/2019 * gerard.c.villasenor * Added validations for both epayment and card payouts checkbox.       
 *   3.3   * 03/26/2019 * gerard.c.villasenor * Fixed bug with rethrowing of error.   
 *   3.4   * 03/28/2019 * gerard.c.villasenor * Added validations for inactivated or unenrolled debit details  
 *   4.0   * 04/02/2019 * gerard.c.villasenor * Added valdiations for inactivated treasury 
 *												bank details and reconstructed the main method to optimize validations 
 *   4.1   * 04/03/2019 * gerard.c.villasenor * Added method to convert payment amount to the currency of the treasury bank
 *   4.2   * 04/04/2019 * gerard.c.villasenor * Modified currency validations to consider the supported currency of the Treasury Bank
 *   4.3   * 04/23/2019 * gerard.c.villasenor * Convert the data type of the returned value
 *   4.4   * 01/31/2020 * jayzar.n.estareja   * Added validations for both ACH and card payouts checkbox.  
 *************************************************************/

/**
 * @NApiVersion 2.x
 * @NScriptType workflowactionscript
 */
define(['N/error', 'N/search', 'N/log', 'N/runtime', 'N/currency', '../Library/VDSA_LIB_constantsFile.js'],

function (error, search, log, runtime, currency, VDSA_CONST) {

	/**
	 * Main function for getting of required data for validation of the Vendor Payment
	 * Definition of the Suitelet script trigger point.
	 *
	 * @param {Object} scriptContext
	 * @param {Record} scriptContext.newRecord - New record
	 * @param {Record} scriptContext.oldRecord - Old record
	 * @Since 2016.1
	 */
	function onAction(scriptContext) {

		var resResp = VDSA_CONST.Lists.PaymentStatus.IN_PROGRESS;

		try {
		
			var recObj = scriptContext.newRecord;
			
			var scriptObj = runtime.getCurrentScript();

			var prefId = scriptObj.getParameter({
				name: 'custscript_vdsa_preference_record'
			});

			var debitDetailsId = recObj.getValue({
				fieldId: 'custbody_vdsa_debit_details'
			});

			var bankDetailsId = recObj.getValue({
				fieldId: 'custbody_vdsa_treasury_bank_details'
			});

			//validates if the debit details, bank details and preference is missing or empty
			validateIfNull(debitDetailsId, bankDetailsId, prefId, recObj);

			var ePaymentFieldId = scriptObj.getParameter({
				name: 'custscript_vdsa_epayment_fieldid'
			});

			var ePaymentField = recObj.getField({
				fieldId: ePaymentFieldId
			});

			if (!!ePaymentField){
				//validates if for e payment and for card payouts are both checked
				validatePaymentCheckboxes(ePaymentField, ePaymentFieldId, recObj);
			}

			var achFieldId = 'toach';
			var achField = recObj.getField({
				fieldId: achFieldId
			});

			if (!!achField){
				//validates if to ACH and for card payouts are both checked
				validatePaymentCheckboxes(achField, achFieldId, recObj);
			}

			//validates the debit details tagged on the payment record
			validateDebitDetails(debitDetailsId, recObj);

			//validates if the treasury bank details tagged on the payment record and if valid returns the treasury bank look up object.
			var bankDetailsObj = validateBankDetails(bankDetailsId);

			//currency of the bill payment record
			var currId = recObj.getValue({
				fieldId: 'currency'
			});

			//Object of the supported currency of the treasury bank
			var suppCurrObj = bankDetailsObj['custrecord_vdsa_currency_list'];

			//validates if the currency is supported
			currencyCheck(currId, suppCurrObj);

			var pmtAmount = recObj.getValue({
				fieldId: 'total'
			});

			var treasuryBankCurr = bankDetailsObj['custrecord_vdsa_bank_currency'][0].value;
			var treasuryBankCurrCode = bankDetailsObj['custrecord_vdsa_bank_currency'][0].text;

			var currConvObj = new Object();

			if (currId != treasuryBankCurr){

				//convert the payment amount to the currency of the bank
				currConvObj = convertCurrencyToTreasuryBankCurrency(currId, treasuryBankCurr, pmtAmount, recObj);
			}

			//var thresholdAmt = bankDetailsObj['custrecord_vdsa_payment_threshold'];

			//validates if the amount is not over the treasury bank threshold limit
			//pmtAmtValidation(thresholdAmt, pmtAmount, currConvObj, treasuryBankCurrCode);


		} catch (errObj){

			if (typeof errObj == 'object'){

				log.error(errObj.name, errObj.message);

				throw errObj.message;

			} else {

				throw errObj;
			}
			
		}

		return resResp.toString();
	}

	/**
	 * Function for creation of error Object
	 * this will log the error on NetSuite.
	 */

	function createErrObj(errName, errMsg){

		var errObj = error.create({
			name: errName,
			message: errMsg
		});

		log.error(errObj.name, errObj.message);

		return errObj;
	}

	/**
	 * Function for checking if the card payout preference record, debit details and bank details id is 
	 * populated or not empty.
	 */

	function validateIfNull(debitDetailsId, bankDetailsId, prefId, recObj){

		var errObj = new Object(),
			errName = '',
			errMsg = '';

		if (!prefId){

			errName = 'NULL_CP_PREFERENCE',
			errMsg = 'Card Payouts Preference Record is not configured in the General Preferences.'

		} else if (!parseInt(debitDetailsId)) {

			var debitDetailsLabel = recObj.getField({
				fieldId: 'custbody_vdsa_debit_details'
			}).label;

			errName = 'DEBIT_DETAIL_EMPTY';
			errMsg = '"' + debitDetailsLabel + '" is not selected in the Payment record.';
		} else if (!parseInt(bankDetailsId)){

			var bankDetailsLabel = recObj.getField({
				fieldId: 'custbody_vdsa_treasury_bank_details'
			}).label;

			errName = 'TREASURY_BANK_DETAIL_EMPTY',
			errMsg = '"' + bankDetailsLabel + '" is not selected in the Payment record. <br><br>Note: If there is no available' +
				'Corporate Bank Details in the dropdown field, please create a new Corporate Bank Details for the Bank Account' +
				'selected or check if the Corporate Bank Details you are using is not inactive.';
		}

		if (!!errName){

			errObj = createErrObj(errName, errMsg);
			throw errObj.message;
		}
	}

	/**
	* Function for validation if the e-payment or ach and card payouts is checked
   	* if checked the script will throw an error.
	*/
	function validatePaymentCheckboxes(fieldObj, fieldId, recObj){

		var errObj = new Object(),
			errName = '',
			errMsg = '';

		var OtherPaymentChk = recObj.getValue({
			fieldId: fieldId
		});

		var cardPayoutChk = recObj.getValue({
			fieldId: 'custbody_vdsa_for_visa_direct_payment'
		});

		var OtherPaymentLabel = fieldObj.label;

	    if (OtherPaymentChk == true && cardPayoutChk == true){

	    	errName = 'ERROR';
	    	errMsg = 'Please only select one payment method to process this payment. ' +
				"Please don't tick the " + '"'+ OtherPaymentLabel +'" ' + "checkbox to process this payment using Card Payouts.";

			errObj = createErrObj(errName, errMsg);

			throw errObj.message;
	    }

	}

	/**
	 * Function for checking if the currency is USD.
	 */
	 function currencyCheck(currId, suppCurrObj){

	 	var errObj = new Object(),
	 		errName = '',
	 		errMsg = '';

	 	var transFormData = currConvtoArr(suppCurrObj);
	 	var suppCurr = transFormData['supportedcurrency'];
	 	var currMsg = transFormData['message'];

	 	if (suppCurr.indexOf(currId) == -1){

			errName ='CCY_INVALID';
			errMsg = "Card Payouts Corporate Bank Details doesn't support the currency of the Bill Payment. Card Payouts Treasury" + 
			" Bank Details only supports the following currency: " + currMsg + ".";
	 	}

	 	if (!!errName){

	 		errObj = createErrObj(errName, errMsg);

			throw errObj.message;
	 	}

	 }


	 /**
	 * Function for converting supported currency array of objects into array of currency ids and label for error message
	 */
	 function currConvtoArr(suppCurrObj){

	 	var transFormData = new Object(),
	 		suppCurrId = new Array(),
	 		suppCurrTxt = new Array ();

	 	for (var i in suppCurrObj){
	 		suppCurrId.push(suppCurrObj[i].value);
	 		suppCurrTxt.push(suppCurrObj[i].text);
	 	}

	 	transFormData['supportedcurrency'] = suppCurrId; 
	 	transFormData['message'] = suppCurrTxt.join(', ');

	 	return transFormData;

	 }


	/**
	 * Function for looking up values
	 * this will return the object result of the lookup values
	 */
	 function lookupValues(recordType, recordId, fieldObj){

	 	var lookUpObj = search.lookupFields({
            type: recordType,
            id: recordId,
            columns: fieldObj
        });

 		return lookUpObj;
	 }

	/**
	 * Function for validation of the payment amount based from the treasury bank amount threshold
	 * amtValue = the threshold amount, pmtAmount = the Bill Payment Amount value
	 */
	function pmtAmtValidation(thresholdAmt, pmtAmount, currConvObj, treasuryBankCurrCode) {

		var errObj = new Object(),
			errName = '',
			errMsg = '',
			addtlMsg = '';

		if (!!currConvObj['convertedamount']){
			var exchRate = currConvObj['exchangerate'];
			pmtAmount = currConvObj['convertedamount'];
			addtlMsg = 'Bill Payment amount is ' + pmtAmount.toFixed(2) + ' in ' + treasuryBankCurrCode	+ ' using ' + exchRate + ' as exchange rate.';
		}

		if (parseFloat(pmtAmount) > parseFloat(thresholdAmt)) {
		
			errName = 'PMT_AMT_THRE_EXCEED';
			errMsg = 'Bill Payment Amount exceeded from the threshold value of ' + thresholdAmt + ' ' + treasuryBankCurrCode + '. ' + addtlMsg;
		}

		if (!!errName){

	 		errObj = createErrObj(errName, errMsg);

			throw errObj.message;
	 	}
		
	}

	/**
	 * Function for validation of the debit details set on the bill payment record
	 * such as if it's empty, expired or token is invalid
	 */
	function validateDebitDetails(debitDetailsId, recObj) {

		var errObj = new Object(),
			errName = '',
			errMsg = '';

		var debitDetailsLabel = recObj.getField({
			fieldId: 'custbody_vdsa_debit_details'
		}).label;

		var recType = 'customrecord_vdsa_debit_details';

		var arrCols = ['custrecord_vdsa_debit_token', 'custrecord_vdsa_debit_expiration_date', 'custrecord_vdsa_debit_billing_country', 'isinactive'];

		var debitDetailsObj = lookupValues(recType, debitDetailsId, arrCols);

		var dateToday = new Date();

		if (!debitDetailsObj['custrecord_vdsa_debit_token']) {

			errName = 'NULL_DEBIT_TOKEN';
			errMsg = 'Token for the selected Debit Details is missing.';

		} else if (!!debitDetailsObj['isinactive']){

			errName = 'DEBIT_IS_INACTIVE';
			errMsg = "Bill Payment can't be processed because the Contractor's Debit Details is inactive. It's either inactivated or unenrolled in NetSuite";

		//} else if (debitDetailsObj['custrecord_vdsa_debit_billing_country'] != 'US'){

		//	errName = 'DEBIT_INVALID_COUNTRY';
		//	errMsg = "Contractor's Debit Card Billing Country is not supported. Card Payouts only supports payments within the United States.";

		} else if (dateToday >= new Date(debitDetailsObj['custrecord_vdsa_debit_expiration_date'])) {

			errName = 'CARD_IS_EXPIRED';
			errMsg = 'Debit Card has already expired.';
		}	

		if (!!errName) {

			errObj = createErrObj(errName, errMsg);

			throw errObj.message;
		}
	}

	/**
	 * Function for validation of the treasury bank details to make sure it is active.
	 */
	function validateBankDetails(bankDetailsId) {

		var errObj = new Object(),
			errName = '',
			errMsg = '';

		var bankType = 'customrecord_vdsa_treasury_bank_details';

		var bankCols = ['isinactive', 'custrecord_vdsa_payment_threshold', 'custrecord_vdsa_bank_currency', 'custrecord_vdsa_currency_list'];

		var bankDetailsObj = lookupValues(bankType, bankDetailsId, bankCols);

		if (!!bankDetailsObj['isinactive']){

			errName = 'DEBIT_IS_INACTIVE';
			errMsg = "Bill Payment can't be processed because the Corporate Bank details used has been deactivated.";
		}

		if (!!errName) {

			errObj = createErrObj(errName, errMsg);

			throw errObj.message;
		}

		return bankDetailsObj;

	}

	/*
	 * Function for converting the bill payment amount to the currency
	 * of the treasury bank details to correctly validate the threshold amount,
	 */

	 function convertCurrencyToTreasuryBankCurrency(sourceCurr, targetCurr, tranAmt, recObj){

	 	var convertedAmt = 0,
	 		exchRate = 0,
	 		currConvObj	= new Object();


 		var tranDate = recObj.getValue({
 			fieldId: 'trandate'
 		});

 		exchRate = currency.exchangeRate({
 			date: tranDate,
 			source: sourceCurr,
 			target: targetCurr
 		});
 	

	 	convertedAmt = parseFloat(tranAmt) * parseFloat(exchRate);

	 	currConvObj['exchangerate'] = exchRate;
	 	currConvObj['convertedamount'] = convertedAmt;

	 	return currConvObj;
	 }

	return {
		onAction: onAction
	};

});
