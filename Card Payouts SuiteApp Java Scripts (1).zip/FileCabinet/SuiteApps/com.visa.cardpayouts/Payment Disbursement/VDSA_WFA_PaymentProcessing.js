/*************************************************************
 * Script   : VDSA_WFA_PaymentProcessing.js
 * Abstract : Workflow action script for sending request to and getting response from the Treasury Bank.
 * Author   : gerard.c.villasenor
 * Revision History :
 *************************************************************
 * Version * Date       * Author              * Description
 *************************************************************
 *   0.1   * 02/20/2019 * gerard.c.villasenor * Initial version
 *   0.2   * 03/07/2019 * gerard.c.villasenor * Created logic for payment processing with treasury bank
 *   0.3   * 03/12/2019 * jayzar.n.estareja   * Updated logic to include auto retry
 *   0.4   * 03/13/2019 * gerard.c.villasenor * Script Refinement
 *   0.5   * 03/20/2019 * jayzar.n.estareja   * Added getting of preference object
 *   0.6   * 03/22/2019 * jayzar.n.estareja   * Fixed error handling
 *   1.0   * 04/16/2019 * gerard.c.villasenor * Added OCT Function
 *   1.1   * 04/17/2019 * gerard.c.villasenor * Added parse function for the xml response of OCT
 *   1.2   * 04/25/2019 * jayzar.n.estareha   * Fixed Netsuite error handling
 *   2.0   * 01/27/2020 * jayzar.n.estareja   * Integration - card payment transaction
 *   2.1   * 02/04/2020 * darryl.d.caparas    * Modified SourceSenderName
 *   2.2   * 03/03/2020 * jayzar.n.estareja   * Payment email notification
 *   2.3   * 03/31/2020 * darryl.d.caparas    * CompanyName for email notifications
 *************************************************************/

/**
 * @NApiVersion 2.x
 * @NScriptType workflowactionscript
 */
define(['N/search', 'N/log', 'N/record', 'N/runtime', 'N/email', '../Library/VDSA_LIB_constantsFile.js', '../Library/VDSA_LIB_TokenService.js'],

	function (search, log, record, runtime, email, VDSA_CONST, VDSA_TSP) {

		/**
		 * Main function for the payment processing
		 * Definition of the Suitelet script trigger point.
		 *
		 * @param {Object} scriptContext
		 * @param {Record} scriptContext.newRecord - New record
		 * @param {Record} scriptContext.oldRecord - Old record
		 * @Since 2016.1
		 */
		function onAction(scriptContext) {

			var objRec = scriptContext.newRecord;
			var vendBillId = objRec.id;

			/* get general preference */
			var scriptObj = runtime.getCurrentScript();
			var prefId = scriptObj.getParameter({
				name: 'custscript_vdsa_preference_record'
			});
			var retryCount = 0;
			var maxRetryCount = '';

			if (!!prefId) {
				var lookupValue = search.lookupFields({
					type: 'customrecord_vdsa_suiteapp_preference',
					id: prefId,
					columns: [
						'custrecord_vdsa_max_num_retries',
						'custrecord_vdsa_payout_endpoint',
						'custrecord_vdsa_email_author_payment',
						'custrecord_vdsa_card_payment_email',
						'custrecord_vdsa_email_body_payment',
						'custrecord_vdsa_email_subj_payment',
						'custrecord_vdsa_card_sender_email'
					]
				});

				maxRetryCount = lookupValue.custrecord_vdsa_max_num_retries[0].value;
				payoutURL = lookupValue.custrecord_vdsa_payout_endpoint;

			} else {
				throw 'Preference was not setup on the General Preferences.'
			}

			try {

				var paymentAmt = Math.abs(objRec.getValue({ fieldId: 'total' }));
				//var transactionNumber = objRec.getValue({ fieldId: 'transactionnumber' });
				var transactionNumber = objRec.getValue({ fieldId: 'tranid' });
				var treasuryBankId = objRec.getValue({ fieldId: 'custbody_vdsa_treasury_bank_details' });
				var debitDetailsId = objRec.getValue({ fieldId: 'custbody_vdsa_debit_details' });
				var currencyId = objRec.getValue({ fieldId: 'currency'});
				var vendorId = objRec.getValue({ fieldId: 'entity'});
				var checkNum = objRec.getValue({ fieldId: 'tranid'});
				var lookupObjects = lookupRecords(treasuryBankId, debitDetailsId, currencyId, vendorId);
				var treasuryBankObj = lookupObjects.treasuryBankObj;
				var debitDetailsObj = lookupObjects.debitDetailsObj;
				var currencyCode = lookupObjects.currencyCode;
				var vendorObj = lookupObjects.vendorObj;

				var responseType = 0;
				var responseValue = '';

				do {

					responseType = processPaymentTranasction(vendBillId, debitDetailsObj, treasuryBankObj, paymentAmt,transactionNumber);

					/* update payment status based on action type */
					switch (parseInt(responseType)) {
						case VDSA_CONST.Lists.ActionType.ACCEPT:
							responseValue = VDSA_CONST.Lists.PaymentStatus.CONFIRMED.toString();
							emailNotification(lookupValue, vendorObj, debitDetailsObj.custrecord_vdsa_debit_card_number, paymentAmt.toFixed(2), checkNum);
							break;
						case VDSA_CONST.Lists.ActionType.MANUALLY_REPROCESS:
							responseValue = VDSA_CONST.Lists.PaymentStatus.FOR_REPROCESSING.toString();
							break;
						case VDSA_CONST.Lists.ActionType.REJECT:
							responseValue = VDSA_CONST.Lists.PaymentStatus.REJECTED.toString();
							break;
						default:
							responseValue = VDSA_CONST.Lists.PaymentStatus.IN_PROGRESS.toString();
					}

					retryCount++;
				} while (responseType == VDSA_CONST.Lists.ActionType.AUTO_RETRY && retryCount <= maxRetryCount)

				return responseValue;

			} catch (err) {
				log.error('Error Encountered - Main', JSON.stringify(err));
				return VDSA_CONST.Lists.PaymentStatus.IN_PROGRESS.toString();
			}
		}

		/**
		 * function for looking up values of the treasury bank and debit details.
		 */
		function lookupRecords(treasuryBankId, debitDetailsId, currencyId, vendorId){

			var treasuryBankObj = lookupValues(
				treasuryBankId,
				[ 'name' ],
				'customrecord_vdsa_treasury_bank_details'
			);

			var debitDetailsObj = lookupValues(
				debitDetailsId,
				[ 'custrecord_vdsa_debit_token', 'custrecord_vdsa_debit_card_number' ],
				'customrecord_vdsa_debit_details'
			);

			var currencyCode = lookupValues(
				currencyId,
				[ 'symbol' ],
				'currency'
			)['symbol'];

			var vendorObj = lookupValues(
				vendorId,
				['email', 'entityid', 'internalid'],
				'vendor'
			);

			return {
				treasuryBankObj: treasuryBankObj,
				debitDetailsObj: debitDetailsObj,
				currencyCode: currencyCode,
				vendorObj: vendorObj
			}
		}

		/**
		 * Function for processing request to corporate bank for payments.
		 * this will send the request to the payment endpoints and process the response received.
		 */
		function processPaymentTranasction(vendBillId, debitDetailsObj, treasuryBankObj, paymentAmt,transactionNumber) {
			responseType = 0;

			try {
				// send request to bank
				var paymentTransaction;
				try{
					paymentTransaction = VDSA_TSP.paymentTransaction(debitDetailsObj.custrecord_vdsa_debit_token, paymentAmt, transactionNumber);
				} catch (err) {
					paymentTransaction = {
						request: '',
						response: {body: err}
					}
				}
				log.debug('paymentTransaction',paymentTransaction);

				// map response to netsuite record
				var pymtEventObj = processPaymentResponse(vendBillId, paymentTransaction);
				log.debug('pymtEventObj',pymtEventObj);

				// get action type based on response
				if (pymtEventObj.custrecord_vdsa_reason_code!=null){
					var actionResponse = getActionForResponse(pymtEventObj.custrecord_vdsa_reason_code);
				}
				log.debug('actionResponse',actionResponse);
				if (actionResponse != null){
					responseType = actionResponse.responseType;
					pymtEventObj.custrecord_vdsa_event_pymt_status = actionResponse.eventStatus;
					if (actionResponse.responseType == 0){
						pymtEventObj.custrecord_vdsa_event_message = actionResponse.eventMessage;
					}
				}

				// create payment event
				var eventId = createPaymentEvent(pymtEventObj);
				log.debug('eventId',eventId);
			} catch (err) {
				log.error('Error Encountered - Process Transaction', JSON.stringify(err));
			}
			
			return responseType;
		}

		/**
		 * Function for converting the response from the payment endpoints to JSON format.
		 * this will convert the Raw Response from the payments to JSON format.
		 */
		function processPaymentResponse(vendBillId, paymentTransaction){
			var pymtEventObj = new Object();
	
			pymtEventObj['custrecord_vdsa_event_parent_transaction'] = vendBillId;
			pymtEventObj['custrecord_vdsa_event_date'] = new Date();
			pymtEventObj['custrecord_vdsa_event_raw_data'] = JSON.stringify(paymentTransaction.response);
			pymtEventObj['custrecord_vdsa_raw_request'] = JSON.stringify(paymentTransaction.request);
			pymtEventObj['custrecord_vdsa_event_resp_code'] = paymentTransaction.response.code;
			pymtEventObj['custrecord_vdsa_event_pymt_status'] = '';
			pymtEventObj['custrecord_vdsa_reason_code'] = '';
			pymtEventObj['custrecord_vdsa_event_message'] = '';

			var paymentTxnBody;
			var paymentResult;
			try{
				paymentTxnBody = JSON.parse(paymentTransaction.response.body);
				paymentResult = paymentTxnBody.result;
			} catch (err) {} // ignore SyntaxError
			if (!!paymentResult && paymentTransaction.response.code == 200){
				pymtEventObj['custrecord_vdsa_event_id'] = paymentResult.transactionRequestId;
				pymtEventObj['custrecord_vdsa_event_authorized_amount'] = (paymentResult.amount/100).toFixed(2); // amount is in cents
				pymtEventObj['custrecord_vdsa_request_date_time'] = paymentResult.transactionRequestedAt;
				pymtEventObj['custrecord_vdsa_event_prcsr_resp_code'] = paymentResult.transactionStatus;
				pymtEventObj['custrecord_vdsa_request_token'] = paymentResult.creditCardId;
				pymtEventObj['custrecord_vdsa_event_date_done'] = paymentResult.actualTransactionDoneAt;
				pymtEventObj['custrecord_vdsa_reason_code'] = paymentResult.responseCode;
				pymtEventObj['custrecord_vdsa_event_message'] = paymentResult.responseDescription;
				pymtEventObj['custrecord_vdsa_event_reconciliation_id'] = paymentResult.traceNumber;
				pymtEventObj['custrecord_vdsa_merch_reference_code'] = paymentResult.sourceSenderName;
				pymtEventObj['custrecord_vdsa_event_error'] = paymentResult.error;
				pymtEventObj['custrecord_vdsa_event_error_desc'] = paymentResult.errorDescription;
			} else {
				if (!!paymentResult && !!paymentResult.errors){
					//errors[{code,message}]
					var errorCode = ''
					var errorMessage = ''
					var delimeter = (paymentResult.errors.length > 1) ? '; ' : '';
					paymentResult.errors.forEach(function(err){
						errorCode += err.code + delimeter;
						errorMessage += err.message + delimeter;
					});
					pymtEventObj['custrecord_vdsa_event_error'] = errorCode;
					pymtEventObj['custrecord_vdsa_event_error_desc'] = errorMessage;
				} else {
					pymtEventObj['custrecord_vdsa_event_error_desc'] = paymentTransaction.response.body;
				}
			}

			return pymtEventObj;
		}

		/**
		 * Function for creating payment events record for the bill payment processed.
		 * this will store the response from the payment endpoints to allow end users identify the error.
		 */
		function createPaymentEvent(pymtEventObj) {

			var pymtEventRec = record.create({
				type: 'customrecord_vdsa_pymt_event'
			});

			for (var key in pymtEventObj) {
				pymtEventRec.setValue({
					fieldId: key,
					value: pymtEventObj[key]
				});
			}

			var pymtEventRecId = pymtEventRec.save();
			return pymtEventRecId;
		}

		/**
		 * This is a reusable function for looking up values.
		 * recordId is the internal id of the record, fieldsArr are the internal ids of the field.
		 */
		function lookupValues(recordId, fieldsArr, recType) {

			var lookupFieldsObj = search.lookupFields({
				type: recType,
				id: recordId,
				columns: fieldsArr
			});

			return lookupFieldsObj;
		}

		/**
		 * Function for getting the error mapping of the error codes.
		 * this will be used for the handling of the payment record depending on the error code.
		 */
		function getActionForResponse(responseCode) {
			if (responseCode != '') {
				var responseSearch = search.create({
					type: 'customrecord_vdsa_response_code',
					columns: ['custrecord_vdsa_response_type', 'custrecord_vdsa_response_description'],
					filters: [
						['formulatext: {custrecord_vdsa_response_code}','is',responseCode]
					]
				});
				var responseResult = responseSearch.run().getRange({
					start: 0,
					end: 1
				});
				
				if (responseResult.length > 0) {
					responseType = responseResult[0].getValue({ name: 'custrecord_vdsa_response_type' });
					eventMessage = responseResult[0].getValue({ name: 'custrecord_vdsa_response_description' });
					eventStatus = responseResult[0].getText({ name: 'custrecord_vdsa_response_type' });
				} else {
					responseType = 0;
					eventMessage = 'Card Payouts Response Code is not mapped.';
					eventStatus = 'Error';
				}
	
				return {
					responseType: responseType,
					eventMessage: eventMessage,
					eventStatus: eventStatus
				};
			} else {
				return null;
			}
		}

		/*
        *This function is for sending an email to the card owner when payment is successful.
        */
		function emailNotification(preference, vendorObj, debitCardNumber, amountTotal, checkNum) {
			try {
				var vendorName = vendorObj.entityid;
				var vendorEmail = vendorObj.email;
				var vendorId = vendorObj.internalid[0].value;
				var emailBody = emailParser(preference.custrecord_vdsa_email_body_payment, vendorName, debitCardNumber, amountTotal, checkNum, preference.custrecord_vdsa_card_sender_email);
				var emailSubject = emailParser(preference.custrecord_vdsa_email_subj_payment, vendorName, debitCardNumber, amountTotal, checkNum, preference.custrecord_vdsa_card_sender_email);
				var senderId = preference.custrecord_vdsa_email_author_payment[0].value;
				var sendEmailCheckbox = preference.custrecord_vdsa_card_payment_email;
				var senderHasEmail = false;

				if (!!senderId) {
					var senderSearch = search.lookupFields({
						type: 'employee',
						id: senderId,
						columns: ['email']
					});

					if (!!senderSearch.email) {
						senderHasEmail = true;
					}
				}

				if (!!senderHasEmail && !!sendEmailCheckbox && !!vendorEmail && !!emailBody && !!emailSubject) {
					email.send({
						author: senderId,
						recipients: vendorId,
						subject: emailSubject,
						body: emailBody
					});
					log.debug('email sent to', vendorEmail);
					log.debug('email sent from', senderId);
				}
			} catch (err) {
				log.error('Error Encountered - Email Notification', JSON.stringify(err));
			}
		}

		function emailParser(emailText, vendorName, cardNumber, amountTotal, checkNum, merchantName) {
			var emailParsed = emailText;

			emailParsed = emailParsed.replace(/{vendorName}/g, vendorName);
			emailParsed = emailParsed.replace(/{cardNumber}/g, cardNumber);
			emailParsed = emailParsed.replace(/{amountTotal}/g, amountTotal);
			emailParsed = emailParsed.replace(/{checkNumber}/g, checkNum);
			emailParsed = emailParsed.replace(/{companyName}/g, merchantName);

			return emailParsed;
		}

		return {
			onAction: onAction
		};

	});
