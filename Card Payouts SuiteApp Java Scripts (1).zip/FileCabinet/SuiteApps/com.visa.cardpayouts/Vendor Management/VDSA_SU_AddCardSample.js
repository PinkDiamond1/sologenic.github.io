/**
 * @NApiVersion 2.x
 * @NScriptType Suitelet
 * @NModuleScope SameAccount
 */

define(['N/ui/serverWidget'],

    function(serverWidget) {

        //The main function for Receiving response
        function onRequest(context) {
            var form = serverWidget.createForm({
                title : 'Sample Add Card Page'
               });
            
               form.addButton({
                id : 'buttonid',
                label : 'Register'
               });
            
			form.addButton({
                id : 'buttonid1',
                label : 'Cancel'
               });
          
              form.addField({
              id : 'custpage_firstname',
            type : serverWidget.FieldType.TEXT,
           label : 'First Name'
              });
          
          form.addField({
              id : 'custpage_lastname',
            type : serverWidget.FieldType.TEXT,
           label : 'Last Name'
              });
          
          form.addField({
              id : 'custpage_debitcardnumber',
            type : serverWidget.FieldType.TEXT,
           label : 'Debit Card Number'
              });
          
          form.addField({
              id : 'custpage_expiry',
            type : serverWidget.FieldType.TEXT,
           label : 'Expiry'
              });
          
          form.addField({
              id : 'custpage_cvv',
            type : serverWidget.FieldType.TEXT,
           label : 'CVV'
              });
          
          form.updateDisplaySize({
            id : 'custpage_cvv',
        height : 60,
         width : 100
            });

          
               context.response.writePage(form);
			   
        }

        return {
            onRequest: onRequest
        };

    });