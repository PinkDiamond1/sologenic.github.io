/*************************************************************
 * Script   : VDSA_MR_SendEmailToCardAboutToExpire.js
 * Abstract : Map-reduce script to send email to all vendor (card-payouts eligibile)
 *				if they have expired or expiring cards.
 * Author   : gerard.c.villasenor
 * Revision History :
 *************************************************************
 * Version * Date       * Author            * Description
 *************************************************************
 *   0.1   * 02/20/2019 * francis.robes       * Initial version
 *   1.0   * 03/07/2019 * gerard.c.villasenor * refine script formatting
 *   1.1   * 03/13/2019 * gerard.c.villasenor * added annotations
 *   2.0   * 04/02/2019 * gerard.c.villasenor * added validations when vendor has no email.
 *   2.1   * 04/15/2020 * darryl.d.caparas    * added 1st and 15th deployment, added dynamic values
 *************************************************************/
/**
 * @NApiVersion 2.x
 * @NScriptType MapReduceScript
 * @NModuleScope SameAccount
 */
define(['N/search', 'N/record', 'N/email', 'N/log', 'N/runtime','N/url'],

function(search, record, email, log, runtime, url) {
   
    /**
     * Process the data from the expired credit card from the saved search.
     * Marks the beginning of the Map/Reduce process and generates input data.
     *
     * @typedef {Object} ObjectRef
     * @property {number} id - Internal ID of the record instance
     * @property {string} type - Record type id
     *
     * @return {Array|Object|Search|RecordRef} inputSummary
     * @since 2015.1
     */
    function getInputData() {

			var scriptObj = runtime.getCurrentScript();

			var searchId = scriptObj.getParameter({
				name: 'custscript_vdsa_card_near_expiration'
			});
			
			var mySearch = search.load({
				id: searchId
			});

		return mySearch;
    }

    /**
     * Mapping of key value pair of the credit card details.
     * Executes when the map entry point is triggered and applies to each key/value pair.
     *
     * @param {MapSummary} context - Data collection containing the key/value pairs to process through the map stage
     * @since 2015.1
     */
    function map(context) {
			
		var jsonObj = JSON.parse(context.value);
		
		context.write({
			key: jsonObj.id,
			value: jsonObj
		});
    }

    /**
     * Sending of email to card owner for their visa direct.
     * Executes when the reduce entry point is triggered and applies to each group.
     *
     * @param {ReduceSummary} context - Data collection containing the groups to process through the reduce stage
     * @since 2015.1
     */
    function reduce(context) {
		
		var preferenceRecord = runtime.getCurrentScript().getParameter({name: 'custscript_vdsa_preference_record'}),
			getPreference = preferenceSearch(preferenceRecord),
			scriptObj = runtime.getCurrentScript(),
			jsonObj = JSON.parse(context.values[0]),
			recipients = parseInt(jsonObj.values.custrecord_vdsa_debit_card_owner.value),
			names = jsonObj.values.custrecord_vdsa_debit_card_owner.text,
			number = jsonObj.values.custrecord_vdsa_debit_card_number,
			expiry = jsonObj.values.formulatext,
			author,
			notifEnabled,
			merchantName,
			subject,
			body;
		var cardPayoutsLink = getUrl();
			
		if(!!getPreference){
			author = getPreference.custrecord_vdsa_email_author_expiration[0].value;
			notifEnabled = getPreference.custrecord_vdsa_card_expiration_email;
			merchantName = getPreference.custrecord_vdsa_card_sender_email;
			subject = emailParser(getPreference.custrecord_vdsa_email_subj_expiration, names, number, expiry,null,null);
			body = emailParser(getPreference.custrecord_vdsa_email_body_expiration, names, number, expiry,merchantName,cardPayoutsLink);
		}


		//check if card owner is existing and preference for subject, body and notification is enabled, then process
		if(!!subject && !!body && !!notifEnabled && !!recipients){
			var recordType = 'vendor',
				recordId = recipients,
				fieldObj = ['email'];
			var vendObj = lookupValues(recordType, recordId, fieldObj);

			//checks if email of vendor is existing, then send email
			if (!!vendObj.email){

				sendEmail(author, recipients, subject, body);
			}
		}
		
		context.write({
			key: jsonObj.id,
			value: jsonObj
		});	
    }
	
    /**
     * Processes any error caught on the other statges
     * Executes when the summarize entry point is triggered and applies to the result set.
     *
     * @param {Summary} summary - Holds statistics regarding the execution of a map/reduce script
     * @since 2015.1
     */
    function summarize(summary) {
		
		if (summary.inputSummary.error){
			log.error('Data extraction failed', summary.inputSummary.error);
		}
					
		summary.mapSummary.errors.iterator().each(function (key, error, executionNo){
			log.error({
				title: 'Map error for key: ' + key + ', execution no. ' + executionNo,
				details: error
			});
				return true;
		});

		summary.reduceSummary.errors.iterator().each(function (key, error){
			log.error('Error sending email for debit details record ID ' + key, error);
			return true;
		});
    }
	
	

	function sendEmail(authorId, recipientId, subject, body){

		email.send({
			author: authorId,
			recipients: recipientId,
			subject: subject,
			body: body,
		});
	}

	/**
	 * This method gets the settings from the SuiteApp preference record
	 * settings for email notification enablement, author, subject and body are being retunrned by this function
	 */
	
	function preferenceSearch(preferenceId){

		if(!!preferenceId){
			var preferenceSearchResult = search.lookupFields({
				type: 'customrecord_vdsa_suiteapp_preference',
				id: preferenceId,
				columns: ['custrecord_vdsa_email_author_expiration', 'custrecord_vdsa_card_expiration_email', 'custrecord_vdsa_email_body_expiration', 'custrecord_vdsa_email_subj_expiration','custrecord_vdsa_card_sender_email']
			});
			return preferenceSearchResult;
		}
		else{
			return null;
		}
	}

	/**
	 * Function for replacing the email template set on the suiteapp preference
	 * replaces the value indicated for vendor name, card number and expiration date.
	 */

	function emailParser(emailText, vendorName, cardNumber, expirationDate, merchantName,cardPayoutsLink){
		var emailParsed = emailText;
		
		if(!!emailParsed){
			emailParsed = emailParsed.replace(/{vendorName}/g, vendorName);
			emailParsed = emailParsed.replace(/{cardNumber}/g, cardNumber);
			emailParsed = emailParsed.replace(/{expirationDate}/g, expirationDate);
			if(!!merchantName){
				emailParsed = emailParsed.replace(/{companyName}/g, merchantName);
			}else{
				emailParsed = emailParsed.replace(/{companyName}/g, 'Card Payouts');
			}
			if(!!cardPayoutsLink){
				emailParsed = emailParsed.replace(/{cardPayoutsLink}/g, cardPayoutsLink);
			}else{
				emailParsed = emailParsed.replace(/{cardPayoutsLink}/g, 'netsuite.com');
			}
			return emailParsed;
		}
		else{
			return null;
		}
		
	}

	/**
	 * Function for looking up values
	 * this will return the object result of the lookup values
	 */
	 function lookupValues(recordType, recordId, fieldObj){

	 	var lookUpObj = search.lookupFields({
            type: recordType,
            id: recordId,
            columns: fieldObj
        });

 		return lookUpObj;
	 }

	 function getUrl(){
		var output = url.resolveScript({
			scriptId: 'customscript_vdsa_payment_preference_sl',
			deploymentId: 'customdeploy_vdsa_payment_preference_sl',
			returnExternalUrl: false
			});
		return output;
	}

    return {
        getInputData: getInputData,
        map: map,
        reduce: reduce,
        summarize: summarize
    };
    
});
