/**********************************************************************************************
 * Script 	: VDSA_PL_ManageCardOptions.js
 * Abstract : Creates a Portlet for vendor card option tile buttons
 * Author 	: jordan.k.johnson
 * Revision History :
 **********************************************************************************************
 * Version     * Date         * Author  	          * Description
 **********************************************************************************************
 *   0.1	   * 03/14/2019	  * jordan.k.johnson       * Initial version
 *   0.2	   * 04/04/2019	  * jordan.k.johnson       * Added vendor dropdown
 *   0.3	   * 04/22/2019	  * jayzar.n.estareja      * Updated vendor search filters
 *   0.4	   * 11/13/2019	  * jayzar.n.estareja      * Applied fix for jQuery bug in v2019.2:
 *                                                       -removed jQuery library references
 *                                                       -moved autocomplete code to CS script
 *   0.5       * 01/18/2020   * jayzar.n.estareja      * Integration - add feature & iframe pre-population
 *   0.6       * 01/21/2020   * jayzar.n.estareja      * Remove update feature
 *   0.7       * 03/04/2020   * jayzar.n.estareja      * update loading ui
 *   0.8       * 03/18/2020   * jayzar.n.estareja      * minor ui tweak
 *   0.9       * 03/30/2020   * jayzar.n.estareja      * Update Iframe API
 **********************************************************************************************/

/**
 *@NApiVersion 2.0
 *@NModuleScope Public
 *@NScriptType Portlet
 */

define(['N/ui/serverWidget', 'N/runtime', 'N/file', 'N/error', 'N/search'],
    function(serverWidget, runtime, file, error, search) {
	
		const APP_ID = 'com.visa.cardpayouts';
		const MAX_SEARCH_RESULT = 1000;
	
        /**
        * This function will carry out creation of the form
        * 
        */
        function render(context) {
            var scriptObj = runtime.getCurrentScript();
            
            // If set to true, will display all reports/searches from dropdown rather than separate buttons
            var dropdownCheckbox = scriptObj.getParameter({name: 'custscript_vdsa_portlet_dropdown'});
            var enlargeCheckbox = scriptObj.getParameter({name: 'custscript_vdsa_portlet_enlarge_tiles'});
            var addText = scriptObj.getParameter({name: 'custscript_vdsa_portlet_addbtn_text'});
        	var deleteText = scriptObj.getParameter({name: 'custscript_vdsa_portlet_delbtn_text'});
            // var updateText = scriptObj.getParameter({name: 'custscript_vdsa_portlet_updbtn_text'});
            var reportLinks = scriptObj.getParameter({name: 'custscript_vdsa_portlet_reports'});
            
            try {
                var addButtonText = (addText ? addText : 'Add Debit Details')
                var deleteButtonText = (deleteText ? deleteText : 'Unenroll Debit Details')
                // var updateButtonText = (updateText ? updateText : 'Update Card')
                
                var reportDropdownString = '';
                var reportButtons = '';
                
                var links = getLinks(reportLinks);
                var buttonBreak = '<br/>';
                
                // Small: 125x105, Large: 150x125
                if (enlargeCheckbox) {
                    var height = 125;
                    var width = 150;
                    buttonBreak = '<br/><br/>';
                }
                else {
                    var height = 105;
                    var width = 125;
                }
                
                var divHeight = (height + 100);
                if (links.reportNum > 1 && links.reportNum < 9) divHeight += 100;
                
                if (!dropdownCheckbox && links.reportNum >= 9) {
                    divHeight += 100;
                    var linkNum = links.reportNum + 3; // Number of all links/buttons
                    var rowNum = Math.floor(linkNum / 7);
                    divHeight += ((height + 20) * rowNum);
                }
                
                for (var i = 1; i <= links.reportNum; i++) {            	
                    if (dropdownCheckbox) {
                        reportDropdownString += "<li><a class='dropdown-item' href='" + links.reports[(i-1)] + "'  target='_top'>Report #" + i + "</a></li>";
                        divHeight += 10; // Increase div height so that dropdown will not be cut off
                    }
                    else {
                        reportButtons += "<a href='" + links.reports[(i-1)] + "' class='btn btn-sq-lg btn-default' style='width:" + width + "px;height:" + height + "px;margin-bottom:4px;' target='_top'>"
                        + "<i class='fa fa-file-text fa-5x icon-black'></i>" + buttonBreak + "Report #" + i + "</a>&nbsp;&nbsp;&nbsp;"
                    }
                }
            }
            catch(e) {
                throw error.create({
                    name: 'Portlet Error',
                    message: 'Error rendering portlet: ' + e.message
                })
            }
            
          try {
          	  var portlet = context.portlet;
              portlet.title = 'Card Payouts Preference';

              portlet = addCustomUIAssets(portlet);

              var popupHtml = "<style>.dataTables_wrapper {font-size: 10px;}</style>"
              + "<div id='dialog' title='Select a Card' style='display:none;'>"
              + "<font style='font-size:12px;'>Please select a card</font>"
              + "&nbsp;&nbsp;"
              + "<button type='button' id='submissionButton' class='blueBgNS' style='margin-bottom:7px;' disabled>Submit</button>"
              + "<div class = \"table-responsive\"><table id=\"debitDetails\" class=\"display compact\" style=\"width:100%;\">"
              + "</table></div>"
              + "</div>";           

              var popup = portlet.addField({
                  id: 'custpage_popup',
                  type: serverWidget.FieldType.INLINEHTML,
                  label: 'Popup'
              });

              popup.defaultValue = popupHtml;
              
              var contentDropdown = '';
            	
              if (dropdownCheckbox && links.reportNum > 0) {
            	  contentDropdown = "<div class='dropdown' style='display:inline-block;'>"
                  + "<button class='btn btn-default dropdown-toggle' style='width:" + width + "px;text-align:center;height:" + height + "px;margin-bottom:4px;' href='#' type='button' id='dropdownMenuLink' data-toggle='dropdown' aria-haspopup='true' aria-expanded='false'>"
                  + "<i class='fa fa-file-text fa-5x icon-black'></i>" + buttonBreak + "Reports"
                  + "</button> <ul class='dropdown-menu' aria-labelledby='dropdownMenuLink' style='z-index: 1;position: relative;'>"
                  + reportDropdownString // Will display all reports returned from custom list
                  + "</ul></div>";
              }
              
              /* JNE - jQuery library bugfix - below code moved to CS script.
              var vendorNames = new Array();
              
              var vendorSearch = search.create({
            	  type: record.Type.VENDOR,
            	  filters: [
            		  ['isinactive', search.Operator.IS, 'F'],
					  'AND',
					  ['custentity_vdsa_visa_direct_eligible', search.Operator.IS, 'T']
            	  ],
            	  columns: [
            		  {name: 'companyname', label: 'Name'},
            		  {name: 'internalid', label: 'Internal ID'}
            	  ]
              });
              try {
            	  var vendorSearchResults = vendorSearch.run().getRange(0,1000);
              }
              catch(e) {
            	  log.error('Error getting vendor search results', e.message);
              }
              
              for(var i = 0; i < vendorSearchResults.length; i++) {
            	  var vendorName = vendorSearchResults[i].getValue('companyname');
            	  var internalId = vendorSearchResults[i].getValue('internalid');
            	  vendorName = vendorName.replace("'","");
            	  if (vendorName.length > 2) vendorNames.push("{value: " + internalId + ", label: '" + vendorName + "'}");
              }
              
              var vendorNamesStr = vendorNames.toString();*/
              var content;
              var currentUser = runtime.getCurrentUser();
              var currentUserCenter = currentUser.roleCenter;
              
              var autoCompleteField = '';
              var vendorDetails = ''
              if (currentUserCenter != 'VENDOR') {
                  /* JNE - jQuery library bugfix - below code moved to CS script.
                  autoCompleteField = "<div class='form-group'><input class='form-control autocomplete' id='vendorId' placeholder='Enter Vendor Name' /></div>"
				  + "<script> var vendorNames = [" + vendorNamesStr + "];"
                  + "jQuery('.autocomplete').autocomplete({"
                  + "source: vendorNames "
                  + "}); </script>";*/
				  autoCompleteField = "<div class='form-group'><input class='form-control autocomplete' id='vendorId' placeholder='Enter Vendor Name' /></div>";
              }else{
                vendorLookup = search.lookupFields({
                    type: search.Type.VENDOR,
                    id: currentUser.id,
                    columns: [
                        'firstname',
                        'lastname',
                        'billzipcode'
                        // 'email',
                        // 'phone',
                        // 'billaddress1',
                        // 'billaddress2',
                        // 'billcity',
                        // 'billstate',
                        // 'billcountrycode'
                    ]
                });
                vendorDetails = "<span id='vendorLookup' style='display:none'>"+JSON.stringify(vendorLookup)+"</span>"
              }
              
              var loadingHtml = '<div class="loading" style="display: none;background-color: rgb(224,234,239,.75);width: 100%;height: 325px;position:fixed;padding-top: 145px;z-index:101;">'
              + '<div style="width: 30px;margin: auto;">'
              + '<svg viewBox="-18 -18 36 36" role="img" aria-label="Loading" style="stroke-width: 3px;stroke-dashoffset: 75;animation: spin 2s ease infinite;">'
              + '<circle fill="none" r="16" style="stroke: rgba(96,119,153,0.70);"></circle>'
              + '<circle fill="none" r="16" transform="rotate(-135)" stroke-dasharray="100" style="stroke: #24385B;"></circle>'
              + '</svg></div></div>'

              try {
                content = loadingHtml
                + "<p class='bg-warning'>Welcome, " + runtime.getCurrentUser().name.split(' ').shift() + ".</p>"
                + "<p class='bg-info'>Select '" + addButtonText + "' to enroll a vendor for Card Payouts.</p>"
                + autoCompleteField // Add if context is non-vendor one
                + vendorDetails // Add if user is a vendor
                /*+ "<div class='container-fluid theme-showcase' role='main' width='100%' height='100%'><div style='overflow:auto;height:" + divHeight + "px;'><div style='float:left;'>"
                + "<img src='" + logo + "' style='margin-top:20px;margin-right:20px;' width='475' height='50'></img></div><div>"
                + "<button type='button' id='addDebitDetails' class='btn btn-sq-lg btn-default' style='width:" + width + "px;height:" + height + "px;margin-bottom:4px;' target='_top'>"
                + "<i class='fa fa-plus fa-5x icon-black'></i>" + buttonBreak + addButtonText + "</button>&nbsp;&nbsp;&nbsp;"
                // + "<button type='button' id='updateDebitDetails' class='btn btn-sq-lg btn-default' style='width:" + width + "px;height:" + height + "px;margin-bottom:4px;' target='_top'>"
                // + "<i class='fa fa-cog fa-5x icon-black'></i>" + buttonBreak + updateButtonText + "</button>&nbsp;&nbsp;&nbsp;"
                + "<button type='button' id='unenrollDebitDetails' class='btn btn-sq-lg btn-default' style='width:" + width + "px;height:" + height + "px;margin-bottom:4px;' target='_top'>"
                + "<i class='fa fa-minus fa-5x icon-black'></i>" + buttonBreak + deleteButtonText + "</button>&nbsp;&nbsp;&nbsp;"*/
                + "<div role='main' width='100%' height='100%'><div style='height:" + divHeight + "px;'>"
                + "<button type='button' id='addDebitDetails' class='blueBgNS' style='margin-right:15px' target='_top'>" + addButtonText + "</button>"
                + "<button type='button' id='unenrollDebitDetails' class='blueBgNS' target='_top'>" + deleteButtonText + "</button>"
                + contentDropdown
                + reportButtons
                // + "</div></div></div>";
                + "</div></div>";
              }
              catch(e) {
                throw error.create({
                    name: 'Portlet Error',
                    message: 'Error rendering portlet: ' + e.message
                });
              }
              
              portlet.clientScriptModulePath = './VDSA_CS_ManageCardOptions.js';
                        
              // External libraries
              //portlet = addCDNCSSorJS(portlet, 'js1', 'https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js', 'text/javascript');
              portlet = addCDNCSSorJS(portlet, 'js2', 'https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.3.2/js/bootstrap.js', 'text/javascript');
              //portlet = addCDNCSSorJS(portlet, 'js3', 'https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.js', 'text/javascript');
              portlet = addCDNCSSorJS(portlet, 'css1', 'https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css', 'text/css');
              portlet = addCDNCSSorJS(portlet, 'css2', 'https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css', 'text/css');
              portlet = addCDNCSSorJS(portlet, 'css3', 'https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap-theme.min.css', 'text/css');
              portlet = addCDNCSSorJS(portlet, 'css4', 'https://netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.min.css', 'text/css');
              //portlet = addCDNCSSorJS(portlet, 'css5', 'https://cdn.datatables.net/1.10.19/css/dataTables.jqueryui.min.css', 'text/css');
              //portlet = addCDNCSSorJS(portlet, 'js4', 'https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js', 'text/javascript');
              //portlet = addCDNCSSorJS(portlet, 'js5', 'https://cdn.datatables.net/1.10.19/js/dataTables.jqueryui.min.js', 'text/javascript');
              //portlet = addCDNCSSorJS(portlet, 'js6', 'https://cdn.datatables.net/select/1.3.0/js/dataTables.select.min.js', 'text/javascript');
			  portlet = addCDNCSSorJS(portlet, 'css5', 'https://cdn.datatables.net/v/ju/dt-1.10.19/sl-1.3.0/datatables.min.css', 'text/css');

              var newField = portlet.addField({
                  id: 'custpage_form',
                  type: serverWidget.FieldType.INLINEHTML,
                  label: 'Card Preferences'
              });
              
              newField.defaultValue = content;
          }
          catch(e){
              throw error.create({
                  name: 'Portlet Error',
                  message: 'Error rendering portlet: ' + e.message
              })
          }
      }
        
      function addCDNCSSorJS(form, fieldID, fileURL, type){
    	  var addedField = form.addField({
        	  id: fieldID,
        	  type: serverWidget.FieldType.INLINEHTML
          });
    	  
    	  var incType = '';
    	  var endTag = '';
    	  if (type == 'text/javascript') {
    		  incType = '<script src="';
    		  endTag = '</script>';
    	  }
    	  else {
    		  incType = '<link rel="stylesheet" href="';
    	  }
          
          addedField.defaultValue = incType + fileURL +'" type="' + type + '" ' + '>' + endTag;
          
          return form;
      }
      
      /**
       * Adds custom form elements to the form from the assets folder
       * @param {nlobjForm} visaForm NetSuite form object passed in and then returned after being mutated with custom asset data
       */
      function addCustomUIAssets(visaForm) {
          try {
              var bundleFolderSearch = search.create({
                  type: "folder",
                  filters: [
                      ["name", "is", APP_ID]
                  ]
              }).run().getRange(0, MAX_SEARCH_RESULT);

              if (bundleFolderSearch.length !== 1) {
                  throw error.create({ name: 'FOLDER ERROR', message: 'ANOTHER FOLDER HAS UTILIZED THIS SUITEAPP\'S PUBLISHER ID', notifyOff: false });
              }

              var bundleFolderId = bundleFolderSearch[0].id;
              var assetResults = search.create({
                  type: "file",
                  filters: [
                      ["folder", "anyof", bundleFolderId],
                      "AND",
                      ["formulatext: {folder}", "is", "Vendor Management Custom Assets"],
                  ],
                  columns: [
                      'name',
                      'filetype'
                  ]
              }).run().getRange(0, MAX_SEARCH_RESULT);

              var assetObj = assetResults.map(function(currentValue) {
                  return {
                      id: currentValue.id,
                      name: currentValue.getValue({ name: 'name' }),
                      type: currentValue.getValue({ name: 'filetype' }),
                  };
              });

              for (var assetIndex = 0; assetIndex < assetObj.length; assetIndex++) {
                  var assetFile = file.load({
                      id: assetObj[assetIndex].id
                  });
                  log.debug('assetObj', JSON.stringify(assetObj[assetIndex]));

                  // remove extension and prepend custpage to dynamically create field id
                  var assetFieldId = assetObj[assetIndex].name;
                  assetFieldId = assetFieldId.replace('.', '_');
                  assetFieldId = ('custpage_' + assetFieldId).toLowerCase();

                  assetFile.getContents();
                  var assetField = visaForm.addField({
                      id: assetFieldId,
                      type: serverWidget.FieldType.INLINEHTML,
                      label: '(Hidden) Asset field for ' + assetObj[assetIndex].name
                  })

                  switch (assetObj[assetIndex].type) {
                      case 'STYLESHEET': // CSS files
                          assetField.defaultValue = '<style>' + assetFile.getContents() + '</style>';
                          break;                     
                      default:
                          assetField.defaultValue = assetFile.getContents();
                  }
              }

          } catch (errorObj) {
              throw error.create({
                  name: 'ASSET_LOOKUP_FAILURE',
                  message: errorObj.message,
                  notifyOff: true
              });
          }

          return visaForm;
      }

      /**
      * Retrieve relevant portlet links
      */
      function getLinks(reportLinks){
        if (reportLinks) {
            var reportArr = reportLinks.split(',');
            var reportNum = reportArr.length;
        }
        else {
            var reportArr = [];
            var reportNum = 0;
        }

        var scriptObj = runtime.getCurrentScript();
        var addLink = scriptObj.getParameter({name: 'custscript_vdsa_portlet_addbtn_link'});
        var deleteLink = scriptObj.getParameter({name: 'custscript_vdsa_portlet_delbtn_link'});
        // var updateLink = scriptObj.getParameter({name: 'custscript_vdsa_portlet_updbtn_link'});

        var suiteletLink = '#';

        var addLinkVal = (addLink ? addLink : suiteletLink);
        var deleteLinkVal = (deleteLink ? deleteLink : suiteletLink);
        // var updateLinkVal = (updateLink ? updateLink : suiteletLink);

        var links = {
        	addLink: addLinkVal,
            deleteLink: deleteLinkVal,
            // updateLink: updateLinkVal,
            reportNum: reportNum,
            reports: reportArr
        };
        	
        log.debug('Links returned for portlet', JSON.stringify(links));
        return links;
      }

      return {
          render: render
      };
  });