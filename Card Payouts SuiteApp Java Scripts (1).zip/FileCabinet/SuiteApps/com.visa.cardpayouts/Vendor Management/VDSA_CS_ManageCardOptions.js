/**********************************************************************************************
 * Script 	: VDSA_CS_ManageCardOptions.js
 * Abstract : Button actions for the Card Payout Portlet
 * Author 	: jordan.k.johnson
 * Revision History :
 **********************************************************************************************
 * Version     * Date         * Author  	          * Description
 **********************************************************************************************
 *   0.1	   * 03/14/2019	  * jordan.k.johnson       * Initial version
 *   0.2	   * 11/13/2019	  * jayzar.n.estareja      * Applied fix for jQuery bug in v2019.2:
 *                                                       -added jQuery libraries at NAmdConfig
 *                                                       -replaced all '$' with 'jQuery'
 *                                                       -added autocomplete source from PL script
 *                                                       Code cleanup
 *   0.3       * 01/08/2020   * jayzar.n.estareja      * Integration - add feature
 *   0.4       * 01/18/2020   * jayzar.n.estareja      * Integration - iframe pre-population
 *   0.5       * 01/21/2020   * darryl.d.caparas       * Integration - unenroll feature
 *   0.6       * 01/21/2020   * jayzar.n.estareja      * Remove update feature
 *   0.7       * 01/28/2020   * darryl.d.caparas       * Added Vendor Name if type is Individual
 *   0.8       * 03/02/2020   * jayzar.n.estareja      * Remove card payouts enrolled filter
 *   0.9       * 03/18/2020   * jayzar.n.estareja      * minor datatable and ui tweak
 *   0.10      * 03/30/2020   * jayzar.n.estareja      * Update Iframe API
 **********************************************************************************************/

/**
 * @NApiVersion 2.x
 * @NScriptType ClientScript
 * @NModuleScope SameAccount
 * @NAmdConfig ./VDSA_Config_Portlet.json
 */

 define(['N/url', 'N/runtime', 'N/search', 'N/format', '../Library/VDSA_LIB_constantsFile.js', 'N/https', 'N/record', 'jquery_ui', 'datatables', 'datatables_select'],

    function(url, runtime, search, format, VDSA_CONST, https, record, jquery_ui, datatables, datatables_select) {
        var currentVendor;
        const EXPIRATION_DATE_FIELD_LENGTH = 7;
        var selectedDetails;
        var fwdToSuitelet = false;
        var alreadySelected = false;

        function pageInit(context) {
			var currentUser = runtime.getCurrentUser();
            var currentUserCenter = currentUser.roleCenter;
			if(currentUserCenter == 'VENDOR'){
				currentVendor = currentUser.id;
			}
			
            selectedDetails = {
                lineCount: '',
                lineNumber: '',
                debitId: '',
                detailType: '',
                cardType: ''
            };

        	document.getElementById("addDebitDetails").onclick = function() {addToken(fwdToSuitelet)};
    	    // document.getElementById("updateDebitDetails").onclick = function() {updateDebitDetail(fwdToSuitelet)};
            document.getElementById("unenrollDebitDetails").onclick = function() {unenrollDebitDetail(fwdToSuitelet)};
			
			if(currentUserCenter == 'VENDOR'){
				var debitDetails = loadDebitDetails(currentVendor);
                loadDataTable(debitDetails);
				return false;
            }
            
            // JNE - jQuery library bugfix - START - below code moved from PL script.
            var vendorNames = new Array();
              
            var vendorSearch = search.create({
                type: record.Type.VENDOR,
                filters: [
                    ['isinactive', search.Operator.IS, 'F']
                    // ,'AND',
                    // ['custentity_vdsa_visa_direct_eligible', search.Operator.IS, 'T']
                ],
                columns: [
                    {name: 'companyname', label: 'Name'},
                    {name: 'firstname', label:'First Name'},
                  	{name: 'lastname', label:'Last Name'},
                  	{name: 'isperson', label:'Type'},
                    {name: 'internalid', label: 'Internal ID'}
                ]
            });
            try {
                var vendorSearchResults = vendorSearch.run().getRange(0,1000);
            }
            catch(e) {
                log.error('Error getting vendor search results', e.message);
            }
            
            for(var i = 0; i < vendorSearchResults.length; i++) {
                var vendorType = vendorSearchResults[i].getValue('isperson');
              	if (vendorType == true){
                    var vendorName = vendorSearchResults[i].getValue('firstname') +' '+ vendorSearchResults[i].getValue('lastname');
                }
              	else{
                    var vendorName = vendorSearchResults[i].getValue('companyname');
                }
                var internalId = vendorSearchResults[i].getValue('internalid');
                vendorName = vendorName.replace("'","");
                if (vendorName.length > 2) vendorNames.push({value: internalId, label: vendorName});
            }
            // JNE - jQuery library bugfix - END

	    	jQuery('.autocomplete').autocomplete({
                source: vendorNames, // JNE - jQuery library bugfix - code moved from PL script.
	    		select: function(event, ui) 
	    		{
                    // Destroy table if it already exists before another once is created
                    if (alreadySelected) {
                        try {
                            var table = jQuery('#debitDetails').DataTable();
                            table.destroy(false); // JNE - changed to 'false' as it's removing the table element as well causing followings code to not work as expected.
                        }
                        catch(e) {
                            console.log('Error destroying datatable: ' + String(e));
                        }
                    }

                    alreadySelected = true;

	    			currentVendor = ui.item.value;
                    var debitDetails = loadDebitDetails(currentVendor);
                    loadDataTable(debitDetails);
	    			return false;
	    	    },
	    	    focus: function(event, ui)
    			{
    				jQuery('#vendorId').val(ui.item.label);
    				return false;
                },
                response: function(event, ui) {
                    if (!ui.content.length) {
                        var noResult = { value:"", label:"No results found" };
                        ui.content.push(noResult);
                    }
                }
            });
    	    
			/* Remove cybersource integration 
    	    function addDebitDetail(fwdToSuitelet) {
                var vendorId = currentVendor;
                console.log('Adding debit details for vendor ID: ' + vendorId);
                var msgType = '';
                
                if (fwdToSuitelet) {
                    redirectToSuitelet();
                }
            	else {
                    var suiteletURL = url.resolveScript({
                        scriptId: 'customscript_vdsa_payment_preference_sl',
                        deploymentId: 'customdeploy_vdsa_payment_preference_sl',
                        returnExternalUrl: false,
                        params: {
                            'vendorId': vendorId,
                            'msgType': msgType,
                            'msgAction': msgAction
                        }
                    });

                    var params = {
                        functionCommand: 'CREATE_SECURE_ACCEPTANCE_HOSTED_CHECKOUT_CREATE_TOKEN_FORM',
                        vendorId: vendorId,
                        suiteletRedirectURL: suiteletURL
                    };
                    redirectToTokenForm(params);
                }
            }*/

            /* Remove update feature
            function updateToken() {
                var lineDetail = selectedDetails;
                var tokenId = selectedDetails.debitId;
                var onClickDialog;
                var vendorId = currentVendor;

                if (tokenId === '') {
                    createCustomDialog('No token selected...', 'Please select a token to update.', onClickDialog, false);
                } else {
                    const EXPIRATION_DATE_FIELD_LENGTH = 7;
                    // intentionally set as a global
                    window.autoFillVendorMappingObj = {
                        custrecord_vdsa_debit_first_name: {
                            formName: 'bill_to_forename',
                            label: 'First Name',
                            required: false,
                        },
                        custrecord_vdsa_debit_last_name: {
                            formName: 'bill_to_surname',
                            label: 'Last Name',
                            required: false,
                        },
                        custrecord_vdsa_debit_company: {
                            formName: 'bill_to_company_name',
                            label: 'Company Name',
                            required: false,
                        },
                        custrecord_vdsa_debit_billing_address1: {
                            formName: 'bill_to_address_line1',
                            label: 'Address',
                            required: true,
                        },
                        custrecord_vdsa_debit_billing_address2: {
                            formName: 'bill_to_address_line2',
                            label: 'Address 2',
                            required: false,
                        },
                        custrecord_vdsa_debit_phone: {
                            formName: 'bill_to_phone',
                            label: 'Phone Number',
                            required: false,
                        },
                        custrecord_vdsa_debit_email: {
                            formName: 'bill_to_email',
                            label: 'Email',
                            required: false,
                        },
                        custrecord_vdsa_debit_billing_city: {
                            formName: 'bill_to_address_city',
                            label: 'City',
                            required: true,
                        },
                        custrecord_vdsa_debit_billing_zip_code: {
                            formName: 'bill_to_address_postal_code',
                            label: 'Zip/Postal Code',
                            required: true,
                        },
                        custrecord_vdsa_debit_billing_state: {
                            formName: 'bill_to_address_state',
                            label: 'State/Province',
                            required: true,
                        },
                        custrecord_vdsa_debit_billing_country: {
                            formName: 'bill_to_address_country',
                            label: 'Country',
                            required: true,
                        },
                        custrecord_vdsa_debit_expiration_date: {
                            formName: 'card_expiry_date',
                            label: 'Expiry Date',
                            required: true
                        },
                    };
    
                    // obtain token values to update and use as an autofill
                    var tokenLookup = search.lookupFields({ id: tokenId, type: 'customrecord_vdsa_debit_details', columns: Object.keys(autoFillVendorMappingObj) });
    
                    // helper function
                    function getFormValues(tokenId, cardType) {
                        console.log('Getting form values');
                        // PURPOSEFULLY SET AS GLOBAL. only way to use event handler and have it trickle back down to netsuite function
                        window.cybersourceUpdateFormEditDetails = {};
                        var missingMandatoryFields = [];
                        for (var fieldMappingElement in autoFillVendorMappingObj) {
                            var formObj = autoFillVendorMappingObj[fieldMappingElement];
    
                            var csInputValue = jQuery('#cybersourceForm input[name=' + formObj.formName + ']').val();
                            if (csInputValue) {
                                cybersourceUpdateFormEditDetails[formObj.formName] = csInputValue;
                            } else if (formObj.required === true) {
                                missingMandatoryFields.push(formObj.label);
                            }
                        }
    
                        // manually set fields. These should be transparent to the user and are not inputted
                        cybersourceUpdateFormEditDetails.card_type = cardType.trim();
                        
                        if (missingMandatoryFields.length > 0) {
                            jQuery('#cyberSourceFormValidation > span.visa-form-text').html('Please Enter Values for all mandatory fields: ' + missingMandatoryFields.join(', '));
                        } else {
                            //triggers netsuite button and client bound function to submit to cybersource
                            jQuery('.ui-dialog-buttonset').children().eq(1).click();
                        }
    
                    }

                    function success(result) {
                        var onClickDialog;
                        createCustomDialog('Redirecting...', 'You will be redirected to a secure page to confirm card details.', onClickDialog, false);

                        var suiteletURL = url.resolveScript({
                            scriptId: 'customscript_vdsa_payment_preference_sl',
                            deploymentId: 'customdeploy_vdsa_payment_preference_sl',
                            returnExternalUrl: false
                        });
                        suiteletURL = 'https://' + runtime.accountId + '.app.netsuite.com' + suiteletURL + '&vendorId=' + vendorId;

                        var params = {
                            functionCommand: 'CREATE_SECURE_ACCEPTANCE_HOSTED_CHECKOUT_UPDATE_TOKEN_FORM',
                            tokenId: tokenId,
                            suiteletRedirectURL: suiteletURL,
                            editDetailObj: JSON.stringify(cybersourceUpdateFormEditDetails)
                        };
                        redirectToTokenForm(params);
                    }
    
                    // Create Modal //
    
                    // add header detail
                    var updateFormContent = '<div id="cybersourceForm">' +
                        '<div class="row">' +
                        '    <div id="cyberSourceFormValidation" class="col"><span class="visa-form-text"></span></div>' +
                        '</div>';
    
                    // dynamically add all inputs from object
                    var columnIndex = 0;
                    for (var fieldMappingElement in autoFillVendorMappingObj) {
                        if (columnIndex == 0) updateFormContent += '<div class="column">';
                        var formObj = autoFillVendorMappingObj[fieldMappingElement];
                        var formLabel = formObj.required === true ? formObj.label + '*' : formObj.label;
                        updateFormContent += '<div class="gridRow">' +
                            '<div class="col textSameLine"><span class="visa-form-text">' + formLabel + '</span></div>' +
                            '<div class="col textSameLine"><input class="visa-form-input" name="' + formObj.formName + '" type="text"></div><br>' +
                            '</div>';
                        columnIndex++;
                        if (columnIndex > 4) {
                            columnIndex = 0;
                            updateFormContent += '</div>';
                        }
                    }
    
                    // add buttons
                    updateFormContent += '<center><div class="uir-message-buttons"><button class="ui-button ui-corner-all ui-widget" onclick="' + getFormValues.toString() + ' getFormValues(' + tokenId + ',\'001\')" style="margin-top:25px;font-size: 18px;">Update</button></div>';
    
                    try {
                        jQuery.when(createUpdateCustomDialog('Enter all update details', updateFormContent, success, false)).then();
                    }
                    catch(e) {
                    }
    
                    // hide button that accepts form submission. Need to use our own button. Netsuite closes dialog once buttons are pressed so we need to obtain form data before this button is used
                    jQuery('.ui-dialog-buttonset').children().eq(1).hide();
    
                    //format date as MM-YYYY from token date value from lookup.
                    var expirationDate = tokenLookup['custrecord_vdsa_debit_expiration_date'];
                    expirationDate = new Date(expirationDate);
                    expirationDate = format.format({ value: expirationDate, type: format.Type.MMYYDATE });
                    tokenLookup['custrecord_vdsa_debit_expiration_date'] = expirationDate.replace('/', '-').padStart(EXPIRATION_DATE_FIELD_LENGTH, '0');
    
                    for (var fieldMappingElement in autoFillVendorMappingObj) {
                        var currentFormInput = autoFillVendorMappingObj[fieldMappingElement].formName;
                        var currentFieldValue = tokenLookup[fieldMappingElement];
                        jQuery('#cybersourceForm input[name=' + currentFormInput + ']').val(currentFieldValue);
                    }
                }
    
            }*/
    	     
    	    function unenrollDebitDetail(fwdToSuitelet) {
                var vendorId = currentVendor;
                console.log('Unenrolling debit details for vendor ID: ' + vendorId);

                if (fwdToSuitelet) {
                    redirectToSuitelet();
                }
            	else {
                    var currentUser = runtime.getCurrentUser();
                    var currentUserCenter = currentUser.roleCenter;
                    
                    if (currentUserCenter != 'VENDOR') {
                        params = {vendorId: vendorId};
                    }
                    
                    if (vendorId || currentUserCenter == 'VENDOR') {
                        if (!vendorId) vendorId = currentUser.id;
                        createDialog();

                        var button = document.getElementById('submissionButton');
                        button.onclick = function() 
                        {
                            unenrollCard(vendorId);
                        }
                    }
                    else {
                        alert('Please select a vendor before proceeding.');
                    }
                }
            }
                
            /* Remove update feature
            function updateDebitDetail(fwdToSuitelet) {
                var vendorId = currentVendor;
                console.log('Updating debit details for vendor ID: ' + vendorId);

                if (fwdToSuitelet) {
                    redirectToSuitelet();
                }
                else {
                    var currentUser = runtime.getCurrentUser();
                    var currentUserCenter = currentUser.roleCenter;
                    
                    if (currentUserCenter != 'VENDOR') {
                        params = {vendorId: vendorId};
                    }
                    
                    if (vendorId || currentUserCenter == 'VENDOR') {

                        if (!vendorId) vendorId = currentUser.id;
                        createDialog();
                        
                        var button = document.getElementById('submissionButton');
                        button.onclick = function() 
                        {
                            updateToken();
                        };
                    }
                    else {
                        alert('Please select a vendor before proceeding.');
                    }
                }
            }*/

            function redirectToSuitelet() {
                var vendorId = currentVendor;
                var currentUser = runtime.getCurrentUser();
                var currentUserCenter = currentUser.roleCenter;
                
                console.log('current user center: ' + currentUserCenter);

                var params;
                if (currentUserCenter != 'VENDOR') {
                    params = {vendorId: vendorId};
                }
                
                if (vendorId || currentUserCenter == 'VENDOR') {
                    if (!vendorId) vendorId = currentUser.id;

                    try {
                        var suiteletUrl = url.resolveScript({
                            scriptId: 'customscript_vdsa_payment_preference_sl',
                            deploymentId: 'customdeploy_vdsa_payment_preference_sl',
                            returnExternalUrl: false,
                            params: params
                        });
    
                        window.open(suiteletUrl);
                    }
                    catch(e) {
                        console.log('Issue redirecting to suitelet', e.message);
                        alert('There was an error in loading the card payouts pref. page: ' + e.message);
                    }
                }
                else {
                    alert('Please select a vendor before proceeding.');
                }
            }

            function unenrollCard(vendorId) {
                console.log('Unenrolling card for vendor ID: ' + vendorId);

                var debitId = selectedDetails.debitId;
                var lineCount = selectedDetails.lineCount;
                var detailType = selectedDetails.detailType;

                if (!!debitId) {
                    var body = {
                        vendorId: vendorId,
                        debitId: debitId,
                        functionCommand: 'UNENROLLTOKEN'
                    };

                    console.log('Detail type: ' + detailType);
                    var errorFunc;
    
                    if (detailType == '1') {
                        if (lineCount == 1) {
                            createCustomDialog('Unenrolling card', 'The selected card record will be unenrolled.', onClickDialog, true);
                        } else if (lineCount == 2) {
                            createCustomDialog('Unenrolling card', 'The selected Card record will be unenrolled. The remaining Card record will be automatically set to Primary.', onClickDialog, true);
                        } else {
                            createCustomDialog('Unenrolling card', 'Unable to unenroll the Primary Card. You must first select another Card as Primary in order to unenroll the this card.', errorFunc, true);
                        }
                    } else {
                        createCustomDialog('Unenrolling card', 'The selected card record will be unenrolled.', onClickDialog, true);
                    }
    
                    function onClickDialog(result) {
                        jQuery(".loading").show();
                        var executeResult = executeSuitelet('customscript_vdsa_backend_server_process', 'customdeploy_vdsa_backend_server_d1', null, body);
                        executeResult.then(function(result) {
                            jQuery(".loading").hide();
                            reloadPage(vendorId, 1, 6);
                        })
                        .catch(function(reason) {
                            jQuery(".loading").hide();
                            reloadPage(vendorId, 2, 6);
                        });
                    }
    
                } else {
                    createCustomDialog('Card Payouts Preference', 'You have not selected a card record to unenroll.', errorFunc, false);
                }
                
            }

            function createDialog() {
                jQuery('#dialog').dialog({
                    open: function () {
                        var win = jQuery(window);
                    
                        jQuery(this).parent().css({
                            position: 'absolute',
                            left: (win.width() - jQuery(this).parent().outerWidth()) / 2,
                            top: (win.height() - jQuery(this).parent().outerHeight()) / 2
                        });
                    }
                });
            }

            function executeSuitelet(scriptId, deploymentId, headers, reqBody) {
                var resUrl = url.resolveScript({
                    scriptId: scriptId,
                    deploymentId: deploymentId,
                    returnExternalUrl: false
                });
   
                var response = https.post.promise({ url: resUrl, body: JSON.stringify(reqBody) });
                return response;
            }

            function reloadPage(vendorId, msgType, msgAction) {

                var suiteletURL = url.resolveScript({
                    scriptId: 'customscript_vdsa_payment_preference_sl',
                    deploymentId: 'customdeploy_vdsa_payment_preference_sl',
                    returnExternalUrl: false,
                    params: {
                        'vendorId': vendorId,
                        'msgType': msgType,
                        'msgAction': msgAction
                    }
                });
   
                if (window.onbeforeunload) {
                    window.onbeforeunload = function() { null; };
                };
   
                window.open(suiteletURL);
                window.location.href = location.href;
            }
             
            function loadDebitDetails(vendorId) {
                var vendorSearch = search.create({
                    type: 'customrecord_vdsa_debit_details',
                    filters: [{name: 'custrecord_vdsa_debit_card_owner',operator: search.Operator.IS,values: vendorId},
                              {name: 'isinactive', operator: search.Operator.IS, values: 'F'}
                    ],
                    columns: [{ name: 'custrecord_vdsa_debit_type', label: 'Type', sort: search.Sort.ASC },
                        { name: 'custrecord_vdsa_debit_card_number', label: 'Debit Card Number' },
                        { name: 'custrecord_vdsa_debit_expiration_date', label: 'Expiration Date' },
                        { name: 'internalid', label: 'Internal ID' },
                        { name: 'custrecord_vdsa_debit_card_type', label: 'Card Type' }
                    ]
                });
    
                var vendorSearchRun = vendorSearch.run();
                var vendorSearchResult = vendorSearchRun.getRange(0, 1000);
                console.log('# of debit details: ' + vendorSearchResult.length);
                var data = [];
    
                for (var resultValue = 0; resultValue < vendorSearchResult.length; resultValue++) {
                    var result = vendorSearchResult[resultValue];
                    var innerTableObject = {
                        internalId: ' ',
                        expDate: ' ',
                        cardNumber: ' ',
                        cardType: ' ',
                        cardTypeId: ' ',
                        detailType: ' '
                    };
    
                    innerTableObject.internalId = result.getValue('internalid');
                    innerTableObject.cardNumber = result.getValue('custrecord_vdsa_debit_card_number');
                    innerTableObject.detailType = result.getValue('custrecord_vdsa_debit_type');
                    var cardType = result.getText('custrecord_vdsa_debit_card_type');
    
                    // Add card image
                    var cardType = result.getValue({ name: 'custrecord_vdsa_debit_card_type' });
                    var cardFieldValue = cardType;
                    // var cardFieldValue = ' ';
                    // switch (cardType) {
                    //     case VDSA_CONST.CardType['Visa']:
                    //         cardFieldValue = 'Visa';
                    //         break;
                    //     case VDSA_CONST.CardType['American Express']:
                    //         cardFieldValue = 'Amex';
                    // }
    
                    // overwrite date with formatted date
                    var expirationDate = result.getValue({ name: 'custrecord_vdsa_debit_expiration_date' });
                    expirationDate = new Date(expirationDate);
                    expirationDate = format.format({ value: expirationDate, type: format.Type.MMYYDATE });
                    expirationDate = expirationDate.replace('/', '-').padStart(EXPIRATION_DATE_FIELD_LENGTH, '0');

                    innerTableObject.cardType = cardFieldValue;
                    innerTableObject.expDate = expirationDate;
                    innerTableObject.cardTypeId = cardType;
    
                    data.push(innerTableObject);
                }
                return data;
            }

            function loadDataTable(debitDetails) {
                //Main Data Table
                var cardValues = [];

                for (var i = 0; i < debitDetails.length; i++) {
                    var tempArr = [];
                    tempArr.push(debitDetails[i].cardNumber);
                    tempArr.push(debitDetails[i].internalId);
                    tempArr.push(debitDetails[i].expDate);
                    tempArr.push(debitDetails[i].cardType);
                    tempArr.push(debitDetails[i].cardTypeId);
                    tempArr.push(debitDetails[i].detailType);
                    cardValues.push(tempArr);
                }

                var table = jQuery('#debitDetails').DataTable( {
                    data: cardValues,
                    "bJQueryUI": true,
                    "bInfo": false,
                    "bLengthChange": false,
                    "searching": false,
                    "destroy": true,
                    columns: [
                        { title: "Card Number" },
                        { title: "Internal ID "},
                        { title: "Exp. Date" },
                        { title: "Card Type" },
                        { title: "Card Type ID" },
                        { title: "Detail Type" }
                    ],
                    "columnDefs": [
                    {
                        "targets": [ 1, 4, 5 ],
                        "visible": false,
                        "searchable": false
                    }
                    ],
                    "fnDrawCallback": function() {
                        jQuery("#debitDetails .ui-corner-all, .ui-corner-top, .ui-corner-left, .ui-corner-tl").remove();
                    },
                    "pageLength": 5,
                    "select": 'single'
                }
                );
            
                table.rows().deselect(); // Initially deselect all rows in case it is redrawn
                selectedDetails.lineCount =  '';
                selectedDetails.lineNumber =  '';
                selectedDetails.debitId = '';
                selectedDetails.detailType = '';
                selectedDetails.cardType = '';

                document.getElementById("submissionButton").disabled = true;

                table.on('select', function (e, dt, type, indexes) {
                    document.getElementById("submissionButton").disabled = false;
                    selectedDetails.lineCount = table.rows().count();
                    selectedDetails.lineNumber = jQuery(this).index();
                    selectedDetails.debitId = table.rows( { selected: true } ).data()[0][1];
                    selectedDetails.detailType = table.rows( { selected: true } ).data()[0][5];
                    selectedDetails.cardType = '';

                    console.log('Internal ID: ' + table.rows( { selected: true } ).data()[0][1]);
                });

                table.on('deselect', function (e, dt, type, indexes) {
                    document.getElementById("submissionButton").disabled = true;
                    selectedDetails.lineCount =  '';
                    selectedDetails.lineNumber =  '';
                    selectedDetails.debitId = '';
                    selectedDetails.detailType = '';
                    selectedDetails.cardType = '';
                });
            }
        }

        /* Remove cybersource integration
        function addToken(fwdToSuitelet) {
            var vendorId = currentVendor;
            console.log('Adding debit details for vendor ID: ' + vendorId);

            if (fwdToSuitelet) {
                redirectToSuitelet();
            }
            else {
				var currentUser = runtime.getCurrentUser();
                var currentUserCenter = currentUser.roleCenter;
				
				if(vendorId || currentUserCenter == 'VENDOR'){
					var onClickDialog;
					createCustomDialog('Redirecting...', 'You will be redirected to a secure page to confirm card details', onClickDialog, false);
					var suiteletURL = url.resolveScript({
						scriptId: 'customscript_vdsa_payment_preference_sl',
						deploymentId: 'customdeploy_vdsa_payment_preference_sl',
						returnExternalUrl: false
					});
					suiteletURL = 'https://' + runtime.accountId + '.app.netsuite.com' + suiteletURL + '&vendorId=' + vendorId;

					var params = {
						functionCommand: 'CREATE_SECURE_ACCEPTANCE_HOSTED_CHECKOUT_CREATE_TOKEN_FORM',
						vendorId: vendorId,
						suiteletRedirectURL: suiteletURL
					};
					redirectToTokenForm(params);
				}
				else{
					alert('Please select a vendor before proceeding.');
				}
            }
        }*/
        
         /**
          * Techfino Merged PoC Function to redirect to externally hosted suitelet
          */
         /* Remove cybersource integration
         function redirectToTokenForm(params) {
            console.log('Redirect Entry');
            try {
                var suiteletURL = url.resolveScript({
                    scriptId: 'customscript_vdsa_backend_server_process', 
                    deploymentId: 'customdeploy_vdsa_backend_server_d1'
                });

                console.log('signed form request URL: ' + suiteletURL);
                console.log('signed form request params: ' + JSON.stringify(params));

                var signedFormRequest = https.post({
                    url: suiteletURL,
                    body: JSON.stringify(params)
                });

                var signedFormBody = JSON.parse(signedFormRequest.body);
                console.log('signed form request body: ' + signedFormRequest.body);
                
                var signedFormJSON = signedFormBody.vendorFieldObj;
                var signedFormURL = signedFormBody.actionURL;

                var cybersourceForm = document.createElement('form');
                cybersourceForm.setAttribute('method', 'post');
                cybersourceForm.setAttribute('action', signedFormURL);
                cybersourceForm.setAttribute('target', '_blank');
                for (var formElement in signedFormJSON) {
                    var hiddenInputField = document.createElement('input');
                    hiddenInputField.setAttribute('type', 'hidden');
                    hiddenInputField.setAttribute('name', formElement);
                    hiddenInputField.setAttribute('value', signedFormJSON[formElement]);
                    cybersourceForm.appendChild(hiddenInputField);
                }

                document.body.appendChild(cybersourceForm);
                window.onbeforeunload = function() { return; };
                cybersourceForm.submit();

            } catch (errorObj) {
                var title, errMessage;
                try {
                    title = errorObj.name;
                    errMessage = errorObj.message;
                } catch (errorObj) {
                    title = 'Form error';
                    errMessage = 'Could not submit form...' + errorObj.toString();
                }
                var onClickDialog;
                createCustomDialog(title, errMessage, onClickDialog, false);
            }
        }*/

        function createCustomDialog(title, message, action, isConfirmation) {

            var buttons = {
                Cancel: function () {
                  jQuery(this).dialog('destroy');
                }
            };
            if (isConfirmation) {
               buttons = {
                    OK: function () {
                      if (typeof (action) == 'function') {
                        setTimeout(action, 50);
                      }
                      jQuery(this).dialog('destroy');
                    },
                    Cancel: function () {
                      jQuery(this).dialog('destroy');
                    }
                }
            }

            jQuery("<div>" + message + "</div>").dialog({
                autoOpen: true,
                resizable: false,
                modal: true,
                title: title,
                buttons: buttons,
                open: function () {
                    var win = jQuery(window);
                
                    jQuery(this).parent().css({
                        position: 'absolute',
                        left: (win.width() - jQuery(this).parent().outerWidth()) / 2,
                        top: (win.height() - jQuery(this).parent().outerHeight()) / 2
                    });
                }
            });
            
        }

        /* Remove update feature
        function createUpdateCustomDialog(title, message, action, isConfirmation) {

            var buttons = {
                Cancel: function () {
                  jQuery(this).dialog('destroy');
                },
                SubmitToCybersource: function() {
                  setTimeout(action, 50);
                }
            };
            if (isConfirmation) {
               buttons = {
                    OK: function () {
                      if (typeof (action) == 'function') {
                        //setTimeout(action, 50);
                      }
                      jQuery(this).dialog('destroy');
                    },
                    Cancel: function () {
                      jQuery(this).dialog('destroy');
                    },
                    SubmitToCybersource: function() {
                      setTimeout(action, 50);
                    }
                }
            }

            jQuery("<div>" + message + "</div>").dialog({
                autoOpen: true,
                resizable: false,
                modal: true,
                title: title,
                buttons: buttons,
                width: "80%",
                maxWidth: "670px",
                height: "300px",
                maxHeight: "300px",
                minHeight: "300px",
                bgiframe: true,
                open: function () {
                    var win = jQuery(window);

                    jQuery(this).dialog("option", "height", 300);
                
                    jQuery(this).parent().css({
                        position: 'absolute',
                        left: (win.width() - jQuery(this).parent().outerWidth()) / 2,
                        top: (win.height() - jQuery(this).parent().outerHeight()) / 2
                    });
                }
            });
            
        }*/

        function addToken(fwdToSuitelet) {
            var vendorId = currentVendor;
            console.log('Adding debit details for vendor ID: ' + vendorId);

            if (fwdToSuitelet) {
                redirectToSuitelet();
            }
            else {
				var currentUser = runtime.getCurrentUser();
                var currentUserCenter = currentUser.roleCenter;
				
				if(vendorId || currentUserCenter == 'VENDOR'){
					// var onClickDialog;
					// createCustomDialog('Redirecting...', 'You will be redirected to a secure page to confirm card details', onClickDialog, false);
					createCustomDialog('Redirecting...', 'You will be redirected to a secure page to confirm card details', '', false);
					var suiteletURL = url.resolveScript({
						scriptId: 'customscript_vdsa_payment_preference_sl',
						deploymentId: 'customdeploy_vdsa_payment_preference_sl',
						returnExternalUrl: false
					});
					// suiteletURL = 'https://' + runtime.accountId + '.app.netsuite.com' + suiteletURL + '&vendorId=' + vendorId;
                    suiteletURL = suiteletURL + '&vendorId=' + vendorId;
                    
                    // var debitDetails;
                    if (currentUserCenter != 'VENDOR'){
                        var vendorDetails = search.lookupFields({
                            type: search.Type.VENDOR,
                            id: vendorId,
                            // columns: 'custentity_vdsa_visa_direct_eligible'
                            columns: [
                                'firstname',
                                'lastname',
                                'billzipcode'
                                // 'email',
                                // 'phone',
                                // 'billaddress1',
                                // 'billaddress2',
                                // 'billcity',
                                // 'billstate',
                                // 'billcountrycode'
                            ]
                        });
                    } else {
                        var vendorDetails = JSON.parse(document.getElementById('vendorLookup').textContent);
                    }
                    // get value from billstate select field
                    // if (Array.isArray(vendorDetails.billstate)){
                    //     vendorDetails.billstate = (!!vendorDetails.billstate[0]) ? vendorDetails.billstate[0].value : '';
                    // }
                    
                    // var debitDetails;
                    // if (!Object.values) {
                    //     // IE support
                    //     var values = Object.keys(vendorDetails).map(function(e) {
                    //         return vendorDetails[e];
                    //     });
                    //     debitDetails = values.slice(1);
                    // } else {
                    //     debitDetails = Object.values(vendorDetails).slice(1); // remove first object
                    // }

                    // vendorDetails.billstate = (vendorDetails.billstate.length > 0)? vendorDetails.billstate[0].value : '';
                    // var debitDetails = Object.values(vendorDetails);

					var params = {
						functionCommand: 'ENROLLTOKEN',
						vendorId: vendorId,
                        suiteletRedirectURL: suiteletURL,
                        editDetailObj: vendorDetails
					};
					redirectToTokenForm(params);
				}
				else{
					alert('Please select a vendor before proceeding.');
				}
            }
        }

        function redirectToTokenForm(params){
            console.log('Redirect Entry');
            var backendURL = url.resolveScript({
                scriptId: 'customscript_vdsa_backend_server_process',
                deploymentId: 'customdeploy_vdsa_backend_server_d1'
            });
            
            try {
                var backendRes = https.post({
                    url: backendURL,
                    body: JSON.stringify(params)
                });
                console.log(backendRes);
                var backendBody = JSON.parse(backendRes.body);
                if (backendBody.formBody && backendBody.actionURL){
                    var formBody = backendBody.formBody;
                    var formActionURL = backendBody.actionURL;
        
                    // create hidden form and submit
                    var iframeForm = document.createElement("form");
                    iframeForm.setAttribute("method", "post");
                    iframeForm.setAttribute("action", formActionURL);
                    iframeForm.setAttribute('target', '_blank');
                    for (var formElement in formBody) {
                        var hiddenInputField = document.createElement('input');
                        hiddenInputField.setAttribute("type", "hidden");
                        hiddenInputField.setAttribute("name", formElement);
                        hiddenInputField.setAttribute("value", formBody[formElement]);
                        iframeForm.appendChild(hiddenInputField);
                    }
        
                    document.body.appendChild(iframeForm);
                    window.onbeforeunload = function() { return; };
                    iframeForm.submit();
                } else {
                    createCustomDialog('Error', 'Unable to load Add Card entry form.', '', false);
                }
            } catch (error) {
                console.log(error);
                createCustomDialog('Error', 'Unable to load Add Card entry form. ' + error.message, '', false);
            }
            
        }

        return {
            pageInit: pageInit
        };

    });
