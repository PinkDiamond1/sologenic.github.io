/*************************************************************
 * Script   : VDSA_SU_CardPayoutsBackEndProcess.js
 * Abstract : A backend suitelet that will process all of the server side                 
 *             actions (Debit detail create, edit, delete, and Vendor record updates) 
 * Author   : amico.arthur.v.diaz
 * Revision History :
 *************************************************************
 * Version * Date       * Author             * Description
 *************************************************************
 *   0.1   * 02/26/2019 * amico.arthur.v.diaz* Initial version          
 *   0.2   * 03/07/2019 * antonio.m.p.perez  * Added library for debit type 
 *   0.3   * 03/12/2019 * amico.arthur.v.diaz* Added Email Notification 
 *   0.4   * 03/21/2019 * amico.arthur.v.diaz* Added functionality on automatic detail update  
 *   1.3   * 01/21/2020 * jayzar.n.estareja  * Remove update feature
 *   1.4   * 02/11/2020 * jayzar.n.estareja  * Add enrollment notif feature
 *   1.5   * 03/02/2020 * jayzar.n.estareja  * Auto-unenrollment feature
 *************************************************************/

/**
 * @NApiVersion 2.x
 * @NScriptType Suitelet
 * @NModuleScope SameAccount
 */

define(['N/record', 'N/url', 'N/search', 'N/error', 'N/email', 'N/runtime', '../Library/VDSA_LIB_constantsFile.js', '../Library/VDSA_LIB_TokenService.js'],

    function(record, url, search, error, email, runtime, VDSA_CONST, VDSA_TSP) {

        //The main function for Receiving response
        function onRequest(context) {
            try {
                var payLoad = context.request.body;
                if (!!payLoad) {
                    payLoad = JSON.parse(payLoad);
                }
                var vendorId = payLoad.vendorId;
                var editDetailObj = payLoad.editDetailObj;
                var debitId = payLoad.debitId;
                var suiteletRedirectURL = payLoad.suiteletRedirectURL;
                var functionCommand = payLoad.functionCommand;

          /**********************************************************************************************************
           * Visa Toolkit Note:																 						*
           * 													 	                            					*
           * 'ENROLLTOKEN' and 'UNENROLLTOKEN' denotes the Function Name in your Library							*
           * This Function will get the current parameters and process it on your TSP								*
		   * You may modify the functions createTokenFormObject & unenrollDebitRecord based on your requirements 	*
           **********************************************************************************************************/
              
                switch (functionCommand) {
                    case '2': //save primary
                    case 2:
                        setPrimary(debitId);
                        break;
                    case 'ENROLLTOKEN':
                        var formObj = createTokenFormObject(vendorId, suiteletRedirectURL, editDetailObj);
                        context.response.setHeader({
                            name: 'Content-Type',
                            value: 'Application/JSON',
                        });
                        context.response.write({ 
                            output: JSON.stringify({'actionURL': formObj.actionURL, 'formBody': formObj.formBody}) 
                        });
                        break;
                    case 'UNENROLLTOKEN':
                          unenrollDebitRecord(vendorId, debitId);
                        break;
                        
                }

            } catch (error) {
                throw error;
            //  log.error('Error Message', error.message);
            }
        }

        function createTokenFormObject(vendorId, redirectURL, debitDetails){
            var iframeURL = VDSA_TSP.enrollToken(vendorId, redirectURL, redirectURL, debitDetails);
            var actionURL = url.resolveScript({
                scriptId: 'customscript_vdsa_iframe_page',
                deploymentId: 'customdeploy_vdsa_iframe_page'
            });
            // log.debug('actionURL',actionURL);
            log.debug('iframeURL',iframeURL);
            var formBody = {
                'vendorId': vendorId,
                // 'cpAction': action,
                'iframeURL': iframeURL,
                'redirectURL': redirectURL
            };
            return {
                actionURL : actionURL,
                formBody : formBody
            }
        }

        function setPrimary(debitId) {

            var id = record.submitFields({
                type: 'customrecord_vdsa_debit_details',
                id: debitId,
                values: { 'custrecord_vdsa_debit_type': VDSA_CONST.Lists.DebitType.PRIMARY },
                options: { enableSourcing: false }
            });

        }
    
        /**
         * Creates a record log for each CyberSource requests.
         * @param vendorId - Internal Id of vendor linked to the log record
         * @param 
         */
        function createLogRecord(vendorId, requestBody, requestResponseCode, timeStamp, cardNumber, action){
            
            try{
                
                var reasonDetail ='';
                var errMsg='';
                log.debug('requestResponseCode',requestResponseCode);
                if(requestResponseCode == 200){
                    reasonDetail ='Unenroll Complete';
                }else{
                    reasonDetail = JSON.stringify(requestBody.result.errors[0].code);
                    errMsg = JSON.stringify(requestBody.result.errors[0].message);
                }
                
                var logObject = {
                    custrecord_vdsa_cb_vendor: vendorId,
                    custrecord_vdsa_cb_action: action,
                    custrecord_vdsa_cb_time_stamp: timeStamp,
                    // custrecord_vdsa_cb_code_reason: requestResponseCode,
                    custrecord_vdsa_cb_refnumber: requestBody.result.requestId,
                    custrecord_vdsa_cb_card_number: cardNumber,
                    custrecord_vdsa_cb_reasondetail: reasonDetail,
                    custrecord_vdsa_cb_error: errMsg,
                    custrecord_vdsa_cb_card_token: requestBody.result.cardToken,
					custrecord_vdsa_cb_authorized: requestBody.result.isAuthorizationSucceeded
                };
                
                var logRecord = record.create({
                    type:'customrecord_vdsa_response_log'
                });
                
                for(var key in logObject){
                    logRecord.setValue({
                        fieldId: key,
                        value: logObject[key]
                    });
                }
                
                logRecord.save();
                
            }
            catch(e){
                log.error('Error Message',e.message);
            }
        }
    
        /*
        *This function is for setting the  primary card in vendor record when the detail unenrolled
        *is primary. The vendor record should be updated as well if its primary has been unenrolled
        */
        function setParentVendorPrimary(vendorId, detailType) {
            if (detailType == 1) {
                record.submitFields({
                    type: 'vendor',
                    id: parseInt(vendorId),
                    values: { custentity_vdsa_primary_debit: null }
                });
            }
        }
        

        /*
        *This function is for sending an email to the card owner when their card recod has been
        *unenrolled successfully
        */
        function emailNotification(vendorId, debitCardNumber) {
            var senderId;
            var senderHasEmail = false;
            var sendEmailCheckbox;
            var vendorName;
            var vendorEmail;
            var emailBody;
            var emailSubject;

            var vendorSearch = search.lookupFields({
                type: 'vendor',
                id: vendorId,
                columns: ['email', 'entityid']
            });
            var preferenceRecord = runtime.getCurrentScript().getParameter({ name: 'custscript_vdsa_preference_record' }),
                preferenceSearchObject = preferenceSearch(preferenceRecord);

            if (!!preferenceSearchObject) {
                vendorName = vendorSearch.entityid;
                vendorEmail = vendorSearch.email;
                emailBody = emailParser(preferenceSearchObject.custrecord_vdsa_email_body_unenrollment, vendorName, debitCardNumber,preferenceSearchObject.custrecord_vdsa_card_sender_email);
                emailSubject = emailParser(preferenceSearchObject.custrecord_vdsa_email_subj_unenrollment, vendorName, debitCardNumber,preferenceSearchObject.custrecord_vdsa_card_sender_email);
                senderId = preferenceSearchObject.custrecord_vdsa_email_author_unenroll[0].value;
                sendEmailCheckbox = preferenceSearchObject.custrecord_vdsa_card_unenrollment_email;
            }

            if (!!senderId) {
                var senderSearch = search.lookupFields({
                    type: 'employee',
                    id: senderId,
                    columns: ['email']
                });

                if (!!senderSearch.email) {
                    senderHasEmail = true;
                }
            }

            if (!!senderHasEmail && !!sendEmailCheckbox && !!vendorEmail && !!emailBody && !!emailSubject) {
                email.send({
                    author: senderId,
                    recipients: vendorId,
                    subject: emailSubject,
                    body: emailBody
                });
                log.debug('email sent to', vendorEmail);
                log.debug('email sent from', senderId);
            }

        }

        function emailParser(emailText, vendorName, cardNumber,merchantName) {
            var emailParsed = emailText;

            emailParsed = emailParsed.replace(/{vendorName}/g, vendorName);
            emailParsed = emailParsed.replace(/{cardNumber}/g, cardNumber);
            emailParsed = emailParsed.replace(/{companyName}/g, merchantName);

            return emailParsed;
        }

        function preferenceSearch(preferenceId) {
            if (!!preferenceId) {
                var preferenceSearchResult = search.lookupFields({
                    type: 'customrecord_vdsa_suiteapp_preference',
                    id: preferenceId,
                    columns: ['custrecord_vdsa_email_author_unenroll',
                        'custrecord_vdsa_card_unenrollment_email',
                        'custrecord_vdsa_email_body_unenrollment',
                        'custrecord_vdsa_email_subj_unenrollment',
                        'custrecord_vdsa_card_sender_email'
                    ]
                });
                return preferenceSearchResult;
            } else {
                return null;
            }
        }

        /*
        *This function is for setting the CP record detial type into Primary when only 2 remaining CP record
        *and the Primary was unenrolled. And for auto-unenrolling vendor when all cards removed.
        */
        function setAutomaticPrimary(vendorId) {
            var tokenSearch = search.create({
                type: 'customrecord_vdsa_debit_details',
                filters: [
                    ['custrecord_vdsa_debit_card_owner', 'anyof', parseInt(vendorId)],
                    'AND',
                    ['isinactive', 'is', false]
                ],
                columns: [{ name: 'internalid', label: 'Internal ID' }]
            });

            var tokenSearchRun = tokenSearch.run();
            var tokenSearchResult = tokenSearchRun.getRange(0, 1000);

            if (tokenSearchResult.length === 1) { // if its the only active 
                var otherToken = tokenSearchResult[0].id;
                submitFields('customrecord_vdsa_debit_details', otherToken, 'custrecord_vdsa_debit_type', VDSA_CONST.Lists.DebitType.PRIMARY);
            } else if (tokenSearchResult.length === 0) { // if no cards remain
                record.submitFields({
                    type: 'vendor',
                    id: parseInt(vendorId),
                    values: { 'custentity_vdsa_visa_direct_eligible': false }
                });
            }
        }

        /*
        *This function is used for updating other Card Payouts record.
        */
        function submitFields(recType, recordId, fieldId, value) {
            var valObj = new Object();

            valObj[fieldId] = value;

            var recId = record.submitFields({
                type: recType,
                id: parseInt(recordId),
                values: valObj
            });
        }

        function unenrollDebitRecord(vendorId, debitId){
            var debitDetails = record.load({
                id: debitId,
                type: 'customrecord_vdsa_debit_details'
            });
            var tokenNumber = debitDetails.getValue('custrecord_vdsa_debit_token');
            var detailType = debitDetails.getValue('custrecord_vdsa_debit_type');
            var debitCardNumber = debitDetails.getValue('custrecord_vdsa_debit_card_number');
            try {
                var requestObject = VDSA_TSP.unenrollToken(tokenNumber);
                log.debug('requestObject',requestObject);
                var requestBody = JSON.parse(requestObject.body);
                var requestResponseCode = JSON.parse(requestObject.code);
                createLogRecord(vendorId, requestBody, requestResponseCode, new Date(), debitCardNumber, VDSA_CONST.CardAction.UNENROLL);
                if(requestResponseCode == 200){
                    debitDetails.setValue('isinactive', true); // Set inactive
                    debitDetails.setValue('custrecord_vdsa_debit_card_owner', null); //Set card owner as null
                    //debitDetails.setValue('custrecord_vdsa_debit_token', null); //Set token as null
                    var fmtDateTime = new Date();
                    // var responseFormattedDateTime = format.format({ value: fmtDateTime, type: format.Type.DATE });
                    debitDetails.setValue('custrecord_vdsa_debit_unenroll_timestamp', fmtDateTime);
                    var debitDetailSave = debitDetails.save();
                    if (!!debitDetailSave) { //Checking if the saving/unenrolling of record is successful
                        emailNotification(vendorId, debitCardNumber); //function to send an email to the card owner
                        setParentVendorPrimary(vendorId, detailType); //This will set the vendor record's primary card to null.
                        setAutomaticPrimary(vendorId); //Set remaining as Primary if there is only 2 card record left

                    }
                }
            } catch(errMsg) {
                throw error.create({
                    name: 'Unenrollment Failed',
                    message: errMsg
                }).message;
            }

        }

        return {
            onRequest: onRequest
        };

    });