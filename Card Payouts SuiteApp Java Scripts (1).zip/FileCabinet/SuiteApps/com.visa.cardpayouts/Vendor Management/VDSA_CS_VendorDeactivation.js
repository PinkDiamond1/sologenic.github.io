    /*************************************************************
     * Script   : VDSA_CS_VendorDeactivation.js
     * Abstract : Sent out warning to user when inactivating a vendor.
     * Author   : darryl.d.caparas
     * Revision History :
     *************************************************************
    * Version * Date       * Author              * Description
    *************************************************************
    *   0.1   * 05/13/2020 * darryl.d.caparas    * Initial version
    *************************************************************/

    /**
    * @NApiVersion 2.x
    * @NScriptType ClientScript
    * @NModuleScope SameAccount
    */

    define(['N/ui/dialog'],
        function (dialog) {
            function fieldChanged(scriptContext) {

                if (scriptContext.fieldId == 'isinactive') {
                    var rec = scriptContext.currentRecord;
                    var isInactive = rec.getValue({ fieldId: 'isinactive' });
                    var isEnrolled = rec.getValue({ fieldId: 'custentity_vdsa_visa_direct_eligible' });
                    console.log(isInactive);

                    if (isEnrolled == true && isInactive == true) {
                        dialog.create({
                            title: 'Card Payouts',
                            message: 'Inactivating this vendor will unenroll all associated debit cards. Would you like to continue?',
                            buttons: [
                                { label: 'Yes', value: true },
                                { label: 'Cancel', value: false }]
                        }).then(onClickDialog).catch();
                    }
                    function onClickDialog(result) {
                        if (!result) {
                            rec.setValue({
                                fieldId: 'isinactive',
                                value: false
                            });
                        }

                    }
                }

            }

            return {
                fieldChanged: fieldChanged
            };

        });