/*************************************************************
 * Script   : VDSA_SU_Webhook.js
 * Abstract : Handles iFrame response via Webhook.
 * Author   : jayzar.n.estareja
 * Revision History :
 *************************************************************
 * Version * Date       * Author              * Description
 *************************************************************
 *   0.1   * 01/07/2020 * jayzar.n.estareja   * Initial version
 *   0.2   * 01/17/2020 * jayzar.n.estareja   * Rework response handler
 *   0.3   * 01/29/2020 * jayzar.n.estareja   * Added new response log field and error logging
 *   0.4   * 04/06/2020 * jayzar.n.estareja   * Password decode
 *************************************************************/

/**
 * @NApiVersion 2.x
 * @NScriptType Suitelet
 */

define(['N/encode', 'N/record', 'N/search', 'N/runtime'],
	function(encode, record, search, runtime){

		function onRequest(context){
			log.debug('context',JSON.stringify(context));
            if (context.request.method === 'POST') {
                var basicAuth = context.request.headers.Authorization;
				if (!basicAuth) {
					log.error('context',JSON.stringify(context.request));
					log.error('Authorization Error', 'No authorization received.');
					return;
				}
                var webhookUsername;
                var webhookPassword;
                var preferenceId = runtime.getCurrentScript().getParameter({ name: 'custscript_vdsa_preference_record' });
                log.debug('preferenceId',preferenceId);
                if (!preferenceId) {
                    log.error('Configuration Error', 'Card Payouts Preference Record is not configured in the General Preferences.');
					return;
                } else {
                    var preferenceSearchResult = search.lookupFields({
                        type: 'customrecord_vdsa_suiteapp_preference',
                        id: preferenceId,
                        columns: ['custrecord_vdsa_webhook_username', 'custrecord_vdsa_webhook_password']
                    });
                    webhookUsername = preferenceSearchResult.custrecord_vdsa_webhook_username;
                    webhookPassword = encode.convert({
                        string: preferenceSearchResult.custrecord_vdsa_webhook_password,
                        inputEncoding: encode.Encoding.BASE_64,
                        outputEncoding: encode.Encoding.UTF_8
                    });
                }

                var webhookAuth = 'Basic ' + encode.convert({
                    string: webhookUsername + ':' + webhookPassword,
                    inputEncoding: encode.Encoding.UTF_8,
                    outputEncoding: encode.Encoding.BASE_64
                });

				// check authentication
                if (basicAuth == webhookAuth){
                    var requestBody = JSON.parse(context.request.body);
					// TO DO: add error handling

                    // create response log
                    var logObject = {
						custrecord_vdsa_cb_vendor: requestBody.Data.CustomerReferenceNumber,
						// custrecord_vdsa_cb_card_number: maskedCard,
						custrecord_vdsa_cb_time_stamp: new Date(),
						custrecord_vdsa_cb_action: 'Create', // VDSA_CONST.CardAction.CREATE
						custrecord_vdsa_cb_code_reason: requestBody.Data.ResponseCode,
						custrecord_vdsa_cb_reasondetail: requestBody.Data.ResponseDescription,
						custrecord_vdsa_cb_refnumber: requestBody.Data.RequestId,
                        custrecord_vdsa_cb_card_token: requestBody.Data.CardToken,
                        custrecord_vdsa_cb_error: requestBody.Data.Error,
						custrecord_vdsa_cb_authorized: requestBody.Data.Authorized
						//requestBody.Data.ResponseReceived
                    };
                    
                    var logRecord = record.create({
                        type:'customrecord_vdsa_response_log'
                    });
                    
                    for(var key in logObject){
                        logRecord.setValue({
                            fieldId: key,
                            value: logObject[key]
                        });
                    }
                    
                    try{
						var logrecid = logRecord.save();
						log.debug('Response Log Id', logrecid);
					} catch (err){
						log.error('context',JSON.stringify(context.request));
						log.error(err.name, err);
					}
                } else {
					log.error('context',JSON.stringify(context.request));
					log.error('Authentication Error', 'Incorrect Webhook username and Webhook password.');
				}
            }
        }
        
		return {
			onRequest: onRequest
		}
	}
);