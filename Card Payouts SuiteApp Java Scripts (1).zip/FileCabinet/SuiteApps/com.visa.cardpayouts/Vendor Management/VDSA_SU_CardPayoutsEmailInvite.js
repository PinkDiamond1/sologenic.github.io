/**************************************************************
* Script   : VDSA_SU_CardPayoutsEmailInvite.js                            											   
* Abstract : Suitelet script to create page for Card Payouts Email Invitation 											   
* Author   : darryl.d.caparas                                                 											   
* Revision History :                                                            											   
***************************************************************
* Version * Date       * Author             * Description                      											   
***************************************************************
*   0.1   * 02/28/2020 * darryl.d.caparas   * Initial version
*   0.2   * 03/24/2020 * darryl.d.caparas   * Add Filter                   											    
***************************************************************/

/**
 * @NApiVersion 2.x
 * @NScriptType Suitelet
 * @NModuleScope SameAccount
 */

define(['N/ui/serverWidget', 'N/search', 'N/runtime', 'N/task', 'N/redirect'],
    function (serverWidget, search, runtime, task, redirect) {
        var TASK_ID = '';
        var SENT_FILTER = '';
        /**
	     * Definition of the Suitelet script trigger point.
	    *
        * @param {Object} context
        * @param {ServerRequest} context.request - Encapsulation of the incoming request
        * @param {ServerResponse} context.response - Encapsulation of the Suitelet response
        * 
        */

        function onRequest(context) {
            function createForm() {
                try {
                    log.error('output', context.request.parameters);
                    var form = serverWidget.createForm({
                        title: 'Card Payouts Vendor Enrollment Invitation'
                    });

                    form.clientScriptModulePath = './VDSA_CS_CardPayoutsEmailInvite.js';

                    sendEmail = form.addSubmitButton({
                        label: 'Send Invite'
                    });

                    var taskId = form.addField({
                        id: 'custpage_vdsa_task',
                        label: 'Status',
                        type: serverWidget.FieldType.TEXT
                    });

                    taskId.updateDisplayType({
                        displayType: serverWidget.FieldDisplayType.INLINE
                    });
                    taskId.defaultValue = "READY";
                    sendEmail.isDisabled = false;

                    if (context.request.parameters.SENT_FILTER) {
                        log.error('Filter', context.request.parameters.SENT_FILTER);
                        
                    }

                    SENT_FILTER = context.request.parameters.SENT_FILTER;
                    log.error('filterInvite', SENT_FILTER);

                    var alreadyEmailedCheckBox = form.addField({
                        id: 'custpage_vdsa_filter_sent',
                        label: 'Invitation Sent',
                        type: serverWidget.FieldType.SELECT
                    });

                    alreadyEmailedCheckBox.updateDisplayType.ENTRY;

                    alreadyEmailedCheckBox.addSelectOption({
                        value : '',
                        text : 'All'
                    });

                    alreadyEmailedCheckBox.addSelectOption({
                            value : 'true',
                            text : 'Yes'
                    });

                    alreadyEmailedCheckBox.addSelectOption({
                        value : 'false',
                        text : 'No'
                    });

                    if(SENT_FILTER=='true'){
                        alreadyEmailedCheckBox.defaultValue = 'true';
                    }
                    else if (SENT_FILTER=='false'){
                        alreadyEmailedCheckBox.defaultValue = 'false';
                    }
                    else{
                        alreadyEmailedCheckBox.defaultValue = '';
                    }

                    if (context.request.parameters.TASK_ID) {
                        log.error('Context ID', context.request.parameters.TASK_ID);
                        var taskStatus = task.checkStatus(context.request.parameters.TASK_ID);
                        taskId.defaultValue = taskStatus.status;

                        var refreshBttn = form.addButton({
                            label: 'Refresh',
                            id: 'custpage_refreshbutton',
                            functionName: 'refreshPage'
                        });
                        refreshBttn.isHidden = true;

                        if (taskStatus.status != 'COMPLETE') {
                            log.error('taskStatus.status!COMPLETE', taskStatus.status);
                            sendEmail.isDisabled = true;
                            refreshBttn.isHidden = false;
                            alreadyEmailedCheckBox.updateDisplayType({
                                displayType: serverWidget.FieldDisplayType.INLINE
                            });
                        }
                    }

                    var sublist = form.addSublist({
                        id: 'custpage_tableresult',
                        type: serverWidget.SublistType.LIST,
                        label: 'Unenrolled Vendors'
                    });

                    sublist.addMarkAllButtons();

                    var idField = sublist.addField({
                        id: 'custpage_vdsa_hidden_id',
                        label: 'Internal ID',
                        type: serverWidget.FieldType.TEXT
                    });

                    idField.updateDisplayType({
                        displayType: serverWidget.FieldDisplayType.HIDDEN
                    });

                    sublist.addField({
                        id: 'custpage_vdsa_checkbox',
                        label: 'Select',
                        type: serverWidget.FieldType.CHECKBOX
                    });

                    sublist.addField({
                        id: 'custpage_vdsa_name',
                        label: 'Vendor',
                        type: serverWidget.FieldType.TEXT
                    });

                    sublist.addField({
                        id: 'custpage_vdsa_email',
                        label: 'Email',
                        type: serverWidget.FieldType.TEXT
                    });

                    sublist.addField({
                        id: 'custpage_vdsa_invite',
                        label: 'Invitation Sent',
                        type: serverWidget.FieldType.TEXT
                    });

                    var preferenceRecord = runtime.getCurrentScript().getParameter({ name: 'custscript_vdsa_preference_record' }),
                        preferenceSearchObject = preferenceSearch(preferenceRecord);

                    if (!!preferenceSearchObject) {
                        sendEmailCheckbox = preferenceSearchObject.custrecord_vdsa_card_invite_email;
                        emailBody = preferenceSearchObject.custrecord_vdsa_email_body_invite;
                        emailSubject = preferenceSearchObject.custrecord_vdsa_email_subj_invite;
                        senderId = preferenceSearchObject.custrecord_vdsa_email_author_invite[0].value;
                    }

                    if (sendEmailCheckbox == false) {
                        sendEmail.isDisabled = true;
                    }


                    return { form: form, sublist: sublist, SENT_FILTER: SENT_FILTER };

                } catch (e) {
                    log.error('Error creating form.', e);
                }
            }
            function getResult() {
                var myForm = createForm();
                if (myForm) {
                    var form = myForm.form;
                    var sublist = myForm.sublist;
                    var filterInvite = myForm.SENT_FILTER;
                    log.error('filterInvite',filterInvite);
                    var vendorsResults = runSearch(filterInvite);
                    
                    for (var i = 0; i < vendorsResults.length; i++) {
                        sublist.setSublistValue({
                            id: 'custpage_vdsa_hidden_id',
                            line: i,
                            value: vendorsResults[i].internalid
                        });
                        sublist.setSublistValue({
                            id: 'custpage_vdsa_name',
                            line: i,
                            value: vendorsResults[i].entityid
                        });
                        sublist.setSublistValue({
                            id: 'custpage_vdsa_email',
                            line: i,
                            value: vendorsResults[i].email
                        });
                        if(!vendorsResults[i].invite){
                            var status = 'No';
                        }
                        else {
                            var status = 'Yes';
                        }
                        sublist.setSublistValue({
                            id: 'custpage_vdsa_invite',
                            line: i,
                            value: status
                        });
                    }
                    context.response.writePage(form);

                }
            }

            function runSearch(filterInvite) {
                var filters = [
                    search.createFilter({ name: "custentity_vdsa_visa_direct_eligible", operator: search.Operator.IS, values: false }),
                    search.createFilter({ name: "email", operator: search.Operator.ISNOTEMPTY, values: true }),
                    search.createFilter({ name: "isinactive", operator: search.Operator.IS, values: false })
                    //search.createFilter({ name: "custentity_vdsa_email_invite", operator: search.Operator.ANY, values: ''})
                ];

                if (!!filterInvite){
                    log.error('PUSH',filterInvite);
                    filters.push(search.createFilter({ name: "custentity_vdsa_email_invite", operator: search.Operator.IS, values: filterInvite}));
                }
                else{
                    log.error('NAH',filterInvite);
                    filters.push(search.createFilter({ name: "custentity_vdsa_email_invite", operator: search.Operator.ANY, values: ''}));
                }

                var columns = [
                    search.createColumn({ name: "internalid", label: "Internal ID" }),
                    search.createColumn({ name: "entityid", label: "Name" }),
                    search.createColumn({ name: "email", label: "Email" }),
                    search.createColumn({ name: "custentity_vdsa_email_invite", label: "Invite" })
                ];

                var vendorsResults = search.create({
                    type: "vendor",
                    filters: filters,
                    columns: columns
                });
                var results = [];

                vendorsResults.run().each(function (result) {
                    var res = {};
                    res['internalid'] = result.getValue({
                        name: 'internalid'
                    })
                    res['entityid'] = result.getValue({
                        name: 'entityid'
                    });
                    res['email'] = result.getValue({
                        name: 'email'
                    });
                    res['invite'] = result.getValue({
                        name: 'custentity_vdsa_email_invite'
                    });
                    results.push(res);
                    return true;
                });

                return results;
            }

            function preferenceSearch(preferenceId) {
                if (!!preferenceId) {
                    var preferenceSearchResult = search.lookupFields({
                        type: 'customrecord_vdsa_suiteapp_preference',
                        id: preferenceId,
                        columns: ['custrecord_vdsa_email_author_invite',
                            'custrecord_vdsa_card_invite_email',
                            'custrecord_vdsa_email_body_invite',
                            'custrecord_vdsa_email_subj_invite'
                        ]
                    });
                    return preferenceSearchResult;
                } else {
                    return null;
                }
            }

            var mrTask = task.create({
                taskType: task.TaskType.MAP_REDUCE,
                scriptId: 'customscript_vdsa_card_invite_email',
                deploymentId: 'customdeploy_vdsa_card_invite_email'
            });

            if (context.request.method === 'GET') {
                getResult();
            }

            if (context.request.method === 'POST') {
                
                if(context.request.parameters.entryformquerystring){
                    log.error('SENT_FILTER',context.request.parameters.entryformquerystring);
                    SENT_FILTER = context.request.parameters.entryformquerystring;
                    var sent = SENT_FILTER.split(/&/);
                    log.error('sent',sent.length);
                    if (sent.length>3){
                        SENT_FILTER = SENT_FILTER.split(/&/)[3].split(/=/)[1];
                        log.error('SENT_FILTER',SENT_FILTER);
                    }
                    else{
                        SENT_FILTER = '';
                    }
                }
                var resultTable = context.request.parameters.custpage_tableresultdata;
                var delimiter = /\u0001/;
                var resultTable = resultTable.split(/\u0002/);
                var filteredResult = []
                resultTable.forEach(function (line) {
                    var rec = line.split(delimiter);
                    if (rec[1] == 'T') {
                        filteredResult.push(rec[0]);
                    }
                });

                if (filteredResult.length > 0) {
                    mrTask.params = { 'custscript_vdsa_vendor_id': filteredResult.toString() };
                    log.error('custscript_vdsa_vendor_id',filteredResult.toString());
                    TASK_ID = mrTask.submit();
                }

                var redirectToPage = redirect.toSuitelet({
                    scriptId: 'customscript_vdsa_card_payouts_invite',
                    deploymentId: 'customdeploy_vdsa_card_payouts_invite',
                    parameters: { 'TASK_ID': TASK_ID,'SENT_FILTER':SENT_FILTER}
                });
            }
        }

        return {
            onRequest: onRequest
        };

    });