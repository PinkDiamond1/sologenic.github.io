/*************************************************************
 * Script   : VDSA_UE_VendorDeactivation
 * Abstract : A User-event script that will unenroll all cards associated when a vendor is deactivated.
 * Author   : darryl.d.caparas
 * Revision History :
 *************************************************************
 * Version * Date       * Author             * Description
 *************************************************************
 *   0.1   * 05/13/2020 * darryl.d.caparas   * Initial version                        
 *************************************************************/

/**
 * @NApiVersion 2.x
 * @NScriptType UserEventScript
 * @NModuleScope SameAccount
 */

define(['N/search', 'N/record','N/runtime','N/email', '../Library/VDSA_LIB_TokenService.js', '../Library/VDSA_LIB_constantsFile.js'],

    function (search, record,runtime, email, VDSA_TSP, VDSA_CONST) {

        function beforeSubmit(scriptContext) {
            var currentRecord = scriptContext.newRecord;
            var isInactive = currentRecord.getValue({ fieldId: 'isinactive' });
            var isEnrolled = currentRecord.getValue({ fieldId: 'custentity_vdsa_visa_direct_eligible' });
            var vendorId = currentRecord.id;

            if (isInactive && isEnrolled) {

                var cardRecordLookup = search.create({
                    type: 'customrecord_vdsa_debit_details',
                    filters: [{ name: 'custrecord_vdsa_debit_card_owner', operator: 'anyof', values: vendorId },
                    { name: 'isinactive', operator: 'is', values: 'F' }],
                    columns: [{ name: 'custrecord_vdsa_debit_token', label: 'Token' }, { name: 'custrecord_vdsa_debit_card_number', label: 'number' }]
                });

                currentRecord.setValue({
                    fieldId: 'custentity_vdsa_visa_direct_eligible',
                    value: false
                });

                var cardRecordResult = cardRecordLookup.run().getRange(0, 100);

                log.debug('cardRecordResult.length', cardRecordResult.length);
                log.debug('cardRecordResult', cardRecordResult);

                if (cardRecordResult.length > 0) {
                    for (i = 0; cardRecordResult.length > i; i++) {
                        var tokenId = cardRecordResult[i].getValue({ name: 'custrecord_vdsa_debit_token' });
                        var debitCardNumber = cardRecordResult[i].getValue({ name: 'custrecord_vdsa_debit_card_number' });

                        var recId = cardRecordResult[i].id;
                        log.debug('tokenId', tokenId);
                        log.debug('recId', recId);
                        try {
                            var responseBody = VDSA_TSP.UnenrollToken(tokenId);
                            log.debug('responseBody', responseBody);
                            var requestBody = JSON.parse(responseBody.body);
                            var requestResponseCode = JSON.parse(responseBody.code);

                            var rec = record.submitFields({
                                type: 'customrecord_vdsa_debit_details',
                                id: recId,
                                values: {
                                    isinactive: true,
                                    custrecord_vdsa_debit_card_owner: null,
                                    custrecord_vdsa_debit_unenroll_timestamp: new Date()
                                }
                            });

                            emailNotification(vendorId, debitCardNumber);
                            createLogRecord(vendorId, requestBody, requestResponseCode, new Date(), debitCardNumber, VDSA_CONST.CardAction.UNENROLL);
                        }
                        catch (errMsg) {
                            log.error('Unenrollment Failed',errMsg);
                        }
                    }

                }

            }
        }

            function createLogRecord(vendorId, requestBody, requestResponseCode, timeStamp, cardNumber, action) {

                try {

                    var reasonDetail = '';
                    var errMsg = '';
                    log.debug('requestResponseCode', requestResponseCode);
                    if (requestResponseCode == 200) {
                        reasonDetail = 'Unenroll Complete';
                    } else {
                        reasonDetail = JSON.stringify(requestBody.result.errors[0].code);
                        errMsg = JSON.stringify(requestBody.result.errors[0].message);
                    }

                    var logObject = {
                        custrecord_vdsa_cb_vendor: vendorId,
                        custrecord_vdsa_cb_action: action,
                        custrecord_vdsa_cb_time_stamp: timeStamp,
                        // custrecord_vdsa_cb_code_reason: requestResponseCode,
                        custrecord_vdsa_cb_refnumber: requestBody.result.requestId,
                        custrecord_vdsa_cb_card_number: cardNumber,
                        custrecord_vdsa_cb_reasondetail: reasonDetail,
                        custrecord_vdsa_cb_error: errMsg,
                        custrecord_vdsa_cb_card_token: requestBody.result.cardToken,
                        custrecord_vdsa_cb_authorized: requestBody.result.isAuthorizationSucceeded
                    };

                    var logRecord = record.create({
                        type: 'customrecord_vdsa_response_log'
                    });

                    for (var key in logObject) {
                        logRecord.setValue({
                            fieldId: key,
                            value: logObject[key]
                        });
                    }

                    logRecord.save();

                }
                catch (e) {
                    log.error('Error Message', e.message);
                }
            }
            
            function emailNotification(vendorId, debitCardNumber) {
                var senderId;
                var senderHasEmail = false;
                var sendEmailCheckbox;
                var vendorName;
                var vendorEmail;
                var emailBody;
                var emailSubject;
    
                var vendorSearch = search.lookupFields({
                    type: 'vendor',
                    id: vendorId,
                    columns: ['email', 'entityid']
                });
                var preferenceRecord = runtime.getCurrentScript().getParameter({ name: 'custscript_vdsa_preference_record' }),
                    preferenceSearchObject = preferenceSearch(preferenceRecord);
    
                if (!!preferenceSearchObject) {
                    vendorName = vendorSearch.entityid;
                    vendorEmail = vendorSearch.email;
                    emailBody = emailParser(preferenceSearchObject.custrecord_vdsa_email_body_unenrollment, vendorName, debitCardNumber,preferenceSearchObject.custrecord_vdsa_card_sender_email);
                    emailSubject = emailParser(preferenceSearchObject.custrecord_vdsa_email_subj_unenrollment, vendorName, debitCardNumber,preferenceSearchObject.custrecord_vdsa_card_sender_email);
                    senderId = preferenceSearchObject.custrecord_vdsa_email_author_unenroll[0].value;
                    sendEmailCheckbox = preferenceSearchObject.custrecord_vdsa_card_unenrollment_email;
                }
    
                if (!!senderId) {
                    var senderSearch = search.lookupFields({
                        type: 'employee',
                        id: senderId,
                        columns: ['email']
                    });
    
                    if (!!senderSearch.email) {
                        senderHasEmail = true;
                    }
                }
    
                if (!!senderHasEmail && !!sendEmailCheckbox && !!vendorEmail && !!emailBody && !!emailSubject) {
                    email.send({
                        author: senderId,
                        recipients: vendorId,
                        subject: emailSubject,
                        body: emailBody
                    });
                    log.debug('email sent to', vendorEmail);
                    log.debug('email sent from', senderId);
                }
    
            }

            function preferenceSearch(preferenceId) {
                if (!!preferenceId) {
                    var preferenceSearchResult = search.lookupFields({
                        type: 'customrecord_vdsa_suiteapp_preference',
                        id: preferenceId,
                        columns: ['custrecord_vdsa_email_author_unenroll',
                            'custrecord_vdsa_card_unenrollment_email',
                            'custrecord_vdsa_email_body_unenrollment',
                            'custrecord_vdsa_email_subj_unenrollment',
                            'custrecord_vdsa_card_sender_email'
                        ]
                    });
                    return preferenceSearchResult;
                } else {
                    return null;
                }
            }

            function emailParser(emailText, vendorName, cardNumber,merchantName) {
                var emailParsed = emailText;
    
                emailParsed = emailParsed.replace(/{vendorName}/g, vendorName);
                emailParsed = emailParsed.replace(/{cardNumber}/g, cardNumber);
                emailParsed = emailParsed.replace(/{companyName}/g, merchantName);
    
                return emailParsed;
            }

            return {
               
                beforeSubmit: beforeSubmit
            };

        });

