/*************************************************************
 * Script   : VDSA_CS_CardPreferenceButtons.js
 * Abstract : Client script to tigger all the button on the Card Payouts Preference Page
 *             this will be used by the Payment Preference Suitelet
 * Author   : darryl.d.caparas
 * Revision History :
 *************************************************************
* Version * Date       * Author             * Description
*************************************************************
*   0.1   * 01/07/2021 * darryl.d.caparas   * Initial version
*************************************************************/

/**
 * @NApiVersion 2.x
 * @NScriptType ClientScript
 * @NModuleScope SameAccount
 */

define(['N/url', 'N/ui/dialog', 'N/runtime', 'N/https', 'N/ui/message'],

    function(url, dialog, runtime, https, message) {

        /**
         *This will initialize all the variables used in Status messages.
        */
        function pageInit(context) {

            var rec = context.currentRecord;
            var vendorId = parseInt(rec.getValue({ fieldId: 'custpage_vendorid' })) || runtime.getCurrentUser().id;
            var vendorDetails = JSON.parse(rec.getValue({ fieldId: 'custpage_vendor_details_obj' }));
            document.getElementById("setAsPrimary").onclick = function() { onSetTypePrimary(vendorId); };
            document.getElementById("addDebitDetails").onclick = function() { addToken(vendorId, vendorDetails); };
            document.getElementById("unenrollDebitDetails").onclick = function() { unenrollToken(vendorId); };

            try {
                var modal = document.getElementById('myModal');
                // When the user clicks anywhere outside of the modal, close it
                window.onclick = function(event) {
                    if (event.target == modal) {
                        modal.style.display = "none";
                    }
                };
            } catch (e) {
                console.log('Error setting modal onclick property: ' + e.message);
            }
            try {
                // Get the <span> element that closes the modal
                var span = document.getElementsByClassName("modal-close")[0];
                // When the user clicks on <span> (x), close the modal
                span.onclick = function() {
                    modal.style.display = "none";
                };
            } catch (e) {
                console.log('Error setting span onclick property: ' + e.message);
            }

            var msgType = rec.getValue({ fieldId: 'custpage_msg_type' });
            var msgAction = rec.getValue({ fieldId: 'custpage_msg_action' });

            var operation = null;
            if (msgType == 1) {
                if (msgAction == 1) { //Success message action for Create
                    operation = 'created';
                } else if (msgAction == 2) { //Success message action for Update
                    operation = 'updated';
                } else if (msgAction == 3) { //Success message action for setting Primary
                    operation = 'updated the primary detail of the';
                } else if (msgAction == 4) { //Success message action for saving preference
                    operation = 'changed the card payouts preference of the';
                } else if (msgAction == 5) { //Success message action for Delete
                    operation = 'deleted';
                } else if (msgAction == 6) { //Success message action for Unenroll
                    operation = 'unenrolled';
                } else {
                    msgType = 0;
                }
            } else if (msgType == 2) {
                if (msgAction == 1) { //Fail message action for Create
                    operation = 'create';
                } else if (msgAction == 2) { //Fail message action for Update
                    operation = 'update';
                } else if (msgAction == 3) { //Fail message action for setting Primary
                    operation = 'set the primary detail on';
                } else if (msgAction == 4) { //Fail message action for saving preference
                    operation = 'set the card payouts preference';
                } else if (msgAction == 5) { //Fail message action Delete
                    operation = 'delete';
                } else if (msgAction == 6) { //Fail message action Unenroll
                    operation = 'unenroll';
                } else {
                    msgType = 0;
                }
            }

            //This is for actual showing of the Status messages.
            if (performance.navigation.type == 0) {
                if (msgType == 1) { // Okay
                    var msgAlert = message.create({
                        type: message.Type.CONFIRMATION,
                        title: 'Success',
                        message: 'Successfully ' + operation + ' debit card.',
                        duration: 5000
                    });
                    msgAlert.show();
                } else if (msgType == 2) { // No
                    var msgAlert = message.create({
                        type: message.Type.ERROR,
                        title: 'Error',
                        message: 'Error trying to ' + operation + ' debit card.',
                        duration: 5000
                    });
                    msgAlert.show();
                }
            }
        }

        /**
         *This will execute the Set Primary button on Card Payouts preference page.
        *The function will call the backend suitelet to process the card record updates.
        */
        function onSetTypePrimary(vendorId) {
            var debitId = findTokenSelected().debitId;
            if (!!debitId) {
                var body = {
                    vendorId: vendorId,
                    debitId: debitId,
                    functionCommand: 2
                };

                var userResponse = dialog.confirm({
                    title: "Card Payouts Preference",
                    message: "All the other debit record that is set as Primary will be set to Secondary."
                });

                userResponse.then(onClickDialog).catch();

                //
                function onClickDialog(result) {
                    if (result) {
                        var executeResult = executeSuitelet('customscript_vdsa_backend_server_process', 'customdeploy_vdsa_backend_server_d1', null, body);
                        executeResult.then(function(result) {
                            reloadPage(vendorId, 1, 3);
                        }).catch(function(reason) {
                            reloadPage(vendorId, 2, 3);
                        });
                    }
                }

            } else {
                dialog.alert({
                    title: "Card Payouts Preference",
                    message: "You have not selected a Debit Detail to set as primary."
                });
            }

        }

        function findTokenSelected() {
			var objectReturn = { // initialize object
                lineCount: '',
                lineNumber: '',
                debitId: '',
                detailType: '',
                cardType: '',
                cardNumber:''
            };

            var tbl=$("#debitDetails").DataTable();
            var tblLength = tbl.rows()[0].length
          	for( i=0; i<tblLength; i++) {
                if ( tbl.row(i).data()[0] != "" && $(tbl.row(i).node()).find('#selectRow:checked').length) {
                    objectReturn.lineNumber = i;
                    objectReturn.debitId = $("#debitDetails").DataTable().row(i).data()[3];
                    objectReturn.detailType = $("#debitDetails").DataTable().row(i).data()[1];
                    objectReturn.cardType = $("#debitDetails").DataTable().row(i).data()[6];
                    objectReturn.cardNumber = $("#debitDetails").DataTable().row(i).data()[2];
                }
            }
            objectReturn.lineCount = tblLength;

            return objectReturn;
        }

        function validateInput(input) {
            var regex = /^([0-9+\s])*$/;
            if (regex.test(input)) return true;
            return false;
        }


        function executeSuitelet(scriptId, deploymentId, headers, reqBody) {

            var resUrl = url.resolveScript({
                scriptId: scriptId,
                deploymentId: deploymentId,
                returnExternalUrl: false
            });

            var response = https.post.promise({ url: resUrl, body: JSON.stringify(reqBody) });
            return response;
        }

        function reloadPage(vendorId, msgType, msgAction) {
            var suiteletURL = url.resolveScript({
                scriptId: 'customscript_vdsa_payment_preference_sl',
                deploymentId: 'customdeploy_vdsa_payment_preference_sl',
                returnExternalUrl: false,
                params: {
                    'vendorId': vendorId,
                    'msgType': msgType,
                    'msgAction': msgAction
                }
            });

            if (window.onbeforeunload) {
                window.onbeforeunload = function() { null; };
            };

            window.location.href = suiteletURL;
        }

        function addToken(vendorId, vendorDetails){
            console.log('Vendor ID: ' + vendorId);
            console.log('Vendor Details: ' + JSON.stringify(vendorDetails));
			
          
          /**************************************************************************************
           * Visa Toolkit Note:																 	*
           * Add your Add Card Logic 														 	*
           * 'ENROLLTOKEN' denotes the Function Name in your Library						*
           * This Function will get the current parameters and process it on backend			*
           * Remove the Warning Message below once all configurations are completed				*
           * You may refer the commented sample Try Catch that performs the Add Card Function   *
           **************************************************************************************/
          
           var suiteletURL = url.resolveScript({
                    scriptId: 'customscript_vdsa_add_card',
                    deploymentId: 'customdeploy_vdsa_add_card_d1'
             
                });
           window.open(suiteletURL);
          
          
          	/*message.create({
                    title: 'Add Card Page',
                    message: 'Please configure your Add Card Page',
                    type: message.Type.WARNING,
                }).show();*/
            /* try {
                // get value from billstate select field
                // if (Array.isArray(vendorDetails.billstate)){
                //     vendorDetails.billstate = (!!vendorDetails.billstate[0]) ? vendorDetails.billstate[0].value : '';
                // }
                
                // var debitDetails;
                // if (!Object.values) {
                //     // IE support
                //     var values = Object.keys(vendorDetails).map(function(e) {
                //         return vendorDetails[e];
                //     });
                //     debitDetails = values.slice(1);
                // } else {
                //     debitDetails = Object.values(vendorDetails).slice(1); // remove first object
                // }

                var suiteletURL = url.resolveScript({
                    scriptId: 'customscript_vdsa_payment_preference_sl',
                    deploymentId: 'customdeploy_vdsa_payment_preference_sl',
                    params: {'vendorId': vendorId}
                });
                console.log(suiteletURL);

                var params = {
                    functionCommand: 'ENROLLTOKEN',
                    vendorId: vendorId,
                    // suiteletRedirectURL: location.pathname + location.search,
                    suiteletRedirectURL: suiteletURL,
                    editDetailObj: vendorDetails
                };
                redirectToTokenForm(params);
                message.create({
                    title: 'Redirecting...',
                    message: 'You will be redirected to a secure page to confirm card details',
                    type: message.Type.CONFIRMATION,
                }).show();
            } catch (errorObj) {
                var title, errMessage;
                try {
                    title = errorObj.name;
                    errMessage = errorObj.message;
                } catch (errorObj) {
                    title = "Form error";
                    errMessage = "Could not submit form..." + errorObj.toString();
                }
                message.create({
                    title: title,
                    message: errMessage,
                    type: message.Type.ERROR
                }).show({ duration: 5000 });
            }*/
        }


        function redirectToTokenForm(params){
            console.log('Redirect Entry');

            var backendURL = url.resolveScript({
                scriptId: 'customscript_vdsa_backend_server_process',
                deploymentId: 'customdeploy_vdsa_backend_server_d1'
            });
            
            var backendRes = https.post({
                url: backendURL,
                body: JSON.stringify(params)
            });
            console.log(backendRes);

            var backendBody = JSON.parse(backendRes.body);
            var formBody = backendBody.formBody;
            var formActionURL = backendBody.actionURL;

            // create hidden form and submit
            var iframeForm = document.createElement("form");
            iframeForm.setAttribute("method", "post");
            iframeForm.setAttribute("action", formActionURL);
            for (var formElement in formBody) {
                var hiddenInputField = document.createElement('input');
                hiddenInputField.setAttribute("type", "hidden");
                hiddenInputField.setAttribute("name", formElement);
                hiddenInputField.setAttribute("value", formBody[formElement]);
                iframeForm.appendChild(hiddenInputField);
            }

            document.body.appendChild(iframeForm);
            window.onbeforeunload = function() { return; };
            iframeForm.submit();
        }
        
        function unenrollToken(vendorId){
            console.log('UNENROLL');
            var lineDetail = findTokenSelected();
            var tokenId = lineDetail.debitId;
            var lineCount = lineDetail.lineCount;
            var detailType = lineDetail.detailType;
            var cardNumber = lineDetail.cardNumber;
          
          
          /******************************************************************************************
           * Visa Toolkit Note:																 		*
           * Add your Unenroll Card Logic 														 	*
           * 'UNENROLLTOKEN' denotes the Function Name in your Library							*
           * This Function will get the current parameters and process it on backend				*
           * Remove the Warning Message below once all configurations are completed					*
           * You may refer the commented sample Try Catch that performs the Unenroll Card Function  *
           ******************************************************************************************/
            message.create({
                 	title: 'Uneroll API',
                    message: 'Please Configure Unenroll API',
                            type: message.Type.WARNING,
                    }).show();
          
           /* if(!!tokenId){
                console.log('UNENROLL - TOKEN IS NOT NULL');
                console.log(tokenId);
                var body = {
                    vendorId: vendorId,
                    debitId: tokenId,
                    functionCommand: 'UNENROLLTOKEN'
                };

                if (detailType == 'Primary') {
                    if (lineCount == 1) {
                        userResponse = dialog.confirm({
                            title: "Card Payouts Preference",
                            message: cardNumber+ " card record will be unenrolled"
                        });
                        userResponse.then(onClickDialog).catch();
                    } else if (lineCount == 2) {
                        userResponse = dialog.confirm({
                            title: "Card Payouts Preference",
                            message: cardNumber +" Card record will be unenrolled. The remaining Card record will be automatically set to Primary."
                        });
                        userResponse.then(onClickDialog).catch();
                    } else {
                        userResponse = dialog.confirm({
                            title: "Card Payouts Preference",
                            message: "Unable to unenroll the Primary Card. You must first select another Card as Primary in order to unenroll this card."
                        });
                    }
                } else {
                    userResponse = dialog.confirm({
                        title: "Card Payouts Preference",
                        message: cardNumber+" card record will be unenrolled"
                    });
                    userResponse.then(onClickDialog).catch();
                }

                function onClickDialog(result) {
                    if (result) {
                        message.create({
                            title: 'Loading...',
                            message: 'Unenrollment in progress.',
                            type: message.Type.INFORMATION,
                        }).show();
                        var executeResult = executeSuitelet('customscript_vdsa_backend_server_process', 'customdeploy_vdsa_backend_server_d1', null, body);
                        console.log(executeResult);
                        executeResult.then(function(result) {
                            reloadPage(vendorId, 1, 6);
                        }).catch(function(reason) {
                            reloadPage(vendorId, 2, 6);
                        });
                    }
                }

            }else{
                message.create({
                title: 'No Token Selected...',
                message: 'Please select a token to update',
                type: message.Type.ERROR
            }).show({ duration: 5000 });

            }*/
        }

        return {
            pageInit: pageInit
        };

    });
