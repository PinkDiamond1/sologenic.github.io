 /*************************************************************
 * Script   : VDSA_CS_TriggerManageCardPayoutsButton.js
 * Abstract : Client script to tigger the Manage Card Payouts button in Vendor record
 *				this will be used by the User Event script to show the Manage Card
 *				Payouts button	
 * Author   : amico.arthur.v.diaz
 * Revision History :
 *************************************************************
 * Version * Date       * Author             * Description
 *************************************************************
 *   0.1   * 02/22/2019 * amico.arthur.v.diaz* Initial version 
 *   0.2   * 03/21/2019 * amico.arthur.v.diaz* Changed the redirection type 
 *************************************************************/

/**
 * @NApiVersion 2.x
 * @NScriptType ClientScript
 * @NModuleScope SameAccount
 */
 
define(['N/url'],

function(url) {
    
	function pageInit(context){
	}
	
	/**
	 * This is the main function that will be called when the Manage Card Payouts button
	 * in the Vendor record is clicked.
	 * This will redirect the page into the Card Payouts Preference Suitelet.
	 */
	function onClickFunction(vendorId){
		var suiteletURL = url.resolveScript({
			scriptId: 'customscript_vdsa_payment_preference_sl',
			deploymentId: 'customdeploy_vdsa_payment_preference_sl',
			returnExternalUrl: false,
			params: {'vendorId': vendorId}
		});
		window.open(suiteletURL);
	}
	
    return {
        onClickFunction: onClickFunction, 
		pageInit: pageInit
    };
    
});
