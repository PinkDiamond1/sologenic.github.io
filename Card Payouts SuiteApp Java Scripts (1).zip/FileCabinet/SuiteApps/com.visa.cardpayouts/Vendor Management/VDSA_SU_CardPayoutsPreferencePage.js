/*************************************************************
 * Script   : VDSA_SU_CardPayoutsPreferencePage.js                                            
 * Abstract : A Suitelet script that will create the Card Payouts                             
 *            Preference page.                                                                
 * Author   : antonio.m.p.perez                                                               
 * Revision History :                                                                         
 *************************************************************
 * Version *     Date      *       Author           * Description                             
 *************************************************************
 *   0.1    * 02/20/2019   * antonio.m.p.perez      * Initial version                         
 *   0.2    * 02/21/2019   * amico.arthur.v.diaz    * Added Sublist                           
 *   0.3    * 02/22/2019   * amico.arthur.v.diaz    * Added Actions on the buttons            
 *   0.4    * 03/06/2019   * antonio.m.p.perez      * Changed checkbox to Enable Card Payouts 
 *   0.5    * 03/13/2019   * jordan.k.johnson       * Updated form style    
 *   1.0    * 01/07/2020   * jayzar.n.estareja      * Integration - add feature
 *   1.1    * 01/17/2020   * jayzar.n.estareja      * Updated response handler logic
 *   1.2    * 01/29/2020   * jayzar.n.estareja      * Updated response handler error handling
 *   1.3    * 02/07/2020   * jayzar.n.estareja      * Added mastercard and default logo
 *                                                    Added popup frame container
 *   1.4    * 02/10/2020   * darryl.d.caparas       * Minor Change on Error Message
 *   1.5    * 02/11/2020   * jayzar.n.estareja      * Add enrollment notif feature
 *   1.6    * 03/02/2020   * jayzar.n.estareja      * Auto-enrollment feature
 *                                                  * Update modal design
 *   1.7    * 03/10/2020   * jayzar.n.estareja      * Add role eligibility restriction
 *   1.8    * 03/18/2020   * jayzar.n.estareja      * Netsuite UI Alignment
 *   1.9    * 03/30/2020   * jayzar.n.estareja      * Update Iframe API
 *   2.0    * 05/05/2020   * darryl.d.caparas       * Disable RE-Enroll for Different Vendor
 *************************************************************
 
 /**
 * @NApiVersion 2.x
 * @NScriptType Suitelet
 * @NModuleScope SameAccount
 */

define(['N/ui/serverWidget', 'N/search', 'N/runtime', 'N/record', 'N/error', 'N/file', 'N/format', 'N/email', '../Library/VDSA_LIB_constantsFile.js', '../Library/VDSA_LIB_TokenService.js'],

    function(ui, search, runtime, record, error, file, format, email, VDSA_CONST, VDSA_TSP) {

		const EXPIRATION_DATE_FIELD_LENGTH = 7;
		const APP_ID = 'com.visa.cardpayouts';
        const MAX_SEARCH_RESULT = 1000;
        var vendorEnrolled;

        function onRequest(context) {
            var vendorId;
            var currentUser = runtime.getCurrentUser();
            var currentUserCenter = currentUser.roleCenter;

            if (currentUserCenter == 'VENDOR') {
                vendorId = currentUser.id;
            } else {
                vendorId = context.request.parameters.vendorId;
            }

			//Error handling
            if (!vendorId || !roleEligible()) {
                throw error.create({
                    name: 'Access Error',
                    message: 'You are not authorized to view this page'
                }).message;
            } else {
                if (parseInt(vendorId) < 1) {
                    throw error.create({
                        name: 'Access Error',
                        message: 'You are not authorized to setup a Card Payouts detail for this Vendor'
                    }).message;
                }
            }

			var vendorLookup = search.lookupFields({
                type: search.Type.VENDOR,
                id: vendorId,
                // columns: 'custentity_vdsa_visa_direct_eligible'
                columns: [
                    'custentity_vdsa_visa_direct_eligible',
                    'firstname',
                    'lastname',
                    'billzipcode'
                    // 'email',
                    // 'phone',
                    // 'billaddress1',
                    // 'billaddress2',
                    // 'billcity',
                    // 'billstate',
                    // 'billcountrycode'
                ]
            });
            vendorEnrolled = vendorLookup.custentity_vdsa_visa_direct_eligible;
			
			if (context.request.parameters.extId){
				var responseMsg = responseHandler(context.request.parameters.extId);
			}

            var logo = file.load({
                id: 'SuiteApps/com.visa.cardpayouts/Vendor Management/assets/vdsaicon_trns.png'
            }).url;
            var visaIcon = file.load({
                id: 'SuiteApps/com.visa.cardpayouts/Vendor Management/assets/visapmticon1.png'
            }).url;
			var mcIcon = file.load({
                id: 'SuiteApps/com.visa.cardpayouts/Vendor Management/assets/mcpmticon1.png'
            }).url;
            var amexIcon = file.load({
                id: 'SuiteApps/com.visa.cardpayouts/Vendor Management/assets/amexpmticon1.png'
            }).url;
            var defaultIcon = file.load({
                id: 'SuiteApps/com.visa.cardpayouts/Vendor Management/assets/defaultpmticon1.png'
            }).url;
			var fileObj = file.load({
                id: 'SuiteApps/com.visa.cardpayouts/Vendor Management/assets/VDSA_SU_CardPayoutsPreferencePage.html'
            });

            var form = ui.createForm({ title: 'Card Payout Preferences' });

			form = addCustomUIAssets(form);
			
			var content = "<div class='headerSection' role='main' width='100%' height='100%'>" +
            "<img class='headerIcon' src='" + logo + "'></img>" +
            "<h1 class='headerTitle'>Card Payouts Preference</h1>" +
            "</div>";

            // Response Handler message
			if (context.request.parameters.extId && responseMsg != '') {
                var extId = context.request.parameters.extId;
                var sessionObj = runtime.getCurrentSession();
                var isNewSession = (sessionObj.get({name:"cpRefNum"})!=extId) ? true : false; 
                log.debug('isNewSession',isNewSession);
                var wasDisplayed;
                if (isNewSession) {
                    wasDisplayed = 0;
                    sessionObj.set({name: 'cpMsgDisplayed', value: 0});
                } else {
                    wasDisplayed = parseInt(sessionObj.get({name:"cpMsgDisplayed"}));
                }
                log.debug('wasDisplayed',wasDisplayed);
                sessionObj.set({name: 'cpRefNum', value: extId});

                var modalHeader = '<div class=modal-header>Card Payouts Preference Message</div>'
                if (responseMsg.search('Card enrollment in progress') >= 0){
                    var retryCount = 3;
                    var reloadInterval = 10000;
                    var reloadCnt = sessionObj.get({name: "cpReloadCtr"}); 
                    log.debug('reloadCnt',reloadCnt);
                    // var reloadCnt = reloadCnt && sessionObj.get({name:"cpRefNum"})==extId ? reloadCnt+1 : 1; 
                    // log.debug('reloadCnt',reloadCnt);
                    var reloadCnt = isNewSession ? 1 : parseInt(reloadCnt)+1; 
                    log.debug('reloadCnt',reloadCnt);
                    sessionObj.set({name: 'cpReloadCtr', value: reloadCnt});
                    if (reloadCnt <= retryCount) {
                        var loadingHtml = '<div style="width: 30px;margin-right: 25px;float: left;">'
                        + '<svg viewBox="-18 -18 36 36" role="img" aria-label="Loading" style="stroke-width: 3px;stroke-dashoffset: 75;animation: spin 2s ease infinite;">'
                        + '<circle fill="none" r="16" style="stroke: rgba(96,119,153,0.70);"></circle>'
                        + '<circle fill="none" r="16" transform="rotate(-135)" stroke-dasharray="100" style="stroke: #24385B;"></circle>'
                        + '</svg></div>'
                        content+='<div class="modal myModal"><div class=modal-content>'+modalHeader+loadingHtml+'<span style="line-height: 34px; vertical-align: middle;">'+responseMsg+'</span></div></div>'
                        // content+='<div class="modal myModal"><div class=modal-content>'+modalHeader+'<p><i class="fa fa-spinner fa-2x fa-spin" style="float:left;margin-right:25px"></i> '+responseMsg+'</p></div></div>'
                        +'<script>setTimeout(function(){window.location.reload();},'+reloadInterval+');</script>'
                    } else if (reloadCnt == retryCount+1) {
                        var responseFailMsg = 'Card enrollment failed.<br>Either no response received or an internal error occurred. Please try to enroll card again.';
                        content+='<div class=modal id=myModal><div class=modal-content>'+modalHeader+'<p>'+responseFailMsg+'</p><span class="modal-close blueBgNS">OK</span></div></div>';
                    }
                } else if (wasDisplayed==0) {
                    sessionObj.set({name: 'cpMsgDisplayed', value: 1});
                    content+='<div class=modal id=myModal><div class=modal-content>'+modalHeader+'<p>'+responseMsg+'</p><span class="modal-close blueBgNS">OK</span></div></div>';
                }
            }

            /* FOR SPRINT5: content+='<div id="frame-container" class="modal" style="display:none"><div id="frame" '
                +'style="width: 360px; height: 457px; border-radius: 3px; background-color: white; '
                +'overflow: hidden; box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);'
                +'margin: 0px auto; margin-top: calc(50vh - 480px);"></div></div>' //((screen.height/2)-(360/2)-300)*/

			var vendorSearch = search.create({
                type: 'customrecord_vdsa_debit_details',
                filters: [{name: 'custrecord_vdsa_debit_card_owner',operator: search.Operator.IS,values: vendorId},
					      {name: 'isinactive', operator: search.Operator.IS, values: 'F'}
				],
                columns: [{ name: 'custrecord_vdsa_debit_type', label: 'Type', sort: search.Sort.ASC },
                    { name: 'custrecord_vdsa_debit_card_number', label: 'Debit Card Number' },
                    { name: 'custrecord_vdsa_debit_expiration_date', label: 'Expiration Date' },
                    { name: 'internalid', label: 'Internal ID' },
                    { name: 'custrecord_vdsa_debit_card_type', label: 'Card Type' }
                ]
            });

            var vendorSearchRun = vendorSearch.run();
			var vendorSearchResult = vendorSearchRun.getRange(0, 1000);
            var data = [];

            for (var resultValue = 0; resultValue < vendorSearchResult.length; resultValue++) {
                var result = vendorSearchResult[resultValue];
				var innerTableObject = {
					select: ' ',
					type: ' ',
					internalId: ' ',
					expDate: ' ',
					cardNumber: ' ',
					cardType: ' ',
					cardTypeId: ' '
				};

				innerTableObject.select = '<input type="radio" name="selectRow" id="selectRow" />';
				innerTableObject.type = result.getText('custrecord_vdsa_debit_type');
				innerTableObject.internalId = result.getValue('internalid');
				innerTableObject.cardNumber = result.getValue('custrecord_vdsa_debit_card_number');
				var cardType = result.getText('custrecord_vdsa_debit_card_type');

				/* Add static column values */
                // Add card image
                var cardType = result.getValue({ name: 'custrecord_vdsa_debit_card_type' });
                var cardImageFieldValue = ' ';
                switch (cardType) {
					case 'Visa':
                    case VDSA_CONST.CardType['Visa']:
                        cardImageFieldValue = '<img src="' + visaIcon + '" title="'+ cardType +'" width="24" height="24" style="padding-top:0px;"></img>';
                        break;
                    case 'MasterCard':
                    case VDSA_CONST.CardType['Mastercard']:
                        cardImageFieldValue = '<img src="' + mcIcon + '" title="'+ cardType +'" width="24" height="24" style="padding-top:0px;"></img>';
                        break;
                    case 'American Express':
                    case VDSA_CONST.CardType['American Express']:
                        cardImageFieldValue = '<img src="' + amexIcon + '" title="'+ cardType +'" width="24" height="24" style="padding-top:0px;"></img>';
                        break;
                    default:
                        cardImageFieldValue = '<img src="' + defaultIcon + '" title="'+ cardType +'" width="24" height="24" style="padding-top:0px;"></img>';
				}

                // overwrite date with formatted date
                var expirationDate = result.getValue({ name: 'custrecord_vdsa_debit_expiration_date' });
                expirationDate = new Date(expirationDate);
                expirationDate = format.format({ value: expirationDate, type: format.Type.MMYYDATE });
                expirationDate = expirationDate.replace('/', '-').padStart(EXPIRATION_DATE_FIELD_LENGTH, '0');

				innerTableObject.cardType = cardImageFieldValue;
				innerTableObject.expDate = expirationDate;
				innerTableObject.cardTypeId = cardType;

				data.push(innerTableObject);
            }
            
            var tableData = form.addField({
            	id: 'custpage_tabledata',
            	type: ui.FieldType.INLINEHTML,
            	label: 'Table Data'

            });
            tableData.defaultValue = '<script type="text/javascript">var debitDetails = ' + JSON.stringify(data) + ';</script>';

            var contentField = form.addField({
                id: 'custpage_form',
                type: ui.FieldType.INLINEHTML,
                label: 'Card Preferences'
            });
			contentField.defaultValue = content;
			
			//Set the client script for button triggers
            form.clientScriptModulePath = './VDSA_CS_CardPreferenceButtons.js';

            // Message Banner
            var msgType = context.request.parameters.msgType;
            var msgAction = context.request.parameters.msgAction;

            form.addField({
                id: 'custpage_msg_type',
                label: 'Message Type',
                type: ui.FieldType.TEXT
            }).updateDisplayType({ displayType: 'hidden' }).defaultValue = msgType;
            form.addField({
                id: 'custpage_msg_action',
                label: 'Message Action',
                type: ui.FieldType.TEXT
            }).updateDisplayType({ displayType: 'hidden' }).defaultValue = msgAction;
			form.addField({
                id: 'custpage_vendorid',
                type: ui.FieldType.INTEGER,
                label: 'Vendor ID'
            }).updateDisplayType({ displayType: 'hidden' }).defaultValue = vendorId;
            form.addField({
                id: 'custpage_vendor_details_obj',
                type: ui.FieldType.LONGTEXT,
                label: 'Vendor ID'
            }).updateDisplayType({ displayType: 'hidden' }).defaultValue = JSON.stringify(vendorLookup);
			
			var htmlForm = form.addField({
            	id: 'custpage_htmlform',
            	type: ui.FieldType.INLINEHTML,
            	label: 'HTMLFORM'
            });
            
            var htmlContent = fileObj.getContents();
            htmlForm.defaultValue = htmlContent;

            context.response.writePage(form);

        }

        /**
		 * Function to determine if role of current user is eligible to manage
		 * card payouts of a vendor as configured in the preference page
		 *
		 * @return boolean
		 */
		function roleEligible() {
			var roleEligible = false;

			var scriptObj = runtime.getCurrentScript();
			var prefId = scriptObj.getParameter({
				name: 'custscript_vdsa_preference_record'
			});

			if (!prefId) {
				return false;
			}

			// Lookup global preference
			var lookupRes = search.lookupFields({
				type: 'customrecord_vdsa_suiteapp_preference',
				id: prefId,
				columns: 'custrecord_vdsa_vendor_mgmt_roles'
			});
			var vendorMgmtRolesArr = lookupRes.custrecord_vdsa_vendor_mgmt_roles;

			// Get current user role
			var currUserRole = runtime.getCurrentUser().role;

			// Check if current user role is in lookup results
			for (var index in vendorMgmtRolesArr) {
				var roleId = vendorMgmtRolesArr[index]['value'];
				if (currUserRole == roleId) {
					roleEligible = true;
					break;
				}
			}

			return roleEligible;
		}
		
		/**
         * Adds custom form elements to the form from the assets folder
         * @param {nlobjForm} visaForm NetSuite form object passed in and then returned after being mutated with custom asset data
         */
        function addCustomUIAssets(visaForm) {
            try {
                var bundleFolderSearch = search.create({
                    type: "folder",
                    filters: [
                        ["name", "is", APP_ID]
                    ]
                }).run().getRange(0, MAX_SEARCH_RESULT);

                if (bundleFolderSearch.length !== 1) {
                    throw error.create({ name: 'FOLDER ERROR', message: 'ANOTHER FOLDER HAS UTILIZED THIS SUITEAPP\'S PUBLISHER ID', notifyOff: false });
                }

                var bundleFolderId = bundleFolderSearch[0].id;
                var assetResults = search.create({
                    type: "file",
                    filters: [
                        ["folder", "anyof", bundleFolderId],
                        "AND",
                        ["formulatext: {folder}", "is", "Vendor Management Custom Assets"],
                    ],
                    columns: [
                        'name',
                        'filetype'
                    ]
                }).run().getRange(0, MAX_SEARCH_RESULT);

                var assetObj = assetResults.map(function(currentValue) {
                    return {
                        id: currentValue.id,
                        name: currentValue.getValue({ name: 'name' }),
                        type: currentValue.getValue({ name: 'filetype' }),
                    };
                });

                for (var assetIndex = 0; assetIndex < assetObj.length; assetIndex++) {
                    var assetFile = file.load({
                        id: assetObj[assetIndex].id
                    });
                    // log.debug('assetObj', JSON.stringify(assetObj[assetIndex]));

                    // remove extension and prepend custpage to dynamically create field id
                    var assetFieldId = assetObj[assetIndex].name;
                    assetFieldId = assetFieldId.replace('.', '_');
                    assetFieldId = ('custpage_' + assetFieldId).toLowerCase();

                    assetFile.getContents();
                    var assetField = visaForm.addField({
                        id: assetFieldId,
                        type: ui.FieldType.INLINEHTML,
                        label: '(Hidden) Asset field for ' + assetObj[assetIndex].name
                    })

                    switch (assetObj[assetIndex].type) {
                        case 'STYLESHEET': // CSS files
                            assetField.defaultValue = '<style>' + assetFile.getContents() + '</style>';
                            break;
                            // case 'HTMLDOC': // CSS files                        
                            // break;                        
                        default:
                            assetField.defaultValue = assetFile.getContents();
                    }
                }

            } catch (errorObj) {
                throw error.create({
                    name: 'ASSET_LOOKUP_FAILURE',
                    message: errorObj.message,
                    notifyOff: true
                });
            }

            return visaForm;
        }

		/** POLYFILL FOR PAD STRING */
        // https://github.com/uxitten/polyfill/blob/master/string.polyfill.js
        // https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String/padStart
        if (!String.prototype.padStart) {
            String.prototype.padStart = function padStart(targetLength, padString) {
                targetLength = targetLength >> 0; //truncate if number, or convert non-number to 0;
                padString = String(typeof padString !== 'undefined' ? padString : ' ');
                if (this.length >= targetLength) {
                    return String(this);
                } else {
                    targetLength = targetLength - this.length;
                    if (targetLength > padString.length) {
                        padString += padString.repeat(targetLength / padString.length); //append to original to ensure we are longer than needed
                    }
                    return padString.slice(0, targetLength) + String(this);
                }
            };
        }

        function responseHandler(referenceId){
            var returnMsg = 'Card enrollment in progress.'; // + ' Reference Number ' + referenceId + '.';

            // search refernceId in responselogs
            var responseSearch = search.create({
                filters: [
                    { name: 'custrecord_vdsa_cb_refnumber', operator: search.Operator.IS, values: referenceId}
                ],
                type: 'customrecord_vdsa_response_log',
                columns: [
                    'custrecord_vdsa_cb_error',
                    'custrecord_vdsa_cb_reasondetail',
                    'custrecord_vdsa_cb_code_reason',
                    'custrecord_vdsa_cb_card_token',
                    'custrecord_vdsa_cb_refnumber',
                    'custrecord_vdsa_cb_vendor',
                    'custrecord_vdsa_cb_card_number',
					'custrecord_vdsa_cb_authorized'
                ]
            }).run().getRange(0, 1);

            // check if result is found
            if (responseSearch && responseSearch.length > 0) {             
                // if error found in response log then display error
                // else if no error and card number field is empty then create card
                // else response already processed
                var errorResponse = responseSearch[0].getValue('custrecord_vdsa_cb_error');
                log.debug('errorResponse',errorResponse);
                log.debug('errorResponse condition',errorResponse!='');
                var cardResponse = responseSearch[0].getValue('custrecord_vdsa_cb_card_number');
                log.debug('cardResponse',cardResponse);
                log.debug('cardResponse condition',cardResponse=='');
				var failMsg = 'Card enrollment failed.<br>'// + ' Reference Number '+referenceId+'.<br>';
				if(errorResponse != ''){
                    returnMsg = failMsg + errorResponse;
                    log.error('Reference Number',referenceId);
				} else if (cardResponse == ''){
					var authorized = responseSearch[0].getValue('custrecord_vdsa_cb_authorized');
					log.debug('authorized',authorized);
					if (authorized){
						var debitRecord = createDebitRecord(responseSearch[0]);
						if (debitRecord.error == null){
							var maskedCard = debitRecord.maskedCard;
							var action = debitRecord.action;

							// update response log
							var responseLog = record.load({ type: 'customrecord_vdsa_response_log', id: responseSearch[0].id });
							responseLog.setValue({ fieldId: 'custrecord_vdsa_cb_card_number', value: maskedCard });
							responseLog.setValue({ fieldId: 'custrecord_vdsa_cb_action', value: action });
							var logId = responseLog.save();
							log.debug('logId',logId);

							switch(action){
								case VDSA_CONST.CardAction.CREATE:
									returnMsg = 'Card ' + maskedCard +' enrolled.'; break;
								case VDSA_CONST.CardAction.UPDATE:
									returnMsg = 'Card ' + maskedCard +' updated.'; break;
								case VDSA_CONST.CardAction.REENROLL:
									returnMsg = 'Card ' + maskedCard +' re-enrolled.'; break;
								default:
									returnMsg = action; 
							}
						} else {
                            returnMsg = failMsg + debitRecord.error;
                            log.error('Reference Number',referenceId);
						}
					} else {
                        returnMsg = failMsg + responseSearch[0].getValue('custrecord_vdsa_cb_reasondetail');
                        log.error('Reference Number',referenceId);
					}
                } else {
                    returnMsg = '';
                }
            }
            return returnMsg;
        }

        function createDebitRecord(responseLog){
            try {
             
                var token = responseLog.getValue('custrecord_vdsa_cb_card_token');
                var refNum = responseLog.getValue('custrecord_vdsa_cb_refnumber');
                var vendorId = responseLog.getValue('custrecord_vdsa_cb_vendor');

                // Retreive token details
                var tokenDetails = VDSA_TSP.getTokenDetails(token);
                log.debug('tokenDetails',tokenDetails);
                var tokenDetails = JSON.parse(tokenDetails.body);

                log.debug('tokenDetails.isSuccessfull',tokenDetails.isSuccessfull);
                if (!tokenDetails.isSuccessfull){
                    throw 'Error retrieving token details from Token Service Provider.';
                }
                var tokenDetails = tokenDetails.result;
                log.debug('tokenDetails.body.result',tokenDetails);

                // check if an existing token can be found, if found update, otherwise create
                var tokenSearch = search.create({
                    filters: [
                        { name: 'custrecord_vdsa_debit_token', operator: search.Operator.IS, values: token },
                        { name: 'externalid', operator: search.Operator.ANYOF, values: token }
                    ],
                    type: 'customrecord_vdsa_debit_details'
                }).run().getRange(0, 1);

                log.debug('tokenSearch.length',tokenSearch.length);

                var action;
                // if a result is found, load and update
                if (tokenSearch && tokenSearch.length > 0) {
                    var cardPayoutDebitDetail = record.load({ type: 'customrecord_vdsa_debit_details', id: tokenSearch[0].id });
                    // if the card is inactivated, this means user tries to re-enroll the card. activate the card
                    if (cardPayoutDebitDetail.getValue('isinactive')) {
                        cardPayoutDebitDetail.setValue('isinactive', false);
                        action = VDSA_CONST.CardAction.REENROLL;
                    } else {
                            if (cardPayoutDebitDetail.getValue('custrecord_vdsa_debit_card_owner')!=vendorId){
                              log.error('vendorId','Already Enrolled');
                              throw 'Card is already used by different vendor.';
                        }
                        action = VDSA_CONST.CardAction.UPDATE;
                    }
                } else {
                    var cardPayoutDebitDetail = record.create({ type: 'customrecord_vdsa_debit_details' });
                    action = VDSA_CONST.CardAction.CREATE;
                }

                cardPayoutDebitDetail.setValue('custrecord_vdsa_debit_card_owner', vendorId);
                // call getCardType to see if the card type needs to be set as primary vs secondary
                if(!cardPayoutDebitDetail || !cardPayoutDebitDetail.getValue('custrecord_vdsa_debit_type')){
                    cardPayoutDebitDetail.setValue('custrecord_vdsa_debit_type', getCardType(vendorId, token));
                }
                // cardPayoutDebitDetail.setValue('custrecord_vdsa_debit_type', VDSA_CONST.Lists.DebitType.PRIMARY);
                cardPayoutDebitDetail.setValue('custrecord_vdsa_debit_token', token);
                cardPayoutDebitDetail.setValue('externalid', token);
                cardPayoutDebitDetail.setValue('custrecord_vdsa_debit_reference', refNum);
                cardPayoutDebitDetail.setValue('custrecord_vdsa_debit_unenroll_timestamp', null);
                // set record field values using customRecordFieldMapping
                const customRecordFieldMapping = {
                    name: 'last4Digits',
                    custrecord_vdsa_debit_card_type: 'cardCompany',
                    custrecord_vdsa_debit_card_number: 'last4Digits',
                    custrecord_vdsa_debit_expiration_date: ['expirationYear','expirationMonth'],
                    custrecord_vdsa_debit_first_name: 'firstName',
                    custrecord_vdsa_debit_last_name: 'lastName',
                    custrecord_vdsa_debit_billing_zip_code: 'zipCode'
                    // custrecord_vdsa_debit_billing_address1: 'address1',
                    // custrecord_vdsa_debit_billing_address2: 'address2',
                    // custrecord_vdsa_debit_billing_city: 'city',
                    // custrecord_vdsa_debit_billing_state: 'state',
                    // custrecord_vdsa_debit_billing_country: 'countryCode',
                    // custrecord_vdsa_debit_email: 'email',
                    // custrecord_vdsa_debit_phone: 'phoneNumber'
                };

                var maskedCard = '';
                for (var nsField in customRecordFieldMapping) {
                    if (tokenDetails[customRecordFieldMapping[nsField]]){
                        if (nsField === 'name') {
                            tokenDetails[customRecordFieldMapping[nsField]] = 'xxxxxxxxxxxx' + tokenDetails[customRecordFieldMapping[nsField]];
                            maskedCard = tokenDetails[customRecordFieldMapping[nsField]];
                        }
                        cardPayoutDebitDetail.setValue(nsField, tokenDetails[customRecordFieldMapping[nsField]]);
                    }
                    // convert "mm" & "yy" to mm/last_day/yyyy
                    if (nsField === 'custrecord_vdsa_debit_expiration_date') {
                        var expYear = tokenDetails[customRecordFieldMapping[nsField][0]];
                        var expMonth = tokenDetails[customRecordFieldMapping[nsField][1]];
                        // new Date(year, month, date): month is 0 indexed. If date = 0, the date will be set to the last date of last month
                        if (expYear && expMonth){
                            cardPayoutDebitDetail.setValue(nsField, new Date("20" + expYear, expMonth, 0));
                        }
                    }
                }

                var cardId = cardPayoutDebitDetail.save();
                log.debug('cardId', cardId);

                if(!!cardId){
                    autoenrollVendor(vendorId);
                    emailNotification(vendorId, maskedCard);
                }

                // return masked card and action for logging
                return {
                    maskedCard: maskedCard,
                    action: action,
					error: null
                }
            } catch (err) {
                return {
					error: err
				}
            }
        }

        function getCardType(vendorId, token) {
        	// if create, check if there's a card linked to the card owner
        	// if found, set type to secondary
        	// if not found, set type to primary
        	var cardSearchForOwner = search.create({
        		filters: [
        			{name: 'custrecord_vdsa_debit_card_owner',operator: search.Operator.ANYOF,values: vendorId},
        			{name: 'custrecord_vdsa_debit_token',operator: search.Operator.ISNOT,values: token},
        			{name: 'isinactive', operator: search.Operator.IS, values: 'F'},
        			{name: 'custrecord_vdsa_debit_type', operator: search.Operator.ANYOF, values: VDSA_CONST.Lists.DebitType.PRIMARY}
        		],
        		type: 'customrecord_vdsa_debit_details'
            }).run().getRange(0, 10);
            
        	if (cardSearchForOwner && cardSearchForOwner.length > 0){
        		return VDSA_CONST.Lists.DebitType.SECONDARY;
            }else{
                return VDSA_CONST.Lists.DebitType.PRIMARY;
            }
        }

        function autoenrollVendor(vendorId) {
            if (!vendorEnrolled){
                var recId = record.submitFields({
                    type: record.Type.VENDOR,
                    id: parseInt(vendorId),
                    values: { 'custentity_vdsa_visa_direct_eligible': true }
                });
                log.debug('Vendor Enrolled', recId);
            }
        }

        /*
        *This function is for sending an email to the card owner when their card recod has been
        *unenrolled successfully
        */
        function emailNotification(vendorId, debitCardNumber) {
            var senderId;
            var senderHasEmail = false;
            var sendEmailCheckbox;
            var vendorName;
            var vendorEmail;
            var emailBody;
            var emailSubject;

            var vendorSearch = search.lookupFields({
                type: 'vendor',
                id: vendorId,
                columns: ['email', 'entityid']
            });
            var preferenceRecord = runtime.getCurrentScript().getParameter({ name: 'custscript_vdsa_preference_record' }),
                preferenceSearchObject = preferenceSearch(preferenceRecord);

            if (!!preferenceSearchObject) {
                vendorName = vendorSearch.entityid;
                vendorEmail = vendorSearch.email;
                emailBody = emailParser(preferenceSearchObject.custrecord_vdsa_email_body_enrollment, vendorName, debitCardNumber,preferenceSearchObject.custrecord_vdsa_card_sender_email);
                emailSubject = emailParser(preferenceSearchObject.custrecord_vdsa_email_subj_enrollment, vendorName, debitCardNumber,preferenceSearchObject.custrecord_vdsa_card_sender_email);
                senderId = preferenceSearchObject.custrecord_vdsa_email_author_enrollment[0].value;
                sendEmailCheckbox = preferenceSearchObject.custrecord_vdsa_card_enrollment_email;
            }

            if (!!senderId) {
                var senderSearch = search.lookupFields({
                    type: 'employee',
                    id: senderId,
                    columns: ['email']
                });

                if (!!senderSearch.email) {
                    senderHasEmail = true;
                }
            }

            if (!!senderHasEmail && !!sendEmailCheckbox && !!vendorEmail && !!emailBody && !!emailSubject) {
                email.send({
                    author: senderId,
                    recipients: vendorId,
                    subject: emailSubject,
                    body: emailBody
                });
                log.debug('email sent to', vendorEmail);
                log.debug('email sent from', senderId);
            }

        }

        function emailParser(emailText, vendorName, cardNumber,merchantName) {
            var emailParsed = emailText;

            emailParsed = emailParsed.replace(/{vendorName}/g, vendorName);
            emailParsed = emailParsed.replace(/{cardNumber}/g, cardNumber);
            emailParsed = emailParsed.replace(/{companyName}/g, merchantName);

            return emailParsed;
        }

        function preferenceSearch(preferenceId) {
            if (!!preferenceId) {
                var preferenceSearchResult = search.lookupFields({
                    type: 'customrecord_vdsa_suiteapp_preference',
                    id: preferenceId,
                    columns: ['custrecord_vdsa_email_author_enrollment',
                        'custrecord_vdsa_card_enrollment_email',
                        'custrecord_vdsa_email_body_enrollment',
                        'custrecord_vdsa_email_subj_enrollment',
                        'custrecord_vdsa_card_sender_email'
                    ]
                });
                return preferenceSearchResult;
            } else {
                return null;
            }
        }

        return {
            onRequest: onRequest
        };
    });