/**
 * @NApiVersion 2.x
 * @NScriptType Suitelet
 * @NModuleScope SameAccount
 */

/*************************************************************
 * Script   : VDSA_Bulk_Vendor_Status_Page_SU.js
 * Abstract : A Suitelet script that will create the Card Payouts Bulk Vendor Status page.
 * Author   : luke.n.pirtle
 * Revision History :
 *************************************************************
 * Version * Date       * Author              * Description
 *************************************************************
 *   0.1   * 04/17/2019 * luke.n.pirtle       * Initial version
 *   0.2   * 03/10/2020 * jayzar.n.estareja   * Add role eligibility restriction
 *************************************************************/

define(['N/ui/serverWidget', 'N/search', 'N/runtime', 'N/record', 'N/error', './VDSA_Bulk_Vendor_LIB.js', '../Library/VDSA_Utility_LIB.js'],

    function(serverWidget, search, runtime, record, error, bulkLib, utilLib) {

        /**
         * Adds NetSuite native form elements to the form
         * @param {nlobjForm} visaForm NetSuite form object passed in and then returned after being mutated with netsuite asset data
         */
        function addNetSuiteUIAssets(visaForm, taskId, paymentProcessRecId) {

            // var taskStatus = task.checkStatus(taskId);

            var statusSublist = visaForm.addSublist({
                id: 'custpage_subsidiary_sublist_id',
                type: serverWidget.SublistType.STATICLIST,
                label: 'Payment Status',
            });

            nameField = statusSublist.addField({
                id: 'custpage_name',
                type: serverWidget.FieldType.SELECT,
                label: 'Name',
                source: record.Type.VENDOR
            });

            nameField.updateDisplayType({
                displayType: serverWidget.FieldDisplayType.INLINE
            });

            statusField = statusSublist.addField({
                id: 'custpage_status',
                type: serverWidget.FieldType.SELECT,
                label: 'Status',
                source: 'customlist_vdsa_bulk_payments_status'
            });

            statusField.updateDisplayType({
                displayType: serverWidget.FieldDisplayType.INLINE
            });

            amountField = statusSublist.addField({
                id: 'custpage_amount',
                type: serverWidget.FieldType.CURRENCY,
                label: 'Amount',
            });

            amountField.updateDisplayType({
                displayType: serverWidget.FieldDisplayType.INLINE
            });

            errorMessageField = statusSublist.addField({
                id: 'custpage_error_message',
                type: serverWidget.FieldType.TEXT,
                label: 'Error Message',
            });

            errorMessageField.updateDisplayType({
                displayType: serverWidget.FieldDisplayType.INLINE
            });

            var vendorTransactionResults = getStatus(paymentProcessRecId);

            for (var vtIndex = 0; vtIndex < vendorTransactionResults.length; vtIndex++) {
                var currentTransaction = vendorTransactionResults[vtIndex].getValue({ name: 'custrecord_vsda_bvp_transaction' });
                var currentVendor = vendorTransactionResults[vtIndex].getValue({ name: 'custrecord_vsda_bvp_vendor' });
                var currentCurrency = vendorTransactionResults[vtIndex].getValue({ name: 'custrecord_vsda_bvp_currency' });
                var currentDiscount = vendorTransactionResults[vtIndex].getValue({ name: 'custrecord_vsda_bvp_discount' });
                var currentPaymentAmount = vendorTransactionResults[vtIndex].getValue({ name: 'custrecord_vsda_bvp_payment_amount' });
                var currentTransactionStatus = vendorTransactionResults[vtIndex].getValue({ name: 'custrecord_vsda_bvp_transaction_status' });
                var currentErrorMessage = vendorTransactionResults[vtIndex].getValue({ name: 'custrecord_vsda_bvp_error_message' }).substring(0,300);


                statusSublist.setSublistValue({
                    id: 'custpage_name',
                    line: vtIndex,
                    value: currentVendor
                });
                statusSublist.setSublistValue({
                    id: 'custpage_status',
                    line: vtIndex,
                    value: currentTransactionStatus
                });
                statusSublist.setSublistValue({
                    id: 'custpage_amount',
                    line: vtIndex,
                    value: currentPaymentAmount
                });
                if (currentErrorMessage) {
                    statusSublist.setSublistValue({
                        id: 'custpage_error_message',
                        line: vtIndex,
                        value: currentErrorMessage
                    });
                }
            }
            return visaForm;
        }

        function getStatus(paymentProcessRecId) {
            var vendorTransactionResults = utilLib.getAllResults({
                type: "customrecord_vdsa_bulk_vendor_tran",
                filters: [
                    search.createFilter({ name: "custrecord_vdsa_bvp_parent", operator: search.Operator.ANYOF, values: [paymentProcessRecId] }),
                ],
                columns: [
                    search.createColumn({ name: "custrecord_vsda_bvp_transaction" }),
                    search.createColumn({ name: "custrecord_vsda_bvp_vendor" }),
                    search.createColumn({ name: "custrecord_vsda_bvp_currency" }),
                    search.createColumn({ name: "custrecord_vsda_bvp_discount" }),
                    search.createColumn({ name: "custrecord_vsda_bvp_payment_amount" }),
                    search.createColumn({ name: "custrecord_vsda_bvp_transaction_status" }),
                    search.createColumn({ name: "custrecord_vsda_bvp_error_message" })
                ]
            });
            return vendorTransactionResults;
        }

        /**
		 * Function to determine if role of current user is eligible to manage
		 * card payouts of a vendor as configured in the preference page
		 *
		 * @return boolean
		 */
		function roleEligible() {
			var roleEligible = false;

			var scriptObj = runtime.getCurrentScript();
			var prefId = scriptObj.getParameter({
				name: 'custscript_vdsa_preference_record'
			});

			if (!prefId) {
				return false;
			}

			// Lookup global preference
			var lookupRes = search.lookupFields({
				type: 'customrecord_vdsa_suiteapp_preference',
				id: prefId,
				columns: 'custrecord_vdsa_pymt_processing_roles'
			});
			var pmtProcessingRolesArr = lookupRes.custrecord_vdsa_pymt_processing_roles;

			// Get current user role
			var currUserRole = runtime.getCurrentUser().role;

			// Check if current user role is in lookup results
			for (var index in pmtProcessingRolesArr) {
				var roleId = pmtProcessingRolesArr[index]['value'];
				if (currUserRole == roleId) {
					roleEligible = true;
					break;
				}
			}

			return roleEligible;
		}

        return {
            onRequest: function(context) {
                try {
                    if (context.request.method === 'POST') {

                    } else if (context.request.method === 'GET') {
                        if (!roleEligible()){
                            throw error.create({
                                name: 'Access Error',
                                message: 'You are not authorized to view this page.'
                            });
                        }

                        var parameters = context.request.parameters;
                        for (var param in parameters)
                            log.debug({ title: param, details: JSON.stringify(parameters[param]) });
                        var taskId = parameters.taskId;
                        var paymentProcessRecId = parameters.paymentProcessRecId;

                        var visaForm = serverWidget.createForm({ title: 'Card Payouts Bulk Vendor Payment Status' });
                        visaForm = bulkLib.addCustomUIAssets(visaForm) || null;
                        visaForm = addNetSuiteUIAssets(visaForm, taskId, paymentProcessRecId);
                        visaForm.clientScriptModulePath = './VDSA_Bulk_Vendor_Status_Page_CLI.js';
                        visaForm.addButton({
                            id: 'custpage_vdsa_go_back',
                            label: 'Go Back',
                            functionName: 'goBack'
                        });
                        visaForm.addButton({
                            id: 'custpage_vdsa_refresh',
                            label: 'Refresh',
                            functionName: 'refreshStatusPage'
                        });
                        // write form to page
                        context.response.writePage(visaForm);
                    }
                } catch (errorObj) {
                    log.debug({ title: 'Error Details', details: JSON.stringify(errorObj) });
                    throw errorObj.message;
                }
            }
        };
    });