/**
 * @NApiVersion 2.x
 * @NScriptType ClientScript
 * @NModuleScope SameAccount
 */

/*************************************************************
 * Script   : VDSA_Bulk_Vendor_Status_Page_CLI.js
 * Abstract : A Suitelet script that will create the Card Payouts Bulk Vendor Status page.
 * Author   : luke.n.pirtle
 * Revision History :
 *************************************************************
 * Version * Date       * Author              * Description
 *************************************************************
 *   0.1   * 04/17/2019 * luke.n.pirtle       * Initial version
 *   0.2   * 03/19/2020 * jayzar.n.estareja   * Update header
 *************************************************************/

define(['N/url', 'N/ui/dialog', 'N/currentRecord', 'N/search', 'N/runtime', 'N/https', 'N/ui/message', 'N/record', 'N/format', '../Library/VDSA_LIB_constantsFile.js'],

    function(url, dialog, currentRecord, search, runtime, https, message, record, format, VDSA_CONST) {

        return {
            pageInit: function(context) {
                 /*
                 * MANUALLY RESET DOCUMENT TITLE
                 * The title is set manually because netsuite overwrites the title with the form title which has inline html which needs to be sanitized
                 */
                document.title = 'Card Payouts Bulk Vendor Payment Status';
                console.log('Hello World');
            },
            fieldChanged: function(context) {},
            goBack: function() {
                var bulkVendorPaymentSuitelet = url.resolveScript({
                    scriptId: 'customscript_vdsa_bulk_vendor_payments', // TODO: inconsistent should rename
                    deploymentId: 'customdeploy_vdsa_bulk_vendor_payments'
                });
                window.onbeforeunload = function() { return; };
                window.location = bulkVendorPaymentSuitelet;
            },
            refreshStatusPage: function() {
                window.location.reload(true); 
            }
        };
    });