/**
 * @NApiVersion 2.x
 * @NScriptType ClientScript
 * @NModuleScope SameAccount
 */

/*************************************************************
 * Script   : VDSA_Bulk_Vendor_Payment_Page_CLI.js
 * Abstract : A Suitelet script that will create the Card Payouts Bulk Vendor Payment page.
 * Author   : luke.n.pirtle
 * Revision History :
 *************************************************************
 * Version * Date       * Author              * Description
 *************************************************************
 *   0.1   * 04/13/2019 * luke.n.pirtle       * Initial version
 *   0.2   * 03/19/2020 * jayzar.n.estareja   * Update header
 *   0.3   * 03/23/2020 * jayzar.n.estareja   * Update dataTable
 *************************************************************/

define(['N/url', 'N/ui/dialog', 'N/currentRecord', 'N/search', 'N/runtime', 'N/https', 'N/ui/message', 'N/record', 'N/format', '../Library/VDSA_LIB_constantsFile.js'],

    function(url, dialog, currentRecord, search, runtime, https, message, record, format, VDSA_CONST) {

        // Global-ish variable to make referencing columns easier. Datatables doesn't have a good way to reference them from the datatables object
        var headerNamesToIndex = {};

        /**
         * Round the numbers to a specific number of precision
         * @param  {[type]} num       [description]
         * @param  {[type]} precision [description]
         * @return {[type]}           [description]
         */
        function roundNumber(num,precision){
            precision = typeof precision === 'undefined' ? 2 : precision;
            return Math.round(num * Math.pow(10,precision)) / Math.pow(10,precision);
        }

        /**
         * Updates fields with values sourced from treasury bank
         * @return {[type]} [description]
         */
        function updateTreasuryBankFields() {
            var cRec = currentRecord.get();
            // displays name and value is internalid
            var treasuryBankName = cRec.getValue({ fieldId: 'custpage_vdsa_treasury_bank_name' });
            var treasuryBankDetail = treasuryBankDetails[treasuryBankName];
            cRec.setValue({ fieldId: 'custpage_vdsa_balance', value: parseFloat(treasuryBankDetail.availableBalance) });
            cRec.setValue({ fieldId: 'custpage_vdsa_available_balance', value: parseFloat(treasuryBankDetail.balance) });
            cRec.setValue({ fieldId: 'custpage_vdsa_threshold', value: parseFloat(treasuryBankDetail.threshold) });
            // only will do something if one world. if the field exists it will fail silently and gracefully
            cRec.setValue({ fieldId: 'custpage_vdsa_subsidiary', value: treasuryBankDetail.subsidiary });
            cRec.setValue({ fieldId: 'custpage_vdsa_treasury_bank_account', value: treasuryBankDetail.account });
            cRec.setValue({ fieldId: 'custpage_vdsa_treasury_bank_currency', value: treasuryBankDetail.currency });
        }

        /**
         * Determines if subtotal amounts are valid for the current selection
         * @return {[type]} [description]
         */
        function validateThresholdAmount() {
            var cRec = currentRecord.get();
            var threshold = cRec.getValue({ fieldId: 'custpage_vdsa_threshold' });
            var thresholdFormatted = format.format({
                type: format.Type.CURRENCY,
                value: threshold
            });
            var vendorAmounts = cRec.getValue({ fieldId: 'custpage_vdsa_subtotals_json' });
            if (vendorAmounts !== '') {
                var vendorAmounts = JSON.parse(vendorAmounts);
                var subtotalHTML = [];
                for (var vendor in vendorAmounts) {
                    if (vendorAmounts[vendor] > threshold) {
                        subtotalHTML.push('<li>' + vendor + ' : ' + format.format({
                            type: format.Type.CURRENCY,
                            value: roundNumber(vendorAmounts[vendor])
                        }));
                    }
                }

                // if any vendor subtotals exceed the threshold then create error message
                if (subtotalHTML.length > 0) {
                    message.create({
                        type: message.Type.WARNING,
                        title: 'Threshold Amount ' + thresholdFormatted + ' has been exceeded',
                        message: subtotalHTML,
                        duration: 8000
                    }).show();
                    jQuery("html, body").animate({ scrollTop: 0 }, "slow");
                    return true;
                } else {
                    return true;
                }
            }

            return false;
        }

        return {
            pageInit: function(context) {
                /*
                 * MANUALLY RESET DOCUMENT TITLE
                 * The title is set manually because netsuite overwrites the title with the form title which has inline html which needs to be sanitized
                 */
                document.title = 'Card Payouts Bulk Vendor Payment';
                // kept to make debugging and break points easier
                // console.log('hello world');
                var cRec = context.currentRecord;


                // Obtain header to index mapping and also which headers to hide
                var hiddenColumnsIndices = [];
                for (var i = 0; i < dataTablesColumns.length; i++) {
                    var headerTitle = dataTablesColumns[i].title;
                    headerNamesToIndex[headerTitle] = i;
                    // dynamically find all columns that should be hidden
                    if (headerTitle.indexOf(VDSA_CONST.Constants.HIDDEN_FIELD_POSTFIX) !== -1) {
                        hiddenColumnsIndices.push(i);
                    }
                }
                /*
                 * Initialize Data Table
                 */
                var vendorBillsDataTable = jQuery('#bulkPaymentsTable').DataTable({
                    dom: 'Bfrtip',
                    data: dataTablesValues,
                    columns: dataTablesColumns,
                    columnDefs: [
                        {
                            // create initial checkbox first column
                            orderable: false,
                            className: 'select-checkbox',
                            targets: 0
                        },{
                            orderable: false,
                            targets: [3,14,15,17,18]
                        },{
                            // hide the fields only meant for data purposes. Marked (Hidden)
                            targets: hiddenColumnsIndices,
                            visible: false,
                        }
                    ],
                    select: {
                        style: 'multi+shift',
                        // only allow row to be selected with checkbox row
                        selector: 'td:first-child',
                    },
                    // I told you no paging
                    paging: false,
                    info: false,
                    order: [ 2, 'asc' ],
                    buttons: [
                        // this is a custom button that works just like default select all but only for the filtered elements
                        {
                            text: 'Mark All',
                            action: function(e, dt, node, config) {
                                // applied = filtered elements. We only select the filtered elements
                                dt.rows({ search: 'applied' }).select();
                            }
                        },
                        // use default select none button
                        'selectNone',
                    ],
                    language: {
                        buttons: {
                            selectAll: "Mark All",
                            selectNone: "Unmark All"

                        }
                    }
                });

                // unfortunate jQuery hack to solve netsuite field group issue. Field group creates numerous parent elements with limited width so table doesn't span the full page
                var outerTable = jQuery('#bulkPaymentsTable').closest('.uir-outside-fields-table').width('100%');
                outerTable.parents('table').width('100%');

                /**
                 * Event handler for selected elements subtotals and check threshold
                 * @return {[type]}          [description]
                 */
                vendorBillsDataTable.on('select.dt', updateSelected);
                vendorBillsDataTable.on('deselect.dt', updateSelected);
                jQuery('.bulk-vendor-amount').on('blur', updateSubtotals);
                jQuery('.bulk-vendor-discount').on('blur', updateSubtotals);

                function updateSelected(e, dt, type, indexes) {
                    if (type === 'row') {
                        // set payment amount for each row if one was previously not set or clear value on deselect
                        var amountRemainingIndex = headerNamesToIndex['Amount Due'];
                        var discountColumnIndex = headerNamesToIndex['Disc. Taken'];
                        var paymentColumnIndex = headerNamesToIndex['Payment'];
                        for (var i = 0; i < indexes.length; i++) {
                            var rowIndex = indexes[i];
                            var existingAmount = vendorBillsDataTable.cell(rowIndex, paymentColumnIndex).nodes().to$().find('input').val();
                            if (e.type === 'select') {
                                if (!existingAmount) {
                                    var dtRowAmountRemaining = vendorBillsDataTable.cell(rowIndex, amountRemainingIndex).data();
                                    var dtParsedRowAmountRemaining = format.parse({
                                        type: format.Type.CURRENCY,
                                        value: dtRowAmountRemaining
                                    });
                                    vendorBillsDataTable.cell(rowIndex, paymentColumnIndex).nodes().to$().find('input').val(dtParsedRowAmountRemaining);
                                }
                            } else if (e.type === 'deselect') {
                                vendorBillsDataTable.cell(rowIndex, paymentColumnIndex).nodes().to$().find('input').val('');
                                //vendorBillsDataTable.cell(rowIndex, discountColumnIndex).nodes().to$().find('input').val('');
                            }

                        }

                        updateSubtotals();
                        validateThresholdAmount();
                    }
                }

                function updateSubtotals() {
                    // need to iterate through all selected elements not jsut selected or deselected elements
                    var dtSelectedRows = vendorBillsDataTable.rows({ selected: true }).data();
                    var dtSelectedRowsIndexes = vendorBillsDataTable.rows({ selected: true })[0];
                    var dtRowSum = 0;
                    var vendorAmounts = {};
                    var amountRemainingIndex = headerNamesToIndex['Amount Due'];
                    var vendorColumnIndex = headerNamesToIndex['Vendor'];
                    var paymentColumnIndex = headerNamesToIndex['Payment'];
                    var discountColumnIndex = headerNamesToIndex['Disc. Taken'];

                    for (var dtDataIndex = 0; dtDataIndex < dtSelectedRows.length; dtDataIndex++) {
                        var dtCurrentRow = dtSelectedRows[dtDataIndex];
                        var dtRowIndex = dtSelectedRowsIndexes[dtDataIndex];
                        var dtRowAmountRemaining = dtSelectedRows[dtDataIndex][amountRemainingIndex];
                        var dtRowPaymentAmount = vendorBillsDataTable.cell(dtRowIndex, paymentColumnIndex).nodes().to$().find('input').val();
                        var dtRowDiscountAmount = vendorBillsDataTable.cell(dtRowIndex, discountColumnIndex).nodes().to$().find('input').val() || 0;
                        var dtRowVendor = dtSelectedRows[dtDataIndex][vendorColumnIndex];

                        var lineDiscount = format.parse({ type: format.Type.CURRENCY, value: dtRowDiscountAmount });

                        if (lineDiscount){
                            // if a discount exists then always calculate amount from total - discount to prevent perpetual discounting
                            var lineAmount = format.parse({
                                type: format.Type.CURRENCY,
                                value: dtRowAmountRemaining
                            });

                            // add discount validation
                            // if it couldn't be parsed
                            if (typeof lineDiscount === 'string') {
                                // clear discount
                                vendorBillsDataTable.cell(dtRowIndex, discountColumnIndex).nodes().to$().find('input').val('');
                            } else { // if its a parsed number
                                if (lineDiscount >= lineAmount) { // if discount higher than amount then throw it away
                                    vendorBillsDataTable.cell(dtRowIndex, discountColumnIndex).nodes().to$().find('input').val('');
                                } else {
                                    lineAmount -= lineDiscount;
                                    vendorBillsDataTable.cell(dtRowIndex, paymentColumnIndex).nodes().to$().find('input').val(roundNumber(lineAmount));
                                }
                            }
                        } else {
                            // if no discount then amount can be the amount in the input from manual or automatic population or the remaining amount if not previously clicked
                            var lineAmount = format.parse({
                                type: format.Type.CURRENCY,
                               value: dtRowPaymentAmount || dtRowAmountRemaining
                            });
                          vendorBillsDataTable.cell(dtRowIndex, paymentColumnIndex).nodes().to$().find('input').val(roundNumber(lineAmount));
                        }


                        if (vendorAmounts[dtRowVendor] === undefined) {
                            vendorAmounts[dtRowVendor] = lineAmount;
                        } else {
                            vendorAmounts[dtRowVendor] += lineAmount;
                        }
                        dtRowSum += lineAmount;
                        // default amount entered
                    }

                    cRec.setValue({ fieldId: 'custpage_vdsa_amount', value: dtRowSum });

                    // display subtotals
                    var subtotalHTML = [];
                    for (var vendor in vendorAmounts) {
                        subtotalHTML.push('<li>' + vendor + ': ' + format.format({
                            type: format.Type.CURRENCY,
                            value: vendorAmounts[vendor]
                        }));
                    }
                    // log subtotals in rich text field 
                    cRec.setValue({ fieldId: 'custpage_vdsa_subtotals', value: subtotalHTML.join('<br>') });
                    // store JSON in hidden field for use in other functions
                    cRec.setValue({ fieldId: 'custpage_vdsa_subtotals_json', value: JSON.stringify(vendorAmounts) });
                }

                // Adding on to datafilters search validation
                jQuery.fn.dataTableExt.afnFiltering.push(
                    /**
\                    * Custom Date Handler
                     */
                    function(settings, data, dataIndex) {
                        var dateFrom = cRec.getValue({ fieldId: 'custpage_vdsa_date_from_filter' });
                        var dateTo = cRec.getValue({ fieldId: 'custpage_vdsa_date_to_filter' });
                        var nowDate = new Date();
                        if (dateFrom === '') dateFrom = new Date(0); // epoch. won't ever be a date before this
                        if (dateTo === '') dateTo = new Date(nowDate.getFullYear() + 100, 0, 0); // 100 years in the future won't ever fail

                        if ((typeof dateTo === 'object' && dateTo instanceof Date) && (typeof dateFrom === 'object' && dateFrom instanceof Date)) {
                            dateFrom.getTime();
                            dateTo.getTime();
                            var dueDate = new Date(data[headerNamesToIndex['Due Date']]);
                            if (dueDate.getTime() >= dateFrom.getTime() && dueDate.getTime() <= dateTo.getTime())
                                return true;
                            else
                                return false;
                        } else {
                            // invalid filter so don't filter
                            return true;
                            // clear filters
                        }
                    },
                    /**
\                    * Custom AP Account filter
                     */
                    function(settings, data, dataIndex) {
                        var apAccount = cRec.getValue({ fieldId: 'custpage_vdsa_ap_account' });
                        var hiddenAccountFieldValue = data[headerNamesToIndex['Accounts Payable ' + VDSA_CONST.Constants.HIDDEN_FIELD_POSTFIX]];
                        if (apAccount === hiddenAccountFieldValue)
                            return true;
                        else {
                            return false;
                        }
                    },
                    /**
\                    * Custom Subsidiary filter
                     */
                    function(settings, data, dataIndex) {
                        var subsidiary = cRec.getValue({ fieldId: 'custpage_vdsa_subsidiary' });
                        var hiddenAccountFieldValue = data[headerNamesToIndex['Subsidiary ' + VDSA_CONST.Constants.HIDDEN_FIELD_POSTFIX]];
                        if (subsidiary === hiddenAccountFieldValue)
                            return true;
                        else {
                            return false;
                        }
                    },
                    /**
\                    * Custom Currency filter
                     */
                    function(settings, data, dataIndex) {
                        var currency = cRec.getValue({ fieldId: 'custpage_vdsa_treasury_bank_currency' });
                        var treasuryBankName = cRec.getValue({ fieldId: 'custpage_vdsa_treasury_bank_name' });
                        var thisTreasuryBank = treasuryBankDetails[treasuryBankName];
                        if (thisTreasuryBank.isBaseCurrency) {
                            // accounts with the same base currency as their subsidiary can process different supported currencies
                            var availableCurrencies = thisTreasuryBank.availableCurrencies.split(',');
                            return (availableCurrencies.indexOf(currency) !== -1) ? true : false;
                        } else {
                            // accounts with base currencies that differ from their subsidiary cannot process different supported currencies
                            var hiddenAccountFieldValue = data[headerNamesToIndex['Currency ' + VDSA_CONST.Constants.HIDDEN_FIELD_POSTFIX]];
                            return (currency === hiddenAccountFieldValue) ? true : false;
                        }
                    }
                );


                /*
                 * default / initialize values
                 */
                updateTreasuryBankFields();
                cRec.setValue({ fieldId: 'custpage_vdsa_date', value: new Date() });
                jQuery('#bulkPaymentsTable').DataTable().draw();

            },
            fieldChanged: function(context) {
                switch (context.fieldId) {
                    //FALL THROUGH SWITCH STATEMENTS
                    case 'custpage_vdsa_treasury_bank_name':
                        updateTreasuryBankFields();
                        validateThresholdAmount();
                        // all filters just require a redraw. All filter functions are initialize in pageInit();
                    case 'custpage_vdsa_subsidiary_filter':
                    case 'custpage_vdsa_date_from_filter':
                    case 'custpage_vdsa_date_to_filter':
                    case 'custpage_vdsa_ap_account':
                        jQuery('#bulkPaymentsTable').DataTable().draw();
                }
            },
          
          /**********************************************************************************************************************
           * Visa Toolkit Note:																 									*
           * 													 	                            								*
           * The createBill is a function that calls out the Map/Reduce Script to create Vendor Payment for each Bills   		*
           * To enable, once the paymentTransaction API in the LIB file has been set, remove the comment for the function		*
           * No modification needed for this as Bulk processing relies on the WFA for Single Payment	 						*
           * Modify as deemed necessary based on your requirement																*
           **********************************************************************************************************************/
            /*createBill: function() {
                try {
                    console.log('That\'s some good bill creation there boys');
                    var cRec = currentRecord.get();
                    var vendorAmounts = cRec.getValue({ fieldId: 'custpage_vdsa_subtotals_json' });

                    // if no bills selected
                    if (vendorAmounts === '') {
                        message.create({
                            type: message.Type.ERROR,
                            title: 'Bill(s) not created',
                            message: 'There are no bills selected...',
                            duration: 8000
                        }).show();
                    }

                    var isAmountValid = validateThresholdAmount();
                    if (isAmountValid) {
                        // get header level info
                        var payloadObject = {
                            action: 'createBills',
                            treasuryBankName: cRec.getValue({ fieldId: 'custpage_vdsa_treasury_bank_name' }),
                            subsidiary: cRec.getValue({ fieldId: 'custpage_vdsa_subsidiary' }),
                            apAccount: cRec.getValue({ fieldId: 'custpage_vdsa_ap_account' }),
                            date: format.format({
                                type: format.Type.DATE,
                                value: cRec.getValue({ fieldId: 'custpage_vdsa_date' }),
                            }),
                            posting_period: cRec.getValue({ fieldId: 'custpage_vdsa_posting_period' }),
                            default_classification: cRec.getValue({ fieldId: 'custpage_vdsa_default_classification' }),
                            default_department: cRec.getValue({ fieldId: 'custpage_vdsa_default_department' }),
                            default_location: cRec.getValue({ fieldId: 'custpage_vdsa_default_location' }),
                        };

                        // obtain selected datatables row
                        var vendorBillsDataTable = jQuery('#bulkPaymentsTable').DataTable();
                        var dtSelectedRowsIndexes = vendorBillsDataTable.rows({ selected: true })[0];
                        // needed indexes for data retrival from the datatable
                        var vendorColumnIndex = headerNamesToIndex['Name ' + VDSA_CONST.Constants.HIDDEN_FIELD_POSTFIX];
                        var currencyColumnIndex = headerNamesToIndex['Currency ' + VDSA_CONST.Constants.HIDDEN_FIELD_POSTFIX];
                        var paymentColumnIndex = headerNamesToIndex['Payment'];
                        var discountColumnIndex = headerNamesToIndex['Disc. Taken'];
                        var InternalidColumnIndex = headerNamesToIndex['Internalid ' + VDSA_CONST.Constants.HIDDEN_FIELD_POSTFIX];
                        var billPaymentDetails = [];
                        for (var dtRowIndex = 0; dtRowIndex < dtSelectedRowsIndexes.length; dtRowIndex++) {
                            var rowIndex = dtSelectedRowsIndexes[dtRowIndex];
                            billPaymentDetails.push({
                                dtRowInternalid: vendorBillsDataTable.cell(rowIndex, InternalidColumnIndex).data(),
                                dtRowAmount: vendorBillsDataTable.cell(rowIndex, paymentColumnIndex).nodes().to$().find('input').val(),
                                dtRowDiscount: vendorBillsDataTable.cell(rowIndex, discountColumnIndex).nodes().to$().find('input').val(),
                                dtRowCurrency: vendorBillsDataTable.cell(rowIndex, currencyColumnIndex).data(),
                                dtRowVendor: vendorBillsDataTable.cell(rowIndex, vendorColumnIndex).data(),
                            });
                        }

                        payloadObject.billDetailObj = JSON.stringify(billPaymentDetails);

                        var bulkVendorPaymentSuitelet = url.resolveScript({
                            scriptId: 'customscript_vdsa_bulk_vendor_payments', // TODO: inconsistent should rename
                            deploymentId: 'customdeploy_vdsa_bulk_vendor_payments'
                        });

                        var signedFormRequest = https.post({
                            url: bulkVendorPaymentSuitelet,
                            body: payloadObject
                        });

                        if (signedFormRequest.code === 200) {
                            var params = JSON.parse(signedFormRequest.body);
                            var bulkVendorPaymentStatusPageSuitelet = url.resolveScript({
                                scriptId: 'customscript_vdsa_bulk_vendor_status', // TODO: inconsistent should rename
                                deploymentId: 'customdeploy_vdsa_bulk_vendor_status',
                                params: params
                            });
                            window.onbeforeunload = function() { return; };
                            window.open(bulkVendorPaymentStatusPageSuitelet);
                        } else {
                            message.create({
                                type: message.Type.ERROR,
                                title: 'Failed to initiate bulk payment...',
                                message: 'bulk payment failure: ' + JSON.stringify(signedFormRequest),
                                duration: 8000
                            }).show();
                            jQuery("html, body").animate({ scrollTop: 0 }, "slow");
                        }

                    } else {
                        // scroll to top to show any threshold violations
                        jQuery("html, body").animate({ scrollTop: 0 }, "slow");
                    }
                } catch (errorObj) {
                    message.create({
                        type: message.Type.ERROR,
                        title: 'Payment(s) not created',
                        message: 'There was an issue processing bills. Please contact an administrator',
                        duration: 8000
                    }).show();
                }
            }*/
        };
    });