/**
 * @NApiVersion 2.x
 * @NScriptType Suitelet
 * @NModuleScope SameAccount
 */

/*************************************************************
 * Script   : VDSA_Bulk_Vendor_Payment_Page_SU.js
 * Abstract : A Suitelet script that will create the Card Payouts Bulk Vendor Payment page.
 * Author   : luke.n.pirtle
 * Revision History :
 *************************************************************
 * Version * Date       * Author              * Description
 *************************************************************
 *   0.1   * 04/13/2019 * luke.n.pirtle       * Initial version
 *   0.2   * 03/10/2020 * jayzar.n.estareja   * Add role eligibility restriction
 *   0.3   * 03/18/2020 * darryl.d.caparas    * Update fields
 *   0.4   * 03/19/2020 * jayzar.n.estareja   * NetSuite UI alignment
 *************************************************************/

define(['N/ui/serverWidget', 'N/search', 'N/runtime', 'N/record', 'N/error', 'N/task', 'N/url', 'N/format', './VDSA_Bulk_Vendor_LIB.js', '../Library/VDSA_Utility_LIB.js', '../Library/VDSA_LIB_constantsFile.js'],

    function(serverWidget, search, runtime, record, error, task, url, format, bulkLib, utilLib, VDSA_CONST) {

        /**
         * Adds NetSuite native form elements to the form
         * @param {nlobjForm} visaForm NetSuite form object passed in and then returned after being mutated with netsuite asset data
         */
        function addNetSuiteUIAssets(visaForm) {

            // get treasury bank details and set as a variable in script for use in client script
            var treasuryBankDetails = getTreasuryBankAccounts();
            var treasuryBankDetailsField = visaForm.addField({
                id: 'custpage_vdsa_treasury_bank_details',
                type: serverWidget.FieldType.INLINEHTML,
                label: 'dataTablesSearchValues',
            });

            treasuryBankDetailsField.defaultValue = '<script type="text/javascript">' +
                'var treasuryBankDetails = ' + JSON.stringify(treasuryBankDetails.treasuryAccounts) + ';\n' +
                '</script>';

            var primaryInformationFieldGroup = visaForm.addFieldGroup({
                id: 'primaryInformation',
                label: 'Primary Information',
            });

            /*
             *  CREATE INPUT AND SOURCED VALUE FIELDS
             */

            var apAccountField = visaForm.addField({
                id: 'custpage_vdsa_ap_account',
                type: serverWidget.FieldType.SELECT,
                label: 'A/P Account',
                container: 'primaryInformation',
            });

            // populate with AP account values
            var apAccounts = getAPAccounts();
            apAccountField = addSourceValuesToField(apAccountField, apAccounts);

            var treasuryBankNameField = visaForm.addField({
                id: 'custpage_vdsa_treasury_bank_name',
                type: serverWidget.FieldType.SELECT,
                label: 'Corporate Bank',
                container: 'primaryInformation',
            });

            treasuryBankNameField.updateDisplayType({
                displayType: serverWidget.FieldDisplayType.HIDDEN
            });

            // populate with Treasury account values
            treasuryBankNameField = addSourceValuesToField(treasuryBankNameField, treasuryBankDetails.treasuryNameFieldSourcing);

            var treasuryBankAccountField = visaForm.addField({
                id: 'custpage_vdsa_treasury_bank_account',
                type: serverWidget.FieldType.SELECT,
                label: 'Account',
                container: 'primaryInformation',
                source: 'account',
            });

            treasuryBankAccountField.updateDisplayType({
                displayType: serverWidget.FieldDisplayType.INLINE
            });

            var treasuryBankCurrency = visaForm.addField({
                id: 'custpage_vdsa_treasury_bank_currency',
                type: serverWidget.FieldType.SELECT,
                label: 'Corporate Bank Currency',
                container: 'primaryInformation',
                source: 'currency',
            });

            treasuryBankCurrency.updateDisplayType({
                displayType: serverWidget.FieldDisplayType.HIDDEN
            });

            var balanceField = visaForm.addField({
                id: 'custpage_vdsa_balance',
                type: serverWidget.FieldType.CURRENCY,
                label: 'Balance',
                container: 'primaryInformation',
            });

            balanceField.updateDisplayType({
                displayType: serverWidget.FieldDisplayType.DISABLED
            });

            var availableBalanceField = visaForm.addField({
                id: 'custpage_vdsa_available_balance',
                type: serverWidget.FieldType.CURRENCY,
                label: 'Available Balance',
                container: 'primaryInformation',
            });

            availableBalanceField.updateDisplayType({
                displayType: serverWidget.FieldDisplayType.INLINE
            });

            

            var thresholdField = visaForm.addField({
                id: 'custpage_vdsa_threshold',
                type: serverWidget.FieldType.CURRENCY,
                label: 'Threshold',
                container: 'primaryInformation',
            });

            var postingPeriodField = visaForm.addField({
                id: 'custpage_vdsa_posting_period',
                type: serverWidget.FieldType.SELECT,
                label: 'Posting Period',
                container: 'primaryInformation',
                source: 'accountingperiod',
            });

            if (bulkLib.isOneWorld) {
                var subsidiaryField = visaForm.addField({
                    id: 'custpage_vdsa_subsidiary',
                    type: serverWidget.FieldType.SELECT,
                    label: 'Subsidiary',
                    container: 'primaryInformation',
                    source: 'subsidiary',
                });

                subsidiaryField.updateDisplayType({
                    displayType: serverWidget.FieldDisplayType.INLINE
                });
            }

            var amountField = visaForm.addField({
                id: 'custpage_vdsa_amount',
                type: serverWidget.FieldType.CURRENCY,
                label: 'Amount',
                container: 'primaryInformation',
            });

            var dateField = visaForm.addField({
                id: 'custpage_vdsa_date',
                type: serverWidget.FieldType.DATE,
                label: 'Date',
                container: 'primaryInformation',
            });
          
            var dateFromField = visaForm.addField({
                id: 'custpage_vdsa_date_from_filter',
                type: serverWidget.FieldType.DATE,
                label: 'Start Date',
                container: 'primaryInformation',
            });

            var dateField = visaForm.addField({
                id: 'custpage_vdsa_date_to_filter',
                type: serverWidget.FieldType.DATE,
                label: 'End Date',
                container: 'primaryInformation',
            });

            amountField.updateDisplayType({
                displayType: serverWidget.FieldDisplayType.DISABLED
            });

            thresholdField.updateDisplayType({
                displayType: serverWidget.FieldDisplayType.INLINE
            });

            var thresholdField = visaForm.addField({
                id: 'custpage_vdsa_subtotals',
                type: serverWidget.FieldType.RICHTEXT,
                label: 'Subtotals',
                container: 'primaryInformation',
            });

            thresholdField.updateDisplayType({
                displayType: serverWidget.FieldDisplayType.INLINE
            });

            var thresholdField = visaForm.addField({
                id: 'custpage_vdsa_subtotals_json',
                type: serverWidget.FieldType.LONGTEXT,
                label: 'Subtotals',
                container: 'primaryInformation',
            });

            thresholdField.updateDisplayType({
                displayType: serverWidget.FieldDisplayType.HIDDEN
            });

            /*
             * CLASSIFICATION FIELDS
             */

            // check to see what segmentation is enabled
            // only add group if at least segmentations are turned on 
            if (bulkLib.isLocationsEnabled || bulkLib.isClassesEnabled || bulkLib.isDepartmentsEnabled) {

                var classificationFieldGroup = visaForm.addFieldGroup({
                    id: 'classification',
                    label: 'Classification',
                });

                if (bulkLib.isClassesEnabled) {
                    var departmentSegmentField = visaForm.addField({
                        id: 'custpage_vdsa_default_department',
                        type: serverWidget.FieldType.SELECT,
                        label: 'Department',
                        container: 'classification',
                        source: 'department'
                    });
                }

                if (bulkLib.isDepartmentsEnabled) {
                    var classificationSegmentField = visaForm.addField({
                        id: 'custpage_vdsa_default_classification',
                        type: serverWidget.FieldType.SELECT,
                        label: 'Class',
                        container: 'classification',
                        source: 'classification'
                    });
                }

                if (bulkLib.isLocationsEnabled) {
                    var locationSegmentField = visaForm.addField({
                        id: 'custpage_vdsa_default_location',
                        type: serverWidget.FieldType.SELECT,
                        label: 'Location',
                        container: 'classification',
                        source: 'location'
                    });
                }
            }

            return visaForm;
        }

        /**
         * Add nonstandard filters
         * @param {[type]} visaForm [description]
         */
        function addNetSuiteFilters(visaForm) {

            var filtersFieldGroup = visaForm.addFieldGroup({
                id: 'filtersList',
                label: 'Filters',
            });

            

            

            return visaForm;
        }

        /**
         * Obtains all valid vendor bills to display for bulk payments to be displayed in the Datatable UI and stores the data in an inline html 
         * field to be initialized upon page init
         * @param {[type]} visaForm [description]
         */
        function AddVendorBills(visaForm) {
            // add this to the label and the column will be hidden

            var filters = [
                search.createFilter({ name: "type", operator: search.Operator.ANYOF, values: ["VendBill", "ExpRept"] }),
                search.createFilter({ name: "status", operator: search.Operator.ANYOF, values: "VendBill:A" }),
                search.createFilter({ name: "mainline", operator: search.Operator.IS, values: true }),
                search.createFilter({ name: "custentity_vdsa_visa_direct_eligible", join: 'vendor', operator: search.Operator.IS, values: true }),
                search.createFilter({ name: "isinactive", join: 'vendor', operator: search.Operator.IS, values: false }),
                search.createFilter({ name: "transactionnumber", operator: search.Operator.ISNOTEMPTY, values: true })
            ];
            var columns = [
                search.createColumn({ name: "internalid", label: "Internalid " + VDSA_CONST.Constants.HIDDEN_FIELD_POSTFIX }),
                search.createColumn({ name: "duedate", label: "Due Date" }),
                search.createColumn({ name: "type", label: "Type" }),
                search.createColumn({ name: "entityid", join: "vendor", label: "Vendor" }),
                search.createColumn({ name: "internalid", join: "vendor", label: "Name " + VDSA_CONST.Constants.HIDDEN_FIELD_POSTFIX }),
              	search.createColumn({ name: "tranid", label: "Ref #"}),
                search.createColumn({ name: "transactionnumber", label: "Transaction #" }),
                search.createColumn({ name: "currency", label: "Currency" }),
                search.createColumn({ name: "currency", label: "Currency " + VDSA_CONST.Constants.HIDDEN_FIELD_POSTFIX }),
                search.createColumn({ name: "exchangerate", label: "Exchange Rate" + VDSA_CONST.Constants.HIDDEN_FIELD_POSTFIX }),
                search.createColumn({ name: "amount", label: "Original Amount" }),
                search.createColumn({ name: "amountremaining", label: "Amount Due" }),
                search.createColumn({ name: "account", label: "Accounts Payable " + VDSA_CONST.Constants.HIDDEN_FIELD_POSTFIX }),
                search.createColumn({ name:  "termsdiscountdate", label:"Disc. Date"}),
                search.createColumn({ name:  "termsdiscountamount", label:"Disc. Avail."})

            ];

            if (bulkLib.isOneWorld) {
                columns.push(search.createColumn({ name: 'subsidiary', label: "Subsidiary " + VDSA_CONST.Constants.HIDDEN_FIELD_POSTFIX }));
            }

            var vendorBillsResults = utilLib.getAllResults({
                type: search.Type.TRANSACTION,
                filters: filters,
                columns: columns,
                settings: [
                    search.createSetting({
                        name: 'consolidationtype',
                        value: 'NONE'
                    })
                ]
            });

            var dataTablesValues = vendorBillsResults.map(function(result) {
                var resultSubsidiary = bulkLib.isOneWorld ? result.getValue({ name: "subsidiary" }) : VDSA_CONST.Constants.PRIMARY_SUBSIDIARY;
                var termDiscount = result.getValue("termsdiscountamount");
                if (termDiscount>0){
                    termDiscount = format.format({
                        type: format.Type.CURRENCY,
                        value: termDiscount
                    })
                }
                var recId = result.getValue({ name: "internalid" });
                var recType = result.getText({ name: "type" });
                var recUrl = url.resolveRecord({
                    recordType: record.Type.VENDOR_BILL,
                    recordId: recId
                });
                var recLink = '<a href=' + recUrl + '>' + recType + '</a>';
                return [
                    // intentionally blank. Datatables CSS takes care of the checkbox
                    '',
                    recId,
                    result.getValue({ name: "duedate" }),
                    recLink,
                    result.getValue({ name: "entityid", join: "vendor" }),
                    result.getValue({ name: "internalid", join: "vendor" }),
                  	result.getValue({ name: "tranid" }),
                    result.getValue({ name: "transactionnumber" }),
                    result.getText({ name: "currency" }),
                    result.getValue({ name: "currency" }),
                    result.getValue({ name: "exchangerate" }),
                    format.format({
                        type: format.Type.CURRENCY,
                        value: result.getValue({ name: "amount" })
                    }),
                    format.format({
                        type: format.Type.CURRENCY,
                        value: result.getValue({ name: "amountremaining" })
                    }),
                    result.getValue({ name: "account" }),
                    result.getValue({ name: "termsdiscountdate" }),
                    termDiscount,

                    resultSubsidiary,
                    // html input fields
                    '<input class="bulk-vendor-discount" type="number" value="'+termDiscount.replace(/,/g, '')+'" lang="en" name="Disc. Taken" min="0" />',
                    '<input class="bulk-vendor-amount" type="number" lang="en" name="Amount" min="0" />',
                ];

            });

            // dynamically create column names off of their labels. Makes it easier to modify / change headers
            var dateTablesColumns = columns.map(function(column) {
                return { title: column.label };
            });

            // add checkbox column title to beginning of array
            dateTablesColumns.unshift({ title: 'Apply' });

            // add payment input fields at the end of the array
            dateTablesColumns.push({ title: 'Disc. Taken', searchable: false });
            dateTablesColumns.push({ title: 'Payment', searchable: false });

            var assetField = visaForm.addField({
                id: 'custpage_vdsa_search_results',
                type: serverWidget.FieldType.INLINEHTML,
                label: 'dataTablesSearchValues',
                container: 'vendorBillList'
            });


            assetField.defaultValue = '<script type="text/javascript">' +
                'var dataTablesValues = ' + JSON.stringify(dataTablesValues) + ';\n' +
                'var dataTablesColumns = ' + JSON.stringify(dateTablesColumns) + ';\n' +
                '</script>';

            return visaForm;
        }

        /**
         * Get Field Source values for treasure banks field
         * @return {[type]} [description]
         */
        function getTreasuryBankAccounts() {

            var subsidiaryBaseCurrencyMapping = getSubsidiaryBaseCurrencies();

            var filters = [
                search.createFilter({ name: "isinactive", operator: search.Operator.IS, values: false })
            ];

            var columns = [
                search.createColumn({ name: "name" }),
                search.createColumn({ name: "custrecord_vdsa_bank_account" }),
                search.createColumn({ name: "custrecord_vdsa_account_number" }),
                search.createColumn({ name: "custrecord_vdsa_account_name" }),
                search.createColumn({ name: 'custrecord_vdsa_bank_currency' }),
                search.createColumn({ name: 'custrecord_vdsa_currency_list' }),
                // search.createColumn({ name: "currency", join: "CUSTRECORD_VDSA_BANK_ACCOUNT" }),
                search.createColumn({ name: "availablebalance", join: "CUSTRECORD_VDSA_BANK_ACCOUNT" }),
                search.createColumn({ name: "balance", join: "CUSTRECORD_VDSA_BANK_ACCOUNT" }),
                search.createColumn({ name: "custrecord_vdsa_payment_threshold" })
            ];

            if (bulkLib.isOneWorld) {
                columns.push(search.createColumn({ name: 'subsidiary', join: "CUSTRECORD_VDSA_BANK_ACCOUNT" }));
            }

            var treasuryBankResults = utilLib.getAllResults({
                type: 'customrecord_vdsa_treasury_bank_details',
                filters: filters,
                columns: columns
            });

            var treasuryAccounts = {};
            var treasuryAccountFieldSourcing = [];
            var treasuryNameFieldSourcing = [];
            for (var i = 0; i < treasuryBankResults.length; i++) {
                var result = treasuryBankResults[i];
                var accountCurrency = result.getValue({ name: 'custrecord_vdsa_bank_currency' });
                var accountSubsidiary = (bulkLib.isOneWorld === true) ? result.getValue({ name: 'subsidiary', join: "CUSTRECORD_VDSA_BANK_ACCOUNT" }) : VDSA_CONST.Constants.PRIMARY_SUBSIDIARY;
                var isBaseCurrency = (subsidiaryBaseCurrencyMapping[accountSubsidiary] === accountCurrency);

                treasuryAccounts[result.id] = {
                    name: result.getValue({ name: "name" }),
                    account: result.getValue({ name: 'custrecord_vdsa_bank_account' }),
                    subsidiary: accountSubsidiary,
                    balance: result.getValue({ name: "availablebalance", join: "CUSTRECORD_VDSA_BANK_ACCOUNT" }),
                    availableBalance: result.getValue({ name: "balance", join: "CUSTRECORD_VDSA_BANK_ACCOUNT" }),
                    currency: accountCurrency,
                    availableCurrencies: result.getValue({ name: 'custrecord_vdsa_currency_list' }),
                    threshold: result.getValue({ name: 'custrecord_vdsa_payment_threshold' }),
                    isBaseCurrency: isBaseCurrency,
                };
                treasuryNameFieldSourcing.push({
                    value: result.id,
                    text: result.getValue({ name: "name" })
                });
            }
            return {
                treasuryAccounts: treasuryAccounts,
                treasuryNameFieldSourcing: treasuryNameFieldSourcing
            };
        }

        /**
         * Need subsidiary mappings for currencies. 
         * @return {[type]} [description]
         */
        function getSubsidiaryBaseCurrencies() {
            var subsidiaryMapping = {};
            if (bulkLib.isOneWorld) {
                var filters = [
                    search.createFilter({ name: "isinactive", operator: search.Operator.ANYOF, values: false })
                ];

                var columns = [
                    search.createColumn({ name: "name" }),
                    search.createColumn({ name: "currency" }),

                ];

                var subsidiaryResults = utilLib.getAllResults({
                    type: search.Type.SUBSIDIARY,
                    filters: filters,
                    columns: columns
                });


                for (var i = 0; i < subsidiaryResults.length; i++) {
                    var subCurrency = subsidiaryResults[i].getValue({ name: "currency" });
                    subsidiaryMapping[subsidiaryResults[i].id] = subCurrency;
                }

            } else { // if no one world then base currency comes from config
                companyInfo = config.load({
                    type: config.Type.COMPANY_INFORMATION
                });
                var baseCurrency = companyInfo.getValue({
                    fieldId: 'basecurrency'
                });
                //load config
                subsidiaryMapping[VDSA_CONST.Constants.PRIMARY_SUBSIDIARY] = baseCurrency;
            }

            return subsidiaryMapping;

        }

        /**
         * Obtain all AP accounts to populate the field
         * @return {[type]} [description]
         */
        function getAPAccounts() {
            var filters = [
                search.createFilter({ name: "type", operator: search.Operator.ANYOF, values: "AcctPay" })
            ];
            var columns = [
                search.createColumn({ name: "name" })
            ];

            var treasuryBankResults = utilLib.getAllResults({
                type: search.Type.ACCOUNT,
                filters: filters,
                columns: columns
            });

            return treasuryBankResults.map(function(result) {
                return {
                    value: result.id,
                    text: result.getValue({ name: "name" }),
                };
            });
        }

        /**
         * Helper function to adds sourcing object to a field
         * @param {nlobjField} field        Field that requires sourcing 
         * @param {[type]} sourceValues [description]
         */
        function addSourceValuesToField(field, sourceValues) {
            // if populated, select first option
            if (sourceValues.length > 0) {
                sourceValues[0].isSelected = true;
                field.addSelectOption(sourceValues[0]);
            } else { // if field is empty add empty option
                field.addSelectOption({ value: '', text: '', isSelected: true });
            }

            // populate with source values
            for (var apIndex = 1; apIndex < sourceValues.length; apIndex++) {
                field.addSelectOption(sourceValues[apIndex]);
            }
            return field;
        }


        function createBillPaymentJob(billDetailObj, apAccount, subsidiary , date, default_classification, default_department, default_location, posting_period, treasuryBankName) {
            
            var newParent = record.create({
                type: 'customrecord_vdsa_bulk_vendor_payment',
                isDynamic: true
            });

            newParent.setValue({ fieldId: 'custrecord_vdsa_bvp_status', value: bulkLib.STATUS_MAPPING['In Queue'] });

            newParent.setValue({ fieldId: 'custrecord_vdsa_bvp_subsidiary', value: subsidiary });
            newParent.setValue({ fieldId: 'custrecord_vdsa_bvp_ap_account', value: apAccount });
            newParent.setValue({
                fieldId: 'custrecord_vdsa_bvp_date',
                value: format.parse({
                    type: format.Type.DATE,
                    value: date,
                })
            });
            newParent.setValue({ fieldId: 'custrecord_vdsa_bvp_class', value: default_classification });
            newParent.setValue({ fieldId: 'custrecord_vdsa_bvp_department', value: default_department });
            newParent.setValue({ fieldId: 'custrecord_vdsa_bvp_location', value: default_location });
            newParent.setValue({ fieldId: 'custrecord_vdsa_bvp_posting_period', value: posting_period });
            newParent.setValue({ fieldId: 'custrecord_vdsa_bvp_treasury_bank', value: treasuryBankName });

            for (var dtRowIndex = 0; dtRowIndex < billDetailObj.length; dtRowIndex++) {
                var dtRow = billDetailObj[dtRowIndex];
                newParent.selectNewLine({ sublistId: 'recmachcustrecord_vdsa_bvp_parent' });

                var dtRowParsedAmount = format.parse({
                    type: format.Type.CURRENCY,
                    value: dtRow.dtRowAmount
                });
                newParent.setCurrentSublistValue({
                    sublistId: 'recmachcustrecord_vdsa_bvp_parent',
                    fieldId: 'custrecord_vsda_bvp_transaction',
                    value: dtRow.dtRowInternalid
                });
                newParent.setCurrentSublistValue({
                    sublistId: 'recmachcustrecord_vdsa_bvp_parent',
                    fieldId: 'custrecord_vsda_bvp_payment_amount',
                    value: dtRowParsedAmount
                });
                newParent.setCurrentSublistValue({
                    sublistId: 'recmachcustrecord_vdsa_bvp_parent',
                    fieldId: 'custrecord_vsda_bvp_discount',
                    value: dtRow.dtRowDiscount
                });
                newParent.setCurrentSublistValue({
                    sublistId: 'recmachcustrecord_vdsa_bvp_parent',
                    fieldId: 'custrecord_vsda_bvp_currency',
                    value: dtRow.dtRowCurrency
                });
                newParent.setCurrentSublistValue({
                    sublistId: 'recmachcustrecord_vdsa_bvp_parent',
                    fieldId: 'custrecord_vsda_bvp_vendor',
                    value: dtRow.dtRowVendor
                });

                newParent.setCurrentSublistValue({
                    sublistId: 'recmachcustrecord_vdsa_bvp_parent',
                    fieldId: 'custrecord_vsda_bvp_transaction_status',
                    value: bulkLib.STATUS_MAPPING['In Queue']
                });

                newParent.commitLine({ sublistId: 'recmachcustrecord_vdsa_bvp_parent' });
            }
            return newParent.save();
        }

        /**
         * Checks if the ADB process is running by searching for an instance of the processing deployment
         * @return {Boolean} True if process is running, false if it is not
         */
        function isBulkPaymentsInProcess() {

            var PROCESSING_DEPLOYMENT = "VDSA Bulk Vendor Payment Processing";
            var filters = [];

            filters.push(search.createFilter({ name: 'title', join: search.Type.SCRIPT_DEPLOYMENT, operator: search.Operator.IS, values: PROCESSING_DEPLOYMENT }));
            filters.push(search.createFilter({ name: 'status', operator: search.Operator.ANYOF, values: ["PENDING", "PROCESSING", "RETRY"] }));

            var searchObj = search.create({ type: search.Type.SCHEDULED_SCRIPT_INSTANCE, filters: filters });
            var searchResults = searchObj.run().getRange({ start: 0, end: 1 });

            return searchResults.length === 1 ? true : false;
        }

        /**
		 * Function to determine if role of current user is eligible to manage
		 * card payouts of a vendor as configured in the preference page
		 *
		 * @return boolean
		 */
		function roleEligible() {
			var roleEligible = false;

			var scriptObj = runtime.getCurrentScript();
			var prefId = scriptObj.getParameter({
				name: 'custscript_vdsa_preference_record'
			});

			if (!prefId) {
				return false;
			}

			// Lookup global preference
			var lookupRes = search.lookupFields({
				type: 'customrecord_vdsa_suiteapp_preference',
				id: prefId,
				columns: 'custrecord_vdsa_pymt_processing_roles'
			});
			var pmtProcessingRolesArr = lookupRes.custrecord_vdsa_pymt_processing_roles;

			// Get current user role
			var currUserRole = runtime.getCurrentUser().role;

			// Check if current user role is in lookup results
			for (var index in pmtProcessingRolesArr) {
				var roleId = pmtProcessingRolesArr[index]['value'];
				if (currUserRole == roleId) {
					roleEligible = true;
					break;
				}
			}

			return roleEligible;
		}

        return {
            onRequest: function(context) {
                try {
                    // Backend actions. Nothing currently implemented only stubbed out
                    log.debug({ title: 'Method', details: context.request.method });
                    if (context.request.method === 'POST') {                        
                        log.debug({ title: 'Parameters', details: JSON.stringify(context.request.parameters) });
                        var parameters = context.request.parameters;
                        var requestAction = parameters.action;
                        switch (requestAction) {
                            case 'createBills':
                                var billDetailObj = JSON.parse(parameters.billDetailObj);
                                var apAccount = parameters.apAccount;
                                var subsidiary = parameters.subsidiary;
                                var date = parameters.date;
                                var default_classification = parameters.default_classification;
                                var default_department = parameters.default_department;
                                var default_location = parameters.default_location;
                                var posting_period = parameters.posting_period;
                                var treasuryBankName = parameters.treasuryBankName;

                                var paymentProcessRecId = createBillPaymentJob(
                                    billDetailObj,
                                    apAccount,
                                    subsidiary,
                                    date,
                                    default_classification,
                                    default_department,
                                    default_location,
                                    posting_period,
                                    treasuryBankName
                                );


                                if (!isBulkPaymentsInProcess()) {
                                    var mrTask = task.create({
                                        taskType: task.TaskType.MAP_REDUCE,
                                        scriptId: 'customscript_vdsa_payment_creation',
                                        deploymentId: 'customdeploy_vdsa_payment_creation',
                                        params: { custscript_vdsa_bvp_payment_job_id: paymentProcessRecId }
                                    });

                                    var taskId = mrTask.submit();
                                }

                                context.response.setHeader({
                                    name: 'Content-Type',
                                    value: 'Application/JSON',
                                });

                                context.response.write({
                                    output: JSON.stringify({
                                        // taskId: taskId,
                                        paymentProcessRecId: paymentProcessRecId
                                    })
                                });

                                //TODO: Create search function
                                break;
                            default:
                                return 'no action specified returned';
                        }
                    } else if (context.request.method === 'GET') {
                        if (!roleEligible()){
                            throw error.create({
                                name: 'Access Error',
                                message: 'You are not authorized to view this page.'
                            });
                        }
                        var visaForm = serverWidget.createForm({ title: 'Card Payouts Bulk Vendor Payment' });
                        // add standard fields and form elements to form
                        visaForm = addNetSuiteUIAssets(visaForm);
                        // add vendor bill data to the form
                        visaForm = AddVendorBills(visaForm);
                        // add netsuite filters for segmentation and date range
                        visaForm = addNetSuiteFilters(visaForm);
                        // add custom assets from Bulk Vendor Assets folder
                        visaForm = bulkLib.addCustomUIAssets(visaForm);
                        // add button to create Payment(s)
                        visaForm.addButton({
                            id: 'custpage_vdsa_create_bill',
                            label: 'Pay Bill(s)',
                            functionName: 'createBill'
                        });
                        // Set the client script for button triggers and UI 
                        visaForm.clientScriptModulePath = './VDSA_Bulk_Vendor_Payment_Page_CLI.js';
                        // write form to page
                        context.response.writePage(visaForm);
                    }
                } catch (errorObj) {
                    log.debug({ title: 'Error Details', details: JSON.stringify(errorObj) });
                    utilLib.createErrorRecord(errorObj);
                    throw errorObj.message;
                }
            }
        };
    });